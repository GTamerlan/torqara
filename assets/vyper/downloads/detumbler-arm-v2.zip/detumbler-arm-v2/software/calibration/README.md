Calibration results are written here by the tools (they are specific to your camera and rig):

- `camera_intrinsics.json` from `tools/calibrate_camera.py` (lens)
- `camera_to_base.json` from `tools/calibrate_camera_to_robot.py --port ...` (camera pose in the robot base frame and the boom marker offset)

`--sim` runs write `camera_to_base_SIM.json` instead, so a simulated calibration can never be used on the real rig by mistake.
Re-run the camera-to-robot calibration whenever the camera or the arm base moves.
