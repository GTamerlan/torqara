"""Forward and inverse kinematics for a serial robot arm described by DH parameters.

The arm is loaded from a TOML file (see config/arm_example_6dof.toml). Swap in your own
arm's numbers and everything else in the package keeps working.

Standard DH convention, joint i (counting from 1):
    T_{i-1,i} = Rz(theta_i + offset_i) · Tz(d_i) · Tx(a_i) · Rx(alpha_i)
Joint i rotates about the z axis of frame i-1.

The tool frame is where the magnet's center is, and its z axis is the magnet's spin
axis (the motor shaft). The IK solves for that point and that axis direction.
"""
from dataclasses import dataclass
import tomllib
import numpy as np

from .frames import T_from_xyz_rpy, make_T, unit


def dh_T(a, alpha, d, theta):
    ca, sa, ct, st = np.cos(alpha), np.sin(alpha), np.cos(theta), np.sin(theta)
    return np.array([
        [ct, -st * ca, st * sa, a * ct],
        [st, ct * ca, -ct * sa, a * st],
        [0.0, sa, ca, d],
        [0.0, 0.0, 0.0, 1.0],
    ])


@dataclass
class IKResult:
    q: np.ndarray
    ok: bool
    pos_err: float          # meters
    axis_err_deg: float     # degrees, 0 when no axis was requested
    flipped: bool           # True if the tool z axis points along -axis (spin the motor the other way)
    iters: int


class Arm:
    def __init__(self, dh, lower, upper, tool=None, base=None, max_speed=None, name="arm", home=None, capsules=None):
        self.dh = np.asarray(dh, float)            # rows: a [m], alpha [rad], d [m], theta_offset [rad]
        self.lower = np.asarray(lower, float)      # joint limits [rad]
        self.upper = np.asarray(upper, float)
        self.tool = np.eye(4) if tool is None else np.asarray(tool, float)   # flange -> magnet center
        self.base = np.eye(4) if base is None else np.asarray(base, float)   # robot base frame -> first DH frame
        n = len(self.dh)
        self.max_speed = np.full(n, np.radians(60.0)) if max_speed is None else np.asarray(max_speed, float)
        self.max_accel = 3.0 * self.max_speed        # joint acceleration limit [rad/s^2]; from_toml overrides
        self.name = name
        self.home = np.zeros(n) if home is None else np.asarray(home, float)
        # collision capsules: list of (link frame index, Kx3 points in that frame, radius, name)
        self.capsules = []
        if capsules:
            F_home = self.frames(self.home)
            for c in capsules:
                p1, p2 = np.asarray(c["p1"], float), np.asarray(c["p2"], float)
                k = max(2, int(np.ceil(np.linalg.norm(p2 - p1) / 0.02)) + 1)
                pts = p1[None, :] + np.linspace(0, 1, k)[:, None] * (p2 - p1)[None, :]
                Fi = F_home[int(c["link"])]
                local = (np.linalg.inv(Fi) @ np.c_[pts, np.ones(k)].T).T[:, :3]
                self.capsules.append((int(c["link"]), local, float(c["radius"]), c.get("name", "")))

    @property
    def n(self):
        return len(self.dh)

    @classmethod
    def from_toml(cls, path):
        with open(path, "rb") as f:
            cfg = tomllib.load(f)
        a = cfg.get("arm", {})
        joints = cfg["joint"]
        dh = [[j["a"], np.radians(j["alpha_deg"]), j["d"], np.radians(j.get("theta_offset_deg", 0.0))] for j in joints]
        lower = [np.radians(j.get("min_deg", -180.0)) for j in joints]
        upper = [np.radians(j.get("max_deg", 180.0)) for j in joints]
        speed = [np.radians(j.get("max_speed_dps", 60.0)) for j in joints]
        accel = [np.radians(j.get("max_accel_dps2", 3.0 * j.get("max_speed_dps", 60.0))) for j in joints]
        t = cfg.get("tool", {})
        tool = T_from_xyz_rpy(t.get("xyz", [0, 0, 0]), t.get("rpy_deg", [0, 0, 0]))
        base = T_from_xyz_rpy(a.get("base_xyz", [0, 0, 0]), a.get("base_rpy_deg", [0, 0, 0]))
        home = np.radians(a["home_deg"]) if "home_deg" in a else None
        out = cls(dh, lower, upper, tool, base, speed, a.get("name", "arm"), home, cfg.get("collision"))
        out.max_accel = np.asarray(accel, float)
        return out

    def copy_with(self, dh_offsets_rad=None, tool=None):
        """A perturbed copy, used to simulate a real arm that differs from its model."""
        dh = self.dh.copy()
        if dh_offsets_rad is not None:
            dh[:, 3] += np.asarray(dh_offsets_rad, float)
        out = Arm(dh, self.lower, self.upper, self.tool if tool is None else tool, self.base, self.max_speed, self.name + "-true", self.home)
        out.capsules = self.capsules
        out.max_accel = self.max_accel
        return out

    def collision_points(self, q):
        """Sample points of every collision capsule at joints q: (N x 3 points, N radii, N capsule index)."""
        if not self.capsules:
            return np.zeros((0, 3)), np.zeros(0), np.zeros(0, int)
        F = self.frames(q)
        P, R, I = [], [], []
        for k, (li, local, r, _) in enumerate(self.capsules):
            Fi = F[li]
            P.append(local @ Fi[:3, :3].T + Fi[:3, 3])
            R.append(np.full(len(local), r))
            I.append(np.full(len(local), k))
        return np.vstack(P), np.concatenate(R), np.concatenate(I)

    def frames(self, q):
        """List of n+2 transforms in the robot base frame: base, after joint 1..n, tool."""
        T = self.base.copy()
        out = [T]
        for (a, alpha, d, off), qi in zip(self.dh, q):
            T = T @ dh_T(a, alpha, d, qi + off)
            out.append(T)
        out.append(T @ self.tool)
        return out

    def fk(self, q):
        """Pose of the magnet (tool frame) in the robot base frame."""
        return self.frames(q)[-1]

    def jacobian(self, q):
        """Geometric Jacobian of the tool frame: rows 0-2 linear velocity, rows 3-5 angular velocity."""
        return self.jacobian_from_frames(self.frames(q))

    def jacobian_from_frames(self, F):
        p = F[-1][:3, 3]
        J = np.zeros((6, self.n))
        for i in range(self.n):
            z = F[i][:3, 2]
            r = p - F[i][:3, 3]
            J[0, i] = z[1] * r[2] - z[2] * r[1]
            J[1, i] = z[2] * r[0] - z[0] * r[2]
            J[2, i] = z[0] * r[1] - z[1] * r[0]
            J[3:, i] = z
        return J

    def reach(self):
        return float(np.sum(np.abs(self.dh[:, 0])) + np.sum(np.abs(self.dh[:, 2])) + np.linalg.norm(self.tool[:3, 3]))

    def clamp(self, q):
        return np.minimum(np.maximum(q, self.lower), self.upper)

    def dls_step(self, q, p, axis=None, max_joint_step=np.radians(1.0), damping=0.01, damping_axis=0.05):
        """One small resolved-rate step toward magnet position p (and spin axis), every joint
        moving at most max_joint_step. Call it a few times per control tick.

        Task priority: the position error is solved first; the spin-axis error only uses the
        freedom left over (null space), so aiming the magnet can never drag it off position.
        Joints that are at a limit and being pushed further are dropped from the solve.
        Returns (q_new, flipped) where flipped means the tool z points along -axis."""
        n = self.n
        F = self.frames(q)
        T = F[-1]
        J = self.jacobian_from_frames(F)
        ep = np.asarray(p, float) - T[:3, 3]
        flipped = False
        zt = None
        if axis is not None:
            zt = unit(axis)
            if np.dot(T[:3, 2], zt) < 0:
                zt, flipped = -zt, True
        active = np.ones(n, bool)
        dq = np.zeros(n)
        for _ in range(4):
            Jp = J[:3] * active
            Jp_pinv = Jp.T @ np.linalg.inv(Jp @ Jp.T + damping ** 2 * np.eye(3))
            dq = Jp_pinv @ ep
            if zt is not None:
                eo = np.cross(T[:3, 2], zt)
                Jo = J[3:] * active
                N = (np.eye(n) - Jp_pinv @ Jp) * active
                JoN = Jo @ N
                dq = dq + N @ (JoN.T @ np.linalg.solve(JoN @ JoN.T + damping_axis ** 2 * np.eye(3), eo - Jo @ dq))
            caps = np.broadcast_to(np.asarray(max_joint_step, float), dq.shape)
            ratio = np.max(np.abs(dq) / np.maximum(caps, 1e-12))
            if ratio > 1.0:
                dq = dq / ratio                     # uniform scaling keeps the step's direction
            qn = q + dq
            push = active & (((qn <= self.lower + 1e-6) & (dq < 0)) | ((qn >= self.upper - 1e-6) & (dq > 0)))
            if not push.any():
                break
            active &= ~push
        return self.clamp(q + dq), flipped

    def ik(self, p, axis=None, q0=None, allow_flip=True, tol_pos=2e-4, tol_ang_deg=0.5,
           iters=300, restarts=10, w_axis=0.15, damping=0.01, rng=None):
        """Joint angles that put the magnet center at p (base frame) with its spin axis along `axis`.

        Damped least squares with joint limits and random restarts. `axis` may be None to
        solve position only. If allow_flip, the tool may point along -axis instead (the
        motor then spins the other way), whichever is closer to the starting pose.
        """
        rng = np.random.default_rng(0) if rng is None else rng
        p = np.asarray(p, float)
        ax = None if axis is None else unit(axis)
        seeds = [self.clamp(np.zeros(self.n) if q0 is None else np.asarray(q0, float))]
        for _ in range(restarts):
            seeds.append(rng.uniform(self.lower, self.upper))
        best = None
        for qs in seeds:
            q = qs.copy()
            flip = False
            if ax is not None and allow_flip:
                flip = float(np.dot(self.fk(q)[:3, 2], ax)) < 0
            zt = None if ax is None else (-ax if flip else ax)
            res = None
            for it in range(iters):
                F = self.frames(q)
                T = F[-1]
                ep = p - T[:3, 3]
                ang = 0.0
                if zt is not None:
                    zc = T[:3, 2]
                    ang = float(np.degrees(np.arccos(np.clip(np.dot(zc, zt), -1, 1))))
                pos_err = float(np.linalg.norm(ep))
                if pos_err < tol_pos and ang < tol_ang_deg:
                    res = IKResult(q, True, pos_err, ang, flip, it)
                    break
                J = self.jacobian_from_frames(F)
                if zt is None:
                    Jt, e = J[:3], ep
                else:
                    Jt = np.vstack([J[:3], w_axis * J[3:]])
                    z = T[:3, 2]
                    e = np.r_[ep, w_axis * np.array([z[1] * zt[2] - z[2] * zt[1], z[2] * zt[0] - z[0] * zt[2], z[0] * zt[1] - z[1] * zt[0]])]
                lam2 = damping ** 2
                dq = Jt.T @ np.linalg.solve(Jt @ Jt.T + lam2 * np.eye(len(e)), e)
                step = np.linalg.norm(dq)
                if step > 0.25:
                    dq *= 0.25 / step
                q = self.clamp(q + dq)
            if res is None:
                T = self.fk(q)
                ang = 0.0 if zt is None else float(np.degrees(np.arccos(np.clip(np.dot(T[:3, 2], zt), -1, 1))))
                res = IKResult(q, False, float(np.linalg.norm(p - T[:3, 3])), ang, flip, iters)
            if res.ok:
                return res
            if best is None or res.pos_err + 0.001 * res.axis_err_deg < best.pos_err + 0.001 * best.axis_err_deg:
                best = res
        return best
