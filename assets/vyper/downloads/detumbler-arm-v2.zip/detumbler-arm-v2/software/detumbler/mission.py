"""The control loop that runs on the real rig (and, unchanged, against SimWorld).

Every camera frame:
  1. Target pose: camera fix -> robot base frame (through the camera-to-base calibration).
  2. Brain: update the tumble estimate, re-plan, get the next magnet waypoint and spin.
  3. Where is the magnet really? Forward kinematics, corrected by the camera's view of the
     tool marker (see `visual_correction` below). This is what makes the gap accurate.
  4. Safety checks, inverse kinematics, joint and motor commands.

Why the visual correction matters: a hobby arm's forward kinematics can be off by several
millimeters (joint zero errors, link bending, backlash). The camera sees BOTH the target
and the magnet holder, so it measures the gap directly, and most calibration errors cancel
because they affect both measurements the same way.
"""
import csv
import numpy as np
from .frames import R_from_quat

from .frames import apply_T, quat_from_R
from .brain import Brain, effective_momentum
from .jsplanner import JointPlanner


class MissionRunner:
    def __init__(self, arm, arm_io, motor_io, brain, safety, T_base_cam, marker_in_tool,
                 com_in_body=None, visual_correction=True, log_path=None):
        self.arm = arm
        self.arm_io = arm_io
        self.motor = motor_io
        self.brain = brain
        self.safety = safety
        self.T_bc = np.asarray(T_base_cam, float)
        self.marker_in_tool = np.asarray(marker_in_tool, float)
        self.com = np.zeros(3) if com_in_body is None else np.asarray(com_in_body, float)
        self.visual = visual_correction
        self.center = None
        self.bias = np.zeros(3)
        self.t_last_fix = -1e9
        self.t_prev = None
        self.q_cmd = None
        self.last = {}
        self.rows = []
        self.log_path = log_path
        self._reach = {}
        self._reach_t = {}
        self.t_last_tool = -1e9
        self._stuck_idx = None
        self._stuck_t = 0.0
        self._ik_budget = 0
        self._goal_q = {}
        self._unsafe_since = None
        self._recover_until = -1.0
        # joint-space planning for big moves (arms with collision models)
        self.jsp = JointPlanner(arm, self._plan_valid, weights=[1.0, 1.0, 0.8, 0.4, 0.4][:arm.n] + [0.4] * max(0, arm.n - 5)) if arm.capsules else None
        self.js_path = None
        self.js_spot = None
        self.js_progress_t = 0.0
        self.js_fail = {}
        brain.cfg.reach_dir = np.array([1.0, 0.0, 0.0])
        brain.waypoint_check = self.waypoint_ok      # approach waypoints: cheap checks; spots: full IK

    def magnet_estimate(self, q_now):
        T = self.arm.fk(q_now)
        return T[:3, 3] + self.bias, T

    def step(self, t, meas):
        """meas: dict with keys T_cam_target (4x4 or None), p_cam_tool_marker (3 or None)."""
        dt = 1 / 30 if self.t_prev is None else max(1e-3, t - self.t_prev)
        self.t_prev = t
        brain, cfg = self.brain, self.brain.cfg

        # 1. target in the robot base frame
        if meas.get("T_cam_target") is not None:
            T_bo = self.T_bc @ meas["T_cam_target"]
            c = apply_T(T_bo, self.com)
            self.center = c if self.center is None else self.center + 0.1 * (c - self.center)
            brain.measure(quat_from_R(T_bo[:3, :3]), t)
            self.t_last_fix = t
            if self.center is not None:
                cfg.reach_dir = (self.safety.base - self.center) / max(1e-6, np.linalg.norm(self.safety.base - self.center))
        if self.center is None:
            return None

        # 3. magnet position: model + camera correction
        q_now = self.arm_io.read_joints()
        p_fk, T_fk = self.magnet_estimate(q_now)
        if self.visual and meas.get("p_cam_tool_marker") is not None:
            p_marker_meas = apply_T(self.T_bc, meas["p_cam_tool_marker"])
            p_marker_model = apply_T(T_fk, self.marker_in_tool)
            self.bias += 0.15 * ((p_marker_meas - p_marker_model) - self.bias)
            p_fk = T_fk[:3, 3] + self.bias
            self.t_last_tool = t
        # if the camera has not seen the magnet holder recently, we only have the arm's own
        # (less accurate) idea of where the magnet is: keep 10 mm more clearance
        seen = self.visual and (t - self.t_last_tool) < 0.3
        brain.position_uncertainty = 0.0 if seen else 0.010
        p_rel = p_fk - self.center

        # 2. brain
        self._ik_budget = 2 if self.jsp is not None else 4   # new reachability checks allowed this tick
        cmd = brain.tick(dt, t, p_rel, self.reachable)

        lost = (t - self.t_last_fix) > self.safety.lost_lock_timeout
        if lost or not cmd.locked and brain.phase in ("detumble", "stable"):
            self.motor.set_rpm(0.0)
            self.arm_io.send_joints(q_now if self.q_cmd is None else self.q_cmd)
            self._log(t, cmd, p_rel, None, "holding: no reliable target fix")
            return cmd

        # 4. safety, IK, commands
        goal = self.center + cmd.p_rel
        ok, why = self.safety.workspace_ok(goal), ""
        route = ""
        if not ok and brain.phase != "standby":
            # never freeze at the edge: aim for the nearest point inside the workspace instead
            goal = np.clip(goal, self.safety.ws_min + 0.005, self.safety.ws_max - 0.005)
            goal[2] = max(goal[2], self.safety.min_tool_z + 0.005)
            d = goal - self.center
            rs = float(brain.safe_radius(d / max(np.linalg.norm(d), 1e-9))[0])
            if np.linalg.norm(d) < rs:
                goal = self.center + d / max(np.linalg.norm(d), 1e-9) * rs
            ok, route = True, "clamped to workspace"
        if brain.phase == "standby":
            ok, why = True, ""
        q_send = self.q_cmd if self.q_cmd is not None else q_now
        ik = None
        if self.jsp is not None and brain.phase != "standby":
            # the hull envelope is closing in on the magnet or a link (the target turned toward a parked or
            # slowly moving arm): drop any planned move and back straight out, before anything else
            c_now = self.clearances(q_now)
            if c_now[0] < self.retreat_margin or c_now[1] < self.retreat_margin or c_now[4] < self.retreat_margin:
                return self.retreat(t, dt, q_now, p_fk, p_rel, cmd, c_now)
        if brain.phase in ("approach", "detumble") and self.jsp is not None:
            # nothing to do: no spot is feasible (the gimbal's ring or yoke covers every candidate for now).
            # Rather than loitering next to a moving ring, fold back toward the home pose and wait.
            no_spot = brain.planner.best is None or (brain.planner.scores is not None and brain.planner.scores.max() <= 0)
            if no_spot:
                self._no_spot_since = getattr(self, "_no_spot_since", t)
                if t - self._no_spot_since > 4.0:
                    self._recover_until = t + 2.0
            else:
                self._no_spot_since = t
        if ok and brain.phase != "standby" and t < self._recover_until:
            # recovery: the path was blocked (a link at the table or stand); fold back toward the
            # home pose in joint space, every step still checked, then re-plan
            q_send = self.safe_step(q_now, q_now + np.clip(self.arm.home - q_now, -self.safety.max_step, self.safety.max_step))
            self.q_cmd = q_send
            self.arm_io.send_joints(q_send)
            self.motor.set_rpm(0.0)
            self._log(t, cmd, p_rel, None, "recovering toward home pose")
            return cmd
        if ok and brain.phase == "stable" and self.jsp is not None:
            # target is still: park the magnet a few centimeters out (clear of the gimbal, which no longer moves),
            # then hold there with the motor stopped until the spin comes back
            c_now = self.clearances(q_now)
            r_now = float(np.linalg.norm(p_rel))
            if np.min(c_now) >= 0 and r_now >= float(brain.safe_radius(p_rel / max(r_now, 1e-9))[0]) + 0.03:
                self.js_path = None
                self.q_cmd = q_now
                self.arm_io.send_joints(q_now)
                self.motor.set_rpm(0.0)
                self._log(t, cmd, p_rel, None, "target stable, holding")
                return cmd
            return self.retreat(t, dt, q_now, p_fk, p_rel, cmd, c_now)
        if ok and brain.phase != "standby" and self.jsp is not None:
            handled = self.joint_space_move(t, dt, q_now, p_fk, cmd)
            if handled:
                return cmd
        if ok and brain.phase != "standby":
            # resolved-rate step: a few damped-least-squares iterations from the last command,
            # so position and spin axis converge smoothly over successive ticks
            target = goal - self.bias
            # resolved-rate control: several tiny Jacobian steps, each checked for safety
            q_try, flipped = q_now, False           # always step from where the arm actually is
            n_sub = 4
            caps = np.minimum(self.safety.max_step, self.arm.max_speed * dt) / n_sub
            for _ in range(n_sub):
                q_next, flipped = self.arm.dls_step(q_try, target, cmd.axis, max_joint_step=caps)
                q_safe = self.safe_step(q_try, q_next)
                if np.allclose(q_safe, q_try):
                    break
                q_try = q_safe
            q_send = q_try
            Tn = self.arm.fk(q_send)
            ang = float(np.degrees(np.arccos(np.clip(abs(np.dot(Tn[:3, 2], cmd.axis)), -1, 1))))
            ik = type("Step", (), {"ok": np.linalg.norm(Tn[:3, 3] - target) < 0.002 and ang < 5,
                                    "pos_err": float(np.linalg.norm(Tn[:3, 3] - target)),
                                    "axis_err_deg": ang, "flipped": flipped})()
            best = brain.planner.best
            if best != self._stuck_idx:
                self._stuck_idx, self._stuck_t = best, t
            if np.linalg.norm(goal - p_fk) < 0.01 or ik.ok:
                self._stuck_t = t
            elif t - self._stuck_t > 4.0:          # no progress for 4 s: is the spot really unreachable?
                full = self.arm.ik(goal - self.bias, axis=cmd.axis, q0=q_send, restarts=8, iters=200)
                if not full.ok or (self.arm.capsules and not np.all(self.clearances(full.q)[1:] >= 0)):
                    brain.planner.block(best)
                    why = "arm cannot reach that spot, re-planning"
                elif self.arm.capsules and np.min(self.clearances(q_now)) < 0.002:
                    self._recover_until = t + 2.5      # reachable, but this path is blocked: back off and retry
                    why = "path blocked, backing off"
                self._stuck_t = t
        self.q_cmd = q_send
        self.arm_io.send_joints(q_send)
        spin_ok = why == "" and ik is not None and ik.axis_err_deg < brain.cfg.spin_axis_tol_deg
        # speed about the tool's actual axis (tool z after this step), so the sweep law stays dissipative
        rpm = brain.rpm_for_axis(self.arm.fk(q_send)[:3, 2]) if spin_ok else brain.rpm_for_axis(None)
        self.motor.set_rpm(rpm if spin_ok else 0.0)
        self._log(t, cmd, p_rel, ik, why or route)
        return cmd

    retreat_margin = 0.0     # inside the hard envelope = retreat (it already includes the safety margins)
    reach_recheck_s = 2.0    # with a moving gimbal, re-verify a spot's reachability this often
    gimbal_plan_clearance = 0.015   # a planned pose keeps at least this from the (predicted) gimbal

    def retreat(self, t, dt, q_now, p_fk, p_rel, cmd, c_now):
        """Back the magnet radially away from the target center (spin axis kept), with resolved-rate steps
        that are only accepted if they improve the clearances. Motor off while retreating."""
        self.js_path = None
        self._recover_until = -1.0
        d = p_fk - self.center
        r = max(np.linalg.norm(d), 1e-9)
        out_dir = d / r
        if c_now[4] < min(c_now[0], c_now[1]) and self.brain.cfg.gimbal is not None:
            # the gimbal (ring, pins or yoke) is what came close: this spot is no good for a while, and the way
            # out is away from the ring plane (along its normal), not straight away from the hull
            if self.brain.planner.best is not None:
                self.brain.planner.block(self.brain.planner.best, seconds=8.0)
            if self.brain.est.init:
                n_ring = self.brain.cfg.gimbal.frame(R_from_quat(self.brain.est.q))[2]
                out_dir = n_ring if np.dot(n_ring, out_dir) >= 0 else -n_ring
        target = self.center + d + out_dir * 0.05 - self.bias
        caps = np.minimum(self.safety.max_step, self.arm.max_speed * dt) / 4
        q_try = q_now
        for _ in range(4):
            q_next, _ = self.arm.dls_step(q_try, target, cmd.axis, max_joint_step=caps)
            q_safe = self.safe_step(q_try, q_next)
            if np.allclose(q_safe, q_try):
                break
            q_try = q_safe
        if np.allclose(q_try, q_now):
            # no radial step improves things (a link, the gimbal, or a corner of the hull is in the way): fold back
            # toward the home pose instead, still only improving moves; if even that is blocked, hold and wait for
            # the hull to turn away (the next tick tries again)
            q_try = self.safe_step(q_now, q_now + np.clip(self.arm.home - q_now, -caps * 4, caps * 4))
            if np.allclose(q_try, q_now):
                self._stuck_ticks = getattr(self, "_stuck_ticks", 0) + 1
                if self._stuck_ticks > 15 and self.brain.planner.best is not None:
                    self.brain.planner.block(self.brain.planner.best, seconds=8.0)     # and re-plan elsewhere
            else:
                self._stuck_ticks = 0
        self.q_cmd = q_try
        self.arm_io.send_joints(q_try)
        self.motor.set_rpm(0.0)
        self._log(t, cmd, p_rel, None, "retreating: hull envelope too close")
        return cmd

    def joint_space_move(self, t, dt, q_now, p_fk, cmd):
        """Big moves to a new spot: plan a collision-free joint path to a pre-approach pose 3 cm
        outside the spot, then follow it. Returns True if this tick was handled here (the final
        few centimeters are left to the resolved-rate controller)."""
        brain = self.brain
        best = brain.planner.best
        spot = brain.planner.best_spot()
        if spot is None:
            return False
        far = np.linalg.norm(self.center + spot - p_fk) > brain.cfg.js_far
        if self.js_path is not None and self.js_spot != best:
            self.js_path = None                                  # the plan changed its mind
        if self.js_path is None and far and self.js_fail.get(best, -1e9) < t - 3.0:
            d = spot / np.linalg.norm(spot)
            p_pre = self.center + d * (np.linalg.norm(spot) + 0.03) - self.bias
            q_goal = self.spot_goal_q(spot)
            if q_goal is None or not self._plan_valid(q_goal):
                q_goal = self.goal_configuration(p_pre, cmd.axis, q_now)
            path = self.jsp.plan(q_now, q_goal) if q_goal is not None else None
            self.js_stats = getattr(self, "js_stats", {"no_goal": 0, "no_path": 0, "ok": 0, "checks": 0})
            self.js_stats["no_goal" if q_goal is None else ("no_path" if path is None else "ok")] += 1
            self.js_stats["checks"] += self.jsp.checks
            if path is None:
                self.js_fail[best] = t
                brain.planner.block(best, seconds=8.0)
                self._log(t, cmd, p_fk - self.center, None, "no collision-free path to that spot, re-planning")
                self.arm_io.send_joints(q_now)
                self.motor.set_rpm(0.0)
                return True
            self.js_path = [np.asarray(q) for q in path[1:]]
            self.js_spot = best
            self.js_progress_t = t
        if self.js_path is None:
            return False
        q_wp = self.js_path[0]
        caps = np.minimum(self.safety.max_step, self.arm.max_speed * dt)
        q_next = self.safe_step(q_now, q_now + np.clip(q_wp - q_now, -caps, caps))
        if np.max(np.abs(q_next - q_now)) > np.radians(0.05):
            self.js_progress_t = t
        if np.max(np.abs(q_wp - q_next)) < np.radians(1.0):
            self.js_path.pop(0)
            if not self.js_path:
                self.js_path = None
        if t - self.js_progress_t > 1.5:                          # blocked by the live envelope: re-plan
            self.js_path = None
        self.q_cmd = q_next
        self.arm_io.send_joints(q_next)
        self.motor.set_rpm(0.0)
        self._log(t, cmd, p_fk - self.center, None, "joint-space move to the next spot")
        return True

    def goal_configuration(self, p, axis, q_near):
        """A collision-free joint solution with the magnet at p and its spin axis along +-axis,
        closest to q_near. Both boom directions are tried (the motor just spins the other way)."""
        sols = []
        signs = (1.0, -1.0) if axis is not None else (1.0,)
        for k, sgn in enumerate(signs):
            ax = None if axis is None else sgn * np.asarray(axis, float)
            for seed in range(3):
                ik = self.arm.ik(p, axis=ax, q0=q_near if seed == 0 else None, allow_flip=False, restarts=4, iters=150,
                                 rng=np.random.default_rng(10 * k + seed))
                if ik.ok and self._plan_valid(ik.q):
                    sols.append(ik.q)
                    break
        if not sols:
            return None
        return min(sols, key=lambda q: self.jsp.dist(q, q_near))

    def _plan_valid(self, q):
        c = self.clearances(q, plan=True)
        return bool(c[0] >= 0.005 and c[1] >= 0.005 and c[2] >= 0.0 and c[3] >= 0.0 and c[4] >= self.gimbal_plan_clearance)

    def clearances(self, q, plan=False):
        """Every clearance that must stay positive at joint angles q, in meters:
        magnet head vs. the hull safety envelope, arm links vs. the envelope, and
        links + magnet head vs. the fixed obstacles (target stand, table).
        plan=True checks against the full-turn envelope used for motion planning."""
        T = self.arm.fk(q)
        p = T[:3, 3] + self.bias
        d = p - self.center
        r = np.linalg.norm(d)
        m_hat = d / max(r, 1e-9)
        if plan:
            head = r - float(self.brain.plan_support(m_hat)[0]) - self.brain.cfg.r_head - self.brain.cfg.safety_gap
        else:
            head = r - float(self.brain.safety_radius(m_hat)[0])
        P, R, _ = self.arm.collision_points(q)
        if len(P):
            P = P + self.bias
            links = self.brain.link_clearance(P - self.center, R, m_hat, plan=plan)
            static = self.safety.static_clearance(np.vstack([P, p[None, :]]), np.r_[R, self.brain.cfg.r_head])
            gimbal = self.brain.gimbal_clearance(np.vstack([P, p[None, :]]) - self.center, np.r_[R, self.brain.cfg.r_head], plan=plan)
        else:
            links, static = np.inf, self.safety.static_clearance(p[None, :], [self.brain.cfg.r_head])
            gimbal = self.brain.gimbal_clearance((p - self.center)[None, :], [self.brain.cfg.r_head], plan=plan)
        height = p[2] - self.safety.min_tool_z
        return np.array([head, links, static, height, gimbal])

    def safe_step(self, q_from, q_to):
        """Limit the joint step, then verify with forward kinematics that nothing (magnet head,
        links) enters the hull envelope or touches the stand or table; shrink the step until it
        doesn't. If something is already too close, only steps that improve it are allowed."""
        q_to = self.safety.limit_step(q_from, q_to)
        c0 = self.clearances(q_from)
        for frac in (1.0, 0.5, 0.25, 0.1):
            q = q_from + frac * (q_to - q_from)
            c = self.clearances(q)
            ok = np.all((c >= 0) | (c >= c0 + 0.0002))
            if ok:
                return q
        return q_from

    def spot_axis(self, p_rel):
        """Magnet spin axis the brain will ask for at this spot (momentum, made perpendicular)."""
        est = self.brain.est
        if not est.init:
            return None
        H = effective_momentum(self.brain.cfg, est)
        d = p_rel / max(np.linalg.norm(p_rel), 1e-9)
        a = H - d * np.dot(H, d)
        if np.linalg.norm(a) < 0.2 * max(np.linalg.norm(H), 1e-12):
            return None
        return a / np.linalg.norm(a)

    def reachable(self, p_rel):
        """Can the arm put the magnet center at this spot, with the spin axis the brain will want,
        without any link entering the hull envelope or touching the stand? Full IK once per spot
        (and axis), then cached."""
        axis = self.spot_axis(p_rel)
        r = float(np.linalg.norm(p_rel))
        key = (tuple(np.round(p_rel / max(r, 1e-9), 3)), int(round(r / 0.005)), None if axis is None else tuple(np.round(axis, 1)))
        if key in self._reach and self.brain.cfg.gimbal is not None and self.t_prev is not None \
                and self.t_prev - self._reach_t.get(key, -1e9) > self.reach_recheck_s:
            del self._reach[key]                     # the gimbal moves: a reachability verdict goes stale
            self._goal_q.pop(key, None)
        if key not in self._reach:
            if self._ik_budget <= 0:
                return None                          # not checked yet (None, not False): try again next tick
            self._ik_budget -= 1
            self._reach_t[key] = self.t_prev if self.t_prev is not None else 0.0
            goal = self.center + p_rel
            if not self.safety.workspace_ok(goal):
                self._reach[key] = False
            else:
                q0 = self.q_cmd if self.q_cmd is not None else self.arm_io.read_joints()
                if self.jsp is not None:
                    # the arm must be able to stand 3 cm outside the spot with every link clear of the
                    # full-turn envelope (where the joint-space move ends), with either boom direction
                    p_pre = self.center + p_rel * (1 + 0.03 / max(r, 1e-9)) - self.bias
                    qg = self.goal_configuration(p_pre, axis, q0)
                    self._reach[key] = qg is not None
                    self._goal_q[key] = qg
                else:
                    ik = self.arm.ik(goal - self.bias, axis=axis, q0=q0, restarts=4, iters=150)
                    self._reach[key] = bool(ik.ok)
        return self._reach[key]

    def spot_goal_q(self, p_rel):
        axis = self.spot_axis(p_rel)
        r = float(np.linalg.norm(p_rel))
        key = (tuple(np.round(p_rel / max(r, 1e-9), 3)), int(round(r / 0.005)), None if axis is None else tuple(np.round(axis, 1)))
        return self._goal_q.get(key)

    def waypoint_ok(self, p_rel):
        """Cheap check for approach-path waypoints: inside the workspace, magnet clear of stand and table."""
        goal = self.center + p_rel
        if not self.safety.workspace_ok(goal):
            return False
        return self.safety.static_clearance(goal[None, :], [self.brain.cfg.r_head]) >= 0

    def _log(self, t, cmd, p_rel, ik, note):
        row = {"t": round(t, 4), "phase": cmd.phase, "locked": cmd.locked, "spin_est_dps": round(cmd.spin_dps, 3),
               "mag_x": p_rel[0], "mag_y": p_rel[1], "mag_z": p_rel[2], "rpm": round(cmd.motor_rpm, 1),
               "ik_err_mm": None if ik is None else round(1000 * ik.pos_err, 3),
               "axis_err_deg": None if ik is None else round(float(ik.axis_err_deg), 2), "note": note}
        self.last = row
        self.rows.append(row)

    def save_log(self, path=None):
        path = path or self.log_path
        if not path or not self.rows:
            return
        with open(path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(self.rows[0].keys()))
            w.writeheader()
            w.writerows(self.rows)
