"""Live camera -> poses, for the real rig. Produces the same dict SimWorld.read_camera() does."""
import time
import numpy as np

from .vision import ArucoPoseTracker, MarkerBody, load_intrinsics, cv2


class CameraPoseSource:
    def __init__(self, rig, intrinsics_path=None):
        if cv2 is None:
            raise RuntimeError("pip install opencv-contrib-python")
        cam = rig["camera"]
        K, dist, _ = load_intrinsics(intrinsics_path or cam["intrinsics_file"])
        self.cap = cv2.VideoCapture(cam.get("index", 0))
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam.get("width", 1280))
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam.get("height", 720))
        self.cap.set(cv2.CAP_PROP_FPS, cam.get("fps", 30))
        self.tracker = ArucoPoseTracker(K, dist, cam.get("aruco_dictionary", "DICT_4X4_50"))
        self.target = MarkerBody.from_config("target", rig["target_marker"])
        tm = rig["tool_marker"]
        if rig.get("tool_marker_face"):
            # marker block on the boom: faces given relative to the block center, which is the point reported
            self.tool = MarkerBody.from_config("tool", [{"id": f["id"], "size": f["size"], "xyz": f["xyz_in_block"],
                                                         "rpy_deg": f["rpy_deg"]} for f in rig["tool_marker_face"]])
        else:
            self.tool = MarkerBody.from_config("tool", [{"id": tm["id"], "size": tm["size"], "xyz": [0, 0, 0], "rpy_deg": [0, 0, 0]}])
        self.prev_target = None
        self.prev_tool = None
        self.last_image = None

    def read(self):
        ok, img = self.cap.read()
        t = time.monotonic()
        out = {"t": t, "T_cam_target": None, "p_cam_tool_marker": None, "n_target_markers": 0}
        if not ok:
            return out
        self.last_image = img
        det = self.tracker.detect(img)
        tp = self.tracker.body_pose(det, self.target, prior_T_cam_body=self.prev_target)
        if tp is not None and tp["reproj_px"] < 3.0:
            out["T_cam_target"] = tp["T_cam_body"]
            out["n_target_markers"] = tp["n_markers"]
            self.prev_target = tp["T_cam_body"]
        tl = self.tracker.body_pose(det, self.tool, prior_T_cam_body=self.prev_tool)
        if tl is not None and tl["reproj_px"] < 3.0:
            out["p_cam_tool_marker"] = tl["T_cam_body"][:3, 3]   # marker (block) center in the camera frame
            self.prev_tool = tl["T_cam_body"]
        return out

    def close(self):
        self.cap.release()
