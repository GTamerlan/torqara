"""Run the full real-world pipeline against SimWorld and summarize how it did."""
import numpy as np

from .frames import apply_T, inv_T
from .brain import Brain, BrainConfig
from .kinematics import Arm
from .mission import MissionRunner
from .safety import Safety
from .sim import SimWorld


def run_sim(arm_path, rig, seconds=40.0, seed=0, mode="spin", visual_correction=True, spin_dps=(5, 50, 5),
            joint_zero_error_deg=0.5, cam_rot_noise_deg=0.4, cam_pos_noise_m=0.001, verbose=False, record_every=0):
    """record_every > 0: keep every n-th tick of the true state (joints, target attitude, magnet spin)
    in result["trajectory"], e.g. to animate the CAD model."""
    arm = Arm.from_toml(arm_path)
    cfg = BrainConfig.from_rig(rig)
    world = SimWorld(rig, arm, cfg, seed=seed, spin_dps=spin_dps, joint_zero_error_deg=joint_zero_error_deg,
                     cam_rot_noise_deg=cam_rot_noise_deg, cam_pos_noise_m=cam_pos_noise_m)
    cal = world.run_calibration()
    brain = Brain(cfg, mode=mode)
    safety = Safety(rig, cfg, arm)
    runner = MissionRunner(arm, world.arm_io, world.motor, brain, safety, cal["T_base_cam"], cal["marker_in_tool"],
                           visual_correction=visual_correction)
    dt = 1 / 30
    t = 0.0
    brain_on = False
    pos_err = []
    gap_true = []
    t_detumble = None
    t_stable = None
    traj = []
    spin_angle = 0.0
    tick = 0
    while t < seconds:
        meas = world.read_camera()
        runner.step(t, meas)
        if not brain_on and t > 1.0:
            brain.set_auto(True)
            brain_on = True
        if brain.phase == "detumble" and t_detumble is None:
            t_detumble = t
        if brain.phase == "stable" and t_stable is None:
            t_stable = t
        if brain.phase in ("detumble", "stable") and brain.planner.best_spot() is not None:
            p_true, _ = world.true_magnet()
            p_believed = arm.fk(world.arm_io.q)[:3, 3] + runner.bias
            # how well the system knows where the magnet is RELATIVE to the target (what sets the gap)
            pos_err.append(np.linalg.norm((p_true - world.center) - (p_believed - runner.center)))
            if world.last_gap is not None:
                gap_true.append(world.last_gap)
        world.step(dt)
        spin_angle += world.motor.rpm / 60.0 * 360.0 * dt
        if record_every and tick % record_every == 0:
            traj.append({"t": round(t, 4), "q_deg": [round(float(v), 3) for v in np.degrees(world.arm_io.q)],
                         "target_quat": [round(float(v), 6) for v in world.q], "magnet_spin_deg": round(spin_angle % 360.0, 2),
                         "rpm": round(float(world.motor.rpm), 1), "phase": brain.phase, "spin_dps": round(world.spin_dps(), 3),
                         "gap_mm": round(1000 * float(world.gap_now), 1)})
        tick += 1
        t += dt
        if verbose and abs(t - round(t)) < dt / 2 and int(round(t)) % 5 == 0:
            print(f"t={t:5.1f}s phase={brain.phase:9s} true spin={world.spin_dps():6.2f} deg/s est={np.degrees(np.linalg.norm(brain.est.w)):6.2f} locked={brain.est.locked}")
    cal_err_mm = 1000 * np.linalg.norm(cal["T_base_cam"][:3, 3] - world.T_bc_true[:3, 3])
    return {
        "calibration_rms_mm": 1000 * cal["rms"],
        "camera_position_error_mm": cal_err_mm,
        "time_to_detumble_phase_s": t_detumble,
        "time_to_stable_s": t_stable,
        "detumble_duration_s": None if (t_stable is None or t_detumble is None) else t_stable - t_detumble,
        "final_true_spin_dps": world.spin_dps(),
        "magnet_position_error_mm_mean": None if not pos_err else 1000 * float(np.mean(pos_err)),
        "magnet_position_error_mm_p95": None if not pos_err else 1000 * float(np.percentile(pos_err, 95)),
        "min_true_gap_mm": 1000 * float(world.min_gap),
        "collisions": int(world.collisions),
        "link_contacts": int(world.link_contacts),
        "static_contacts": int(world.static_contacts),
        "gimbal_contacts": int(world.gimbal_contacts),
        "gimbal_events": world.gimbal_events[:40],
        "static_events": world.static_events[:40],
        "min_gimbal_gap_mm": 1000 * float(world.min_gimbal_gap) if np.isfinite(world.min_gimbal_gap) else None,
        "min_link_gap_mm": 1000 * float(world.min_link_gap) if np.isfinite(world.min_link_gap) else None,
        "max_tilt_deg": world.max_tilt_deg,
        "tool_marker_seen_frac": world.tool_seen_frac[0] / max(1, world.tool_seen_frac[1]),
        "events": brain.events,
        "log_rows": runner.rows,
        "trajectory": traj,
    }
