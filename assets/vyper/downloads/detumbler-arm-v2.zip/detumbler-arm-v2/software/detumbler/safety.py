"""Hard limits checked every control tick, before anything is sent to the motors."""
import numpy as np


class Safety:
    def __init__(self, rig, brain_cfg, arm):
        s = rig["safety"]
        self.ws_min = np.asarray(s["workspace_min"], float)
        self.ws_max = np.asarray(s["workspace_max"], float)
        self.min_tool_z = float(s["min_tool_z"])
        self.min_gap = float(s["min_gap"])
        self.max_step = np.radians(float(s["max_joint_step_deg"]))
        self.lost_lock_timeout = float(s["lost_lock_timeout"])
        self.cfg = brain_cfg
        self.arm = arm
        self.reach = arm.reach()
        self.base = arm.base[:3, 3]
        self.table_z = float(s.get("table_z", 0.0))
        self.link_table_clearance = float(s.get("link_table_clearance", 0.02))
        self.static_margin = float(s.get("static_margin", 0.01))
        st = rig.get("stand")
        # vertical cylinders the arm must never touch: (x, y, radius, z_bottom, z_top)
        self.cylinders = []
        if st:
            cx, cy = st["center_xy"]
            self.cylinders.append((cx, cy, st["post_radius"], 0.0, st["post_top_z"]))
            self.cylinders.append((cx, cy, st["base_radius"], 0.0, st["base_top_z"]))

    def static_clearance(self, P, R):
        """Smallest clearance [m] between spheres (points P with radii R) and the fixed obstacles:
        the target stand (post and base disc) and the table. Negative = touching."""
        P = np.atleast_2d(P)
        R = np.broadcast_to(np.asarray(R, float), (len(P),))
        c = P[:, 2] - R - self.table_z - self.link_table_clearance + self.static_margin
        best = float(np.min(c)) if len(P) else np.inf
        for (x, y, r, z0, z1) in self.cylinders:
            dxy = np.hypot(P[:, 0] - x, P[:, 1] - y) - r
            dz = np.maximum(z0 - P[:, 2], P[:, 2] - z1)
            out = np.where(dz > 0, np.hypot(np.maximum(dxy, 0), dz), dxy)    # distance to the solid cylinder
            best = min(best, float(np.min(out - R)))
        return best - self.static_margin

    def keepout_ok(self, p_base, center_base):
        """Magnet surface stays outside the sphere the tumbling target can sweep."""
        r = np.linalg.norm(np.asarray(p_base) - np.asarray(center_base))
        return r >= self.cfg.r_keepout + self.cfg.r_head - 1e-4

    def workspace_ok(self, p_base):
        p = np.asarray(p_base)
        if np.any(p < self.ws_min) or np.any(p > self.ws_max) or p[2] < self.min_tool_z:
            return False
        dist = np.linalg.norm(p - self.base)
        return 0.12 < dist < 0.92 * self.reach

    def goal_ok(self, p_base, center_base):
        if not self.workspace_ok(p_base):
            return False, "outside workspace"
        if not self.keepout_ok(p_base, center_base):
            return False, "inside keep-out zone"
        return True, ""

    def limit_step(self, q_now, q_new):
        dq = np.clip(np.asarray(q_new) - q_now, -self.max_step, self.max_step)
        return self.arm.clamp(q_now + dq)
