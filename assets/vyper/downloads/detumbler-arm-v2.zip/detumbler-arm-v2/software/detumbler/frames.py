"""Rotation and rigid-transform utilities.

Conventions used everywhere in this package
- Quaternions are [w, x, y, z] and rotate body vectors into the parent frame.
- A transform T_A_B is a 4x4 matrix that maps points written in frame B into frame A:
      p_A = T_A_B @ [p_B, 1]
  so T_A_C = T_A_B @ T_B_C, and inv_T(T_A_B) == T_B_A.
- Units: meters, radians, seconds. Degrees only appear in config files and printouts.
"""
import numpy as np


def qnorm(q):
    q = np.asarray(q, float)
    return q / np.linalg.norm(q)


def qmul(a, b):
    aw, ax, ay, az = a
    bw, bx, by, bz = b
    return np.array([
        aw * bw - ax * bx - ay * by - az * bz,
        aw * bx + ax * bw + ay * bz - az * by,
        aw * by - ax * bz + ay * bw + az * bx,
        aw * bz + ax * by - ay * bx + az * bw,
    ])


def qconj(q):
    return np.array([q[0], -q[1], -q[2], -q[3]])


def qrot(q, v):
    """Rotate vector v (body) into the parent frame."""
    u = np.asarray(q[1:], float)
    v = np.asarray(v, float)
    t = 2.0 * np.cross(u, v)
    return v + q[0] * t + np.cross(u, t)


def qrot_inv(q, v):
    return qrot(qconj(q), v)


def qexp(rv):
    """Rotation vector (axis * angle) to quaternion."""
    rv = np.asarray(rv, float)
    a = np.linalg.norm(rv)
    if a < 1e-12:
        return qnorm(np.r_[1.0, rv / 2.0])
    return np.r_[np.cos(a / 2.0), np.sin(a / 2.0) * rv / a]


def qlog(q):
    """Quaternion to rotation vector (shortest rotation)."""
    q = qnorm(q)
    if q[0] < 0:
        q = -q
    v = q[1:]
    s = np.linalg.norm(v)
    if s < 1e-12:
        return 2.0 * v
    return 2.0 * np.arctan2(s, q[0]) * v / s


def R_from_quat(q):
    w, x, y, z = qnorm(q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - w * z), 2 * (x * z + w * y)],
        [2 * (x * y + w * z), 1 - 2 * (x * x + z * z), 2 * (y * z - w * x)],
        [2 * (x * z - w * y), 2 * (y * z + w * x), 1 - 2 * (x * x + y * y)],
    ])


def quat_from_R(R):
    """Shepperd's method, numerically stable for every rotation."""
    R = np.asarray(R, float)
    tr = np.trace(R)
    if tr > 0:
        s = 2.0 * np.sqrt(tr + 1.0)
        q = [0.25 * s, (R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s]
    elif R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
        q = [(R[2, 1] - R[1, 2]) / s, 0.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s]
    elif R[1, 1] > R[2, 2]:
        s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
        q = [(R[0, 2] - R[2, 0]) / s, (R[0, 1] + R[1, 0]) / s, 0.25 * s, (R[1, 2] + R[2, 1]) / s]
    else:
        s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
        q = [(R[1, 0] - R[0, 1]) / s, (R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, 0.25 * s]
    q = qnorm(q)
    return q if q[0] >= 0 else -q


def R_from_rotvec(rv):
    return R_from_quat(qexp(rv))


def rotvec_from_R(R):
    return qlog(quat_from_R(R))


def rot_x(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def rot_y(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def rot_z(a):
    c, s = np.cos(a), np.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def rpy_R(roll, pitch, yaw):
    """Fixed-axis roll (x), then pitch (y), then yaw (z): R = Rz(yaw) Ry(pitch) Rx(roll)."""
    return rot_z(yaw) @ rot_y(pitch) @ rot_x(roll)


def make_T(R=None, t=None):
    T = np.eye(4)
    if R is not None:
        T[:3, :3] = R
    if t is not None:
        T[:3, 3] = t
    return T


def T_from_xyz_rpy(xyz, rpy_deg):
    return make_T(rpy_R(*np.radians(rpy_deg)), np.asarray(xyz, float))


def inv_T(T):
    R, t = T[:3, :3], T[:3, 3]
    return make_T(R.T, -R.T @ t)


def apply_T(T, p):
    """Transform one point (3,) or many points (N, 3)."""
    p = np.asarray(p, float)
    return p @ T[:3, :3].T + T[:3, 3]


def rotation_angle_deg(R1, R2):
    """Angle of the rotation that takes R1 to R2."""
    c = (np.trace(R1.T @ R2) - 1.0) / 2.0
    return float(np.degrees(np.arccos(np.clip(c, -1.0, 1.0))))


def quat_mean(qs, weights=None):
    """Average of unit quaternions (Markley et al.), robust to the q / -q sign ambiguity."""
    qs = np.asarray(qs, float)
    w = np.ones(len(qs)) if weights is None else np.asarray(weights, float)
    M = (qs * w[:, None]).T @ qs
    vals, vecs = np.linalg.eigh(M)
    q = vecs[:, np.argmax(vals)]
    return q if q[0] >= 0 else -q


def unit(v):
    v = np.asarray(v, float)
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else np.zeros_like(v)


def any_perpendicular(v):
    v = unit(v)
    a = np.array([1.0, 0.0, 0.0]) if abs(v[0]) < 0.9 else np.array([0.0, 1.0, 0.0])
    return unit(np.cross(v, a))
