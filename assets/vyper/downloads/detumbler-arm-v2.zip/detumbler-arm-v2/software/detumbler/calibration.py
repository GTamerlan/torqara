"""Calibration math: tie the camera, the arm and the magnet into one coordinate system.

Three calibrations, done once per setup (and again whenever the camera or arm moves):
1. Camera intrinsics (lens): tools/calibrate_camera.py, uses OpenCV.
2. Camera -> robot base (`fit_camera_to_base`): move the arm to ~20 poses with a marker on
   the tool; the camera measures the marker, forward kinematics says where the tool is.
   Solves the camera pose in the robot base frame AND the marker's offset on the tool.
3. Tool center point (`pivot_calibration`, optional): touch one fixed point from many
   orientations to measure exactly where the magnet center sits on the flange.
"""
import json
import numpy as np

from .frames import make_T, inv_T, apply_T


def fit_rigid(A, B, weights=None):
    """Best rotation R and translation t with R @ A_i + t ≈ B_i (Kabsch / Umeyama, no scale).

    A, B: (N, 3). Returns (T_B_A as 4x4, rms residual in meters, per-point residuals).
    """
    A = np.asarray(A, float)
    B = np.asarray(B, float)
    w = np.ones(len(A)) if weights is None else np.asarray(weights, float)
    w = w / w.sum()
    ca = (w[:, None] * A).sum(0)
    cb = (w[:, None] * B).sum(0)
    H = ((A - ca) * w[:, None]).T @ (B - cb)
    U, _, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    t = cb - R @ ca
    T = make_T(R, t)
    res = np.linalg.norm(apply_T(T, A) - B, axis=1)
    return T, float(np.sqrt(np.mean(res ** 2))), res


def fit_camera_to_base(T_base_tool_list, p_cam, marker_in_tool0=None, iters=200, tol=1e-9):
    """Solve where the camera is (T_base_cam) and where the tool marker sits (in the tool frame).

    T_base_tool_list: forward-kinematics tool poses for each calibration pose (list of 4x4).
    p_cam: (N, 3) marker centers measured by the camera in the camera frame.
    marker_in_tool0: starting guess for the marker offset (from CAD), default zeros.

    Alternates two exact sub-problems until it converges:
      a) with the marker offset fixed, the camera pose is a rigid point fit (Kabsch);
      b) with the camera pose fixed, the marker offset is linear least squares.
    The offset is only observable if the tool ROTATES between poses, so vary the wrist.
    """
    Ts = [np.asarray(T, float) for T in T_base_tool_list]
    p_cam = np.asarray(p_cam, float)
    m = np.zeros(3) if marker_in_tool0 is None else np.asarray(marker_in_tool0, float)
    Rs = np.array([T[:3, :3] for T in Ts])
    ts = np.array([T[:3, 3] for T in Ts])
    A = Rs.reshape(-1, 3)
    cond = np.linalg.cond(A)
    prev = None
    for _ in range(iters):
        P_base = np.einsum("nij,j->ni", Rs, m) + ts
        T_bc, rms, res = fit_rigid(p_cam, P_base)
        meas_base = apply_T(T_bc, p_cam)
        m, *_ = np.linalg.lstsq(A, (meas_base - ts).reshape(-1), rcond=None)
        if prev is not None and abs(prev - rms) < tol:
            break
        prev = rms
    P_base = np.einsum("nij,j->ni", Rs, m) + ts
    T_bc, rms, res = fit_rigid(p_cam, P_base)
    return {"T_base_cam": T_bc, "marker_in_tool": m, "rms": rms, "residuals": res, "rotation_conditioning": float(cond)}


def pivot_calibration(T_base_flange_list):
    """Tool-tip offset from poses that all touch the same fixed point.

    Solves R_i @ m + t_i = p for m (tip in flange frame) and p (pivot in base frame).
    Returns (m, p, rms).
    """
    Ts = [np.asarray(T, float) for T in T_base_flange_list]
    A = np.vstack([np.hstack([T[:3, :3], -np.eye(3)]) for T in Ts])
    b = np.hstack([-T[:3, 3] for T in Ts])
    x, *_ = np.linalg.lstsq(A, b, rcond=None)
    m, p = x[:3], x[3:]
    res = np.array([np.linalg.norm(T[:3, :3] @ m + T[:3, 3] - p) for T in Ts])
    return m, p, float(np.sqrt(np.mean(res ** 2)))


def error_stats(err_vectors):
    """Summary of position errors (N, 3) in meters -> dict in millimeters."""
    e = np.asarray(err_vectors, float)
    n = np.linalg.norm(e, axis=1)
    return {
        "count": int(len(n)),
        "mean_mm": float(1000 * n.mean()),
        "rms_mm": float(1000 * np.sqrt((n ** 2).mean())),
        "p95_mm": float(1000 * np.percentile(n, 95)),
        "max_mm": float(1000 * n.max()),
        "bias_mm": [float(1000 * x) for x in e.mean(0)],
    }


def save_json(path, data):
    def conv(o):
        if isinstance(o, np.ndarray):
            return o.tolist()
        if isinstance(o, (np.floating, np.integer)):
            return o.item()
        raise TypeError(type(o))
    with open(path, "w") as f:
        json.dump(data, f, indent=2, default=conv)


def load_camera_to_base(path):
    with open(path) as f:
        d = json.load(f)
    return np.asarray(d["T_base_cam"], float), np.asarray(d["marker_in_tool"], float)
