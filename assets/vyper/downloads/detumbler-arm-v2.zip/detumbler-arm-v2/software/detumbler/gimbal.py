"""External three-axis gimbal around the target: moving obstacles the arm must stay clear of.

The hull rolls on two pins along its body x axis; the pins run in bearings on a ring; the ring pitches on two
pins held by a U-yoke; the yoke yaws on a vertical shaft. So, for a hull attitude R (world <- body):
    xb = R[:, 0]                      roll axis (pins), moves with the hull
    p  = unit(z_world x xb)           pitch axis, horizontal, fixed to the yoke (yoke yaw follows the hull)
    n  = unit(xb x p)                 normal of the ring plane (the ring contains xb and p)
Everything here is expressed relative to the target center, in world (robot base) axes, meters.
Geometry is approximated by capsules: pins (with their hubs), the ring (a polygon of capsules), the yoke arms
and the yoke's bottom bar. All free to turn without limit, so the parts can be anywhere the hull sends them.
"""
import numpy as np

Z = np.array([0.0, 0.0, 1.0])


def unit(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-12 else v


class ExternalGimbal:
    def __init__(self, cfg):
        self.ring_r = float(cfg["ring_radius"])            # mean ring radius [m]
        self.ring_tube = float(cfg["ring_tube"])           # ring cross-section radius incl. bearing blocks [m]
        self.pin_r0 = float(cfg["pin_r0"])                 # pins + hubs: from this radius along +-xb ...
        self.pin_r1 = float(cfg["pin_r1"])                 # ... to this radius (into the ring blocks)
        self.pin_radius = float(cfg["pin_radius"])
        self.arm_offset = float(cfg["arm_offset"])         # yoke arms at +- this along p
        self.arm_radius = float(cfg["arm_radius"])
        self.arm_z = [float(v) for v in cfg["arm_z"]]      # yoke arm extent along z (relative to center)
        self.bar_z = float(cfg["bar_z"])
        self.bar_radius = float(cfg["bar_radius"])
        self.n_ring = int(cfg.get("ring_segments", 24))
        self.lock_cos = float(np.cos(np.radians(cfg.get("yoke_lock_deg", 50.0))))   # roll axis this close to vertical -> fence
        self._p_last = np.array([0.0, 1.0, 0.0])

    def frame(self, R):
        xb = unit(R[:, 0])
        c = np.cross(Z, xb)
        if np.linalg.norm(c) < 0.05:          # roll axis nearly vertical: yaw and roll coincide, keep the last pitch axis
            p = self._p_last
        else:
            p = unit(c)
            if np.dot(p, self._p_last) < 0:
                p = -p                         # the yoke does not flip: keep continuity
            self._p_last = p
        n = unit(np.cross(xb, p))
        return xb, p, n

    def capsules(self, R, exact=False):
        """List of (p0, p1, radius) relative to the target center, world axes. exact=True: the geometry as it is
        (for the simulator's truth); False: the conservative version used for planning."""
        xb, p, n = self.frame(R)
        caps = []
        for s in (-1.0, 1.0):
            caps.append((s * xb * self.pin_r0, s * xb * self.pin_r1, self.pin_radius))
        ang = np.linspace(0, 2 * np.pi, self.n_ring, endpoint=False)
        pts = [self.ring_r * (np.cos(a) * xb + np.sin(a) * p) for a in ang]
        for i in range(self.n_ring):
            caps.append((pts[i], pts[(i + 1) % self.n_ring], self.ring_tube))
        if abs(xb[2]) > self.lock_cos and not exact:
            # roll axis near vertical: the yoke's yaw is ill-defined and swings fast with small hull motions, so for
            # planning the yoke is a fence of arms all around (what it could be anywhere within the horizon)
            for a in np.linspace(0, 2 * np.pi, 12, endpoint=False):
                base = self.arm_offset * (np.cos(a) * np.array([1.0, 0, 0]) + np.sin(a) * np.array([0, 1.0, 0]))
                caps.append((base + Z * self.arm_z[0], base + Z * self.arm_z[1], self.arm_radius))
        else:
            for s in (-1.0, 1.0):
                base = s * p * self.arm_offset
                caps.append((base + Z * self.arm_z[0], base + Z * self.arm_z[1], self.arm_radius))
        caps.append((-p * self.arm_offset + Z * self.bar_z, p * self.arm_offset + Z * self.bar_z, self.bar_radius))
        return caps

    def capsule_arrays(self, R, exact=False):
        caps = self.capsules(R, exact)
        A = np.array([c[0] for c in caps])
        B = np.array([c[1] for c in caps])
        r = np.array([c[2] for c in caps])
        return A, B, r

    # ------------------------------------------------------------------ distances
    @staticmethod
    def point_segment_dist(P, A, B):
        """P (n,3) points, A/B (m,3) segment ends -> (n,m) distances."""
        AB = B - A                                   # (m,3)
        L2 = np.maximum(np.sum(AB * AB, axis=1), 1e-12)
        AP = P[:, None, :] - A[None, :, :]           # (n,m,3)
        t = np.clip(np.sum(AP * AB[None, :, :], axis=2) / L2[None, :], 0.0, 1.0)
        C = A[None, :, :] + t[:, :, None] * AB[None, :, :]
        return np.linalg.norm(P[:, None, :] - C, axis=2)

    @staticmethod
    def segment_segment_dist(P0, P1, A, B):
        """P0/P1 (n,3) segments vs A/B (m,3) segments -> (n,m) distances (Ericson, vectorized)."""
        d1 = (P1 - P0)[:, None, :]                   # (n,1,3)
        d2 = (B - A)[None, :, :]                     # (1,m,3)
        r = P0[:, None, :] - A[None, :, :]           # (n,m,3)
        a = np.sum(d1 * d1, axis=2)
        e = np.sum(d2 * d2, axis=2)
        f = np.sum(d2 * r, axis=2)
        c = np.sum(d1 * r, axis=2)
        b = np.sum(d1 * d2, axis=2)
        denom = a * e - b * b
        s = np.where(denom > 1e-12, np.clip((b * f - c * e) / np.where(denom > 1e-12, denom, 1.0), 0, 1), 0.0)
        t = (b * s + f) / np.maximum(e, 1e-12)
        s = np.where(t < 0, np.clip(-c / np.maximum(a, 1e-12), 0, 1), s)
        s = np.where(t > 1, np.clip((b - c) / np.maximum(a, 1e-12), 0, 1), s)
        t = np.clip(t, 0, 1)
        C1 = P0[:, None, :] + s[:, :, None] * d1
        C2 = A[None, :, :] + t[:, :, None] * d2
        return np.linalg.norm(C1 - C2, axis=2)

    def near_lock(self, R):
        """Roll axis close to vertical: the ring's plane (and the yoke's yaw) are poorly determined by the hull
        attitude and swing fast, so for planning the ring is taken as the whole spherical shell it could be in."""
        return abs(unit(R[:, 0])[2]) > self.lock_cos

    def shell_dist(self, P):
        """Distance from points (relative to the center) to the spherical shell the ring sweeps near gimbal lock."""
        return np.abs(np.linalg.norm(P, axis=-1) - self.ring_r) - self.ring_tube

    def sphere_clearance(self, P_rel, radii, R_list):
        """Smallest clearance of spheres (points relative to the center, radii) from the gimbal over a list of
        attitudes. Negative = touching."""
        P_rel = np.atleast_2d(P_rel)
        if len(P_rel) == 0:
            return np.inf
        radii = np.broadcast_to(np.asarray(radii, float), (len(P_rel),))
        best = np.inf
        for R in R_list:
            A, B, r = self.capsule_arrays(R)
            d = self.point_segment_dist(P_rel, A, B) - r[None, :] - radii[:, None]
            best = min(best, float(d.min()))
            if self.near_lock(R):
                best = min(best, float(np.min(self.shell_dist(P_rel) - radii)))
        return best

    def shell_segment_dist(self, P0, P1, n=7):
        """Approximate distance of segments to the shell: sampled points along each segment."""
        ts = np.linspace(0, 1, n)
        pts = P0[:, None, :] + ts[None, :, None] * (P1 - P0)[:, None, :]     # (m, n, 3)
        return self.shell_dist(pts).min(axis=1)

    def head_clearance(self, centers, axes, head_half, head_r, boom_len, boom_r, R_list):
        """For n candidate magnet placements (centers relative to the target center, spin axes), the clearance
        of the head capsule (center +- head_half along the axis) and the boom capsule (from the head end to
        boom_len along the axis, radius boom_r) from the gimbal, over the attitudes in R_list. The boom can
        point either way along the axis; the better sign counts. Returns (clearance (n,), sign (n,))."""
        centers = np.atleast_2d(centers)
        axes = np.atleast_2d(axes)
        n = len(centers)
        best_sign = np.ones(n)
        best_clear = np.full(n, -np.inf)
        head_clear = np.full(n, np.inf)
        locked = [self.near_lock(R) for R in R_list]
        for R, lk in zip(R_list, locked):
            A, B, r = self.capsule_arrays(R)
            hd = self.segment_segment_dist(centers - axes * head_half, centers + axes * head_half, A, B) - r[None, :] - head_r
            head_clear = np.minimum(head_clear, hd.min(axis=1))
            if lk:
                head_clear = np.minimum(head_clear, self.shell_segment_dist(centers - axes * head_half, centers + axes * head_half) - head_r)
        for sign in (1.0, -1.0):
            cl = head_clear.copy()
            for R, lk in zip(R_list, locked):
                A, B, r = self.capsule_arrays(R)
                bd = self.segment_segment_dist(centers + sign * axes * head_half, centers + sign * axes * boom_len, A, B) - r[None, :] - boom_r
                cl = np.minimum(cl, bd.min(axis=1))
                if lk:
                    cl = np.minimum(cl, self.shell_segment_dist(centers + sign * axes * head_half, centers + sign * axes * boom_len) - boom_r)
            better = cl > best_clear
            best_clear = np.where(better, cl, best_clear)
            best_sign = np.where(better, sign, best_sign)
        return best_clear, best_sign
