"""Joint-space motion planning (RRT-Connect) with collision checking.

Used for the big moves: from wherever the arm is to a new magnet spot. Steering the magnet
through Cartesian waypoints is fine for small corrections, but a 5-axis arm has no spare
freedom once position and spin axis are fixed, so on long moves it can walk a joint into its
limit and stall. Planning in joint space finds a whole collision-free path first.

Validity of a configuration = every clearance from MissionRunner.clearances() is positive:
the magnet head and every link outside the target's envelope, nothing touching the stand or
the table. The envelope is frozen for the duration of one plan (it changes slowly), and the
executed path is still checked step by step against the live envelope.
"""
import numpy as np


class JointPlanner:
    def __init__(self, arm, valid, rng=None, weights=None, step_deg=8.0, check_deg=3.0):
        self.arm = arm
        self.valid = valid                       # q -> bool
        self.rng = np.random.default_rng(0) if rng is None else rng
        n = arm.n
        self.w = np.ones(n) if weights is None else np.asarray(weights, float)
        self.step = np.radians(step_deg)
        self.check = np.radians(check_deg)
        self.checks = 0

    def dist(self, a, b):
        return float(np.sqrt(np.sum((self.w * (a - b)) ** 2)))

    def edge_ok(self, a, b):
        n = int(np.ceil(np.max(np.abs(b - a)) / self.check))
        for i in range(1, n + 1):
            self.checks += 1
            if not self.valid(a + (b - a) * i / n):
                return False
        return True

    def steer(self, a, b):
        d = self.dist(a, b)
        return b.copy() if d <= self.step else a + (b - a) * self.step / d

    def plan(self, q_start, q_goal, max_iter=500, max_checks=4000):
        """Returns a list of joint vectors from q_start to q_goal, or None."""
        q_start, q_goal = np.asarray(q_start, float), np.asarray(q_goal, float)
        self.checks = 0
        if not self.valid(q_goal):
            return None
        if self.edge_ok(q_start, q_goal):
            return [q_start, q_goal]
        A, pa = [q_start], [-1]
        B, pb = [q_goal], [-1]
        lo, hi = self.arm.lower, self.arm.upper
        for it in range(max_iter):
            if self.checks > max_checks:
                return None
            q_rand = q_goal if self.rng.random() < 0.1 else self.rng.uniform(lo, hi)
            ia = min(range(len(A)), key=lambda i: self.dist(A[i], q_rand))
            q_new = self.steer(A[ia], q_rand)
            if not self.edge_ok(A[ia], q_new):
                A, pa, B, pb = B, pb, A, pa
                continue
            A.append(q_new)
            pa.append(ia)
            # greedily connect the other tree to q_new
            while True:
                ib = min(range(len(B)), key=lambda i: self.dist(B[i], q_new))
                q_b = self.steer(B[ib], q_new)
                if not self.edge_ok(B[ib], q_b):
                    break
                B.append(q_b)
                pb.append(ib)
                if self.dist(q_b, q_new) < 1e-6:
                    path_a = self._trace(A, pa, len(A) - 1)
                    path_b = self._trace(B, pb, len(B) - 1)
                    path = path_a[::-1] + path_b[1:]
                    if np.allclose(path[0], q_goal):          # trees were swapped
                        path = path[::-1]
                    return self.shortcut(path)
            A, pa, B, pb = B, pb, A, pa
        return None

    @staticmethod
    def _trace(T, par, i):
        out = []
        while i != -1:
            out.append(T[i])
            i = par[i]
        return out

    def shortcut(self, path, tries=40):
        path = list(path)
        for _ in range(tries):
            if len(path) <= 2:
                break
            i, j = sorted(self.rng.choice(len(path), 2, replace=False))
            if j - i < 2:
                continue
            if self.edge_ok(path[i], path[j]):
                path = path[:i + 1] + path[j:]
        return path
