"""The autonomy: estimate the tumble, decide where the magnet goes, and how to spin it.

This is a line-for-line port of the browser simulator's brain (simulator/core.js), with all
geometry and physics read from the rig config instead of hard-coded.

Frames used here
- "Target-centered frame": origin at the target's center of mass, axes PARALLEL to the
  robot base frame. Magnet positions handed to/from the brain (p_rel) are in this frame.
- Target body frame: fixed to the target. q (quaternion) rotates body -> base axes.
"""
from dataclasses import dataclass, field
import tomllib
import numpy as np

from .frames import qmul, qconj, qnorm, qrot, qrot_inv, qexp, unit, any_perpendicular, R_from_quat


@dataclass
class BrainConfig:
    half_extents: np.ndarray            # target box half sizes [m]
    inertia_est: np.ndarray = None      # principal inertia estimate [kg m^2]; None = constant-rate model
    mag_radius: float = 0.02            # magnet cylinder radius [m] (physics)
    head_radius: float = 0.0            # collision radius of the magnet head incl. its guard [m]; 0 = magnet radius
    stand_cone_deg: float = 0.0         # never plan spots within this angle of straight down (target stand) [deg]
    pole_dot: float = 0.0               # >0: skip spots with |d . H_hat| above this (spin axis ill-defined there)
    gimbal_axis: np.ndarray = None      # gimbal rig: the tilt-limited mount's vertical axis (world)
    equator_dot: float = 1.0            # gimbal rig: only spots with |d . gimbal_axis| below this (brake at the
                                        # box's center height, so the force can't tip it onto its stop)
    tilt_penalty: float = 0.0           # gimbal rig: discount spots whose torque would tip the box (per unit sideways impulse)
    js_far: float = 0.045               # moves longer than this go through the joint-space planner [m]
    spin_axis_tol_deg: float = 45.0     # spin the magnet only when its axis is this close to the commanded one
                                        # (the speed is computed for the actual axis, so any value is dissipative)
    field_length: float = 0.03          # field falloff length a in B(g) = B0 (a/(a+g))^3 [m]
    k: float = 1.0                      # eddy coefficient c*sigma*delta*A*B0^2 [N s/m]
    sweep_max: float = 1.0              # max field sweep speed at the magnet surface [m/s]
    sweep_gain: float = 2.5             # G: sweep at up to G x hull speed
    sweep_tau: float = 0.12             # sweep speed smoothing [s]
    cam_sigma_deg: float = 0.5          # expected attitude noise per fix, sets lock thresholds
    alpha: float = 0.2                  # filter attitude gain
    beta: float = 0.02                  # filter rate gain
    gate_deg: float = 25.0              # reject a fix this far from prediction while locked
    horizon: float = 1.5                # planner look-ahead [s]
    plan_horizon_max: float = 6.0       # longest planner look-ahead [s]; slow tumbles need tens of seconds
    min_dwell_s: float = 0.0            # once the magnet has arrived at a spot, keep it there at least this long [s]
    pred_n: int = 24
    travel_scale: float = 0.9           # rad; spots this far around the target score e^-1 as well
    switch_ratio: float = 1.25          # a new spot must score this much better to switch
    close_dps: float = 120.0            # above this tumble rate, always use the worst-case sphere
    close_gap: float = 0.006            # gap kept from the PREDICTED swept hull [m]
    close_gap_per_dps: float = 0.00015  # extra gap per deg/s of tumble, covers estimate errors [m]
    close_horizon: float = 1.5          # minimum prediction window for the swept volume [s]
    envelope_max_horizon: float = 8.0   # predict at most this far (about one full turn) [s]
    safety_horizon: float = 1.0         # the arm must never be inside where the hull can be within this [s]
    safety_gap: float = 0.003           # minimum clearance to the conservative safety envelope [m]
    rate_noise_dps: float = 0.5         # 1-sigma noise of the rate estimate (sets axis uncertainty)
    attitude_noise_deg: float = 0.5     # 1-sigma noise of the attitude estimate
    retreat_speed: float = 0.15         # how fast the magnet backs out if it finds itself too close [m/s]
    transit_gap: float = 0.03           # orbit this far outside the envelope while moving to a new spot [m]
    n_dirs: int = 260
    keepout_margin: float = 0.006       # added to the target's bounding sphere [m]
    standoff: float = 0.004             # extra clearance between keep-out sphere and magnet [m]
    stable_dps: float = 0.6
    restart_dps: float = 1.5
    plan_period: float = 0.4
    approach_speed: float = 0.08        # magnet speed along the approach path [m/s]
    approach_rate_dps: float = 40.0     # angular speed around the target [deg/s]
    min_reach_dot: float = -0.15        # reject spots facing away from the robot more than this
    reach_dir: np.ndarray = field(default_factory=lambda: np.array([1.0, 0.0, 0.0]))  # target -> robot base, unit
    gimbal: object = None               # external gimbal (detumbler.gimbal.ExternalGimbal) or None
    head_half: float = 0.0              # half length of the magnet head capsule along its spin axis [m]
    boom_len: float = 0.3               # head center -> wrist, along the spin axis [m]
    boom_r: float = 0.035               # boom radius [m]
    gimbal_margin: float = 0.012        # clearance the head and boom keep from the gimbal when a spot is planned [m]
    ring_side_dot: float = 0.0          # >0: spots only within acos(this) of the ring normal (work over the ring, not through it)

    @property
    def r_keepout(self):
        return float(np.linalg.norm(self.half_extents)) + self.keepout_margin

    @property
    def r_head(self):
        return self.head_radius if self.head_radius > 0 else self.mag_radius

    @property
    def r_magnet(self):
        """Distance from target center to magnet center when parked on the keep-out sphere."""
        return self.r_keepout + self.r_head + self.standoff

    @classmethod
    def from_rig(cls, rig):
        t, m, b = rig["target"], rig["magnet"], rig["brain"]
        g = rig.get("gimbal")
        gimbal = None
        if g and g.get("type") == "external_3axis":
            from .gimbal import ExternalGimbal
            gimbal = ExternalGimbal(g)
        k = m.get("k_override") or (m["shape_factor"] * t["conductivity"] * t["wall_thickness"] *
                                    np.pi * m["radius"] ** 2 * m["surface_field_T"] ** 2)
        inertia = t.get("inertia_est")
        return cls(
            half_extents=np.asarray(t["half_extents"], float),
            inertia_est=None if not inertia else np.asarray(inertia, float),
            mag_radius=m["radius"], field_length=m.get("field_length", m["radius"] * 1.5), k=float(k),
            head_radius=m.get("head_radius", 0.0), stand_cone_deg=rig.get("stand", {}).get("planner_cone_deg", 0.0),
            close_gap=b.get("close_gap", 0.006), close_gap_per_dps=b.get("close_gap_per_dps", 0.00015),
            envelope_max_horizon=b.get("envelope_max_horizon", 8.0), safety_horizon=b.get("safety_horizon", 1.0),
            rate_noise_dps=b.get("rate_noise_dps", 0.5), attitude_noise_deg=b.get("attitude_noise_deg", 0.5),
            retreat_speed=b.get("retreat_speed", 0.15), close_dps=b.get("close_dps", 120.0),
            switch_ratio=b.get("switch_ratio", 1.25), travel_scale=b.get("travel_scale", 0.9),
            pole_dot=b.get("pole_dot", 0.0), tilt_penalty=b.get("tilt_penalty", 0.0),
            js_far=b.get("js_far", 0.045), spin_axis_tol_deg=b.get("spin_axis_tol_deg", 45.0),
            gimbal_axis=None if not b.get("gimbal_axis") else unit(np.asarray(b["gimbal_axis"], float)),
            equator_dot=b.get("equator_dot", 1.0),
            sweep_max=m["sweep_max"], sweep_gain=m["sweep_gain"],
            cam_sigma_deg=b.get("cam_sigma_deg", 0.5), alpha=b.get("alpha", 0.2), beta=b.get("beta", 0.02),
            horizon=b.get("horizon", 1.5), n_dirs=b.get("n_dirs", 260),
            plan_horizon_max=b.get("plan_horizon_max", 6.0), min_dwell_s=b.get("min_dwell_s", 0.0),
            keepout_margin=b.get("keepout_margin", 0.006), standoff=b.get("standoff", 0.004),
            stable_dps=b.get("stable_dps", 0.6), restart_dps=b.get("restart_dps", 1.5),
            approach_speed=b.get("approach_speed", 0.08), approach_rate_dps=b.get("approach_rate_dps", 40.0),
            gimbal=gimbal, head_half=m.get("head_half_length", 0.0), boom_len=m.get("boom_length", 0.3),
            boom_r=m.get("boom_radius", 0.035), gimbal_margin=(g or {}).get("plan_margin", 0.012),
            ring_side_dot=(g or {}).get("ring_side_dot", 0.0),
        )


def effective_momentum(cfg, est):
    """The momentum the magnet works on (all of it)."""
    return est.momentum()


def load_rig(path):
    with open(path, "rb") as f:
        return tomllib.load(f)


def fibonacci_dirs(n):
    i = np.arange(n) + 0.5
    y = 1 - 2 * i / n
    r = np.sqrt(1 - y * y)
    th = np.pi * (3 - np.sqrt(5)) * np.arange(n)
    return np.stack([r * np.cos(th), y, r * np.sin(th)], axis=1)


def euler_rate(I, w, tau):
    return np.array([
        ((I[1] - I[2]) * w[1] * w[2] + tau[0]) / I[0],
        ((I[2] - I[0]) * w[2] * w[0] + tau[1]) / I[1],
        ((I[0] - I[1]) * w[0] * w[1] + tau[2]) / I[2],
    ])


def eddy_patch(cfg, q, w, p_rel, vf_body=None, sweep=False):
    """Eddy braking on the hull patch nearest the magnet.

    q, w: target attitude and body rates. p_rel: magnet center (target-centered frame).
    vf_body: field sweep velocity in body axes, OR sweep=True to use the ideal control law
    (sweep against the local hull motion at up to G x its speed), as the planner does.
    Returns dict with body torque tb, force Fb, patch point rp, unit normal e, gap g, heat P.
    """
    h = cfg.half_extents
    pb = qrot_inv(q, p_rel)
    rp = np.clip(pb, -h, h)
    d = pb - rp
    dist = np.linalg.norm(d)
    if dist < 1e-9:
        return None
    e = d / dist
    g = max(0.0005, dist - cfg.mag_radius)
    B2 = (cfg.field_length / (cfg.field_length + g)) ** 6
    v = np.cross(w, rp)
    vt = v - e * np.dot(v, e)
    if vf_body is None:
        if sweep and np.linalg.norm(vt) > 1e-9:
            vf_body = -unit(vt) * min(cfg.sweep_max, cfg.sweep_gain * np.linalg.norm(vt))
        else:
            vf_body = np.zeros(3)
    vr = v - vf_body
    vrt = vr - e * np.dot(vr, e)
    Fb = -cfg.k * B2 * vrt
    return {"tb": np.cross(rp, Fb), "Fb": Fb, "rp": rp, "e": e, "g": g, "B2": B2,
            "P": cfg.k * B2 * float(np.dot(vrt, vrt)), "vt": vt}


class Estimator:
    """Attitude + rate filter on SO(3): predict with the physics, correct with each camera fix."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.q = np.array([1.0, 0.0, 0.0, 0.0])
        self.w = np.zeros(3)
        self.init = False
        self.inn = 1.0
        self.locked = False
        self.t_init = 0.0
        self.t_last = None
        self.rejects = 0

    def predict(self, dt, torque_body=None):
        if not self.init:
            return
        if self.cfg.inertia_est is not None:
            tau = np.zeros(3) if torque_body is None else torque_body
            wd = euler_rate(self.cfg.inertia_est, self.w, tau)
        else:
            wd = np.zeros(3)
        self.q = qnorm(qmul(self.q, qexp(self.w * dt)))
        self.w = self.w + wd * dt

    def update(self, q_meas, t):
        cfg = self.cfg
        sig = np.radians(cfg.cam_sigma_deg)
        if not self.init:
            self.q, self.w, self.init, self.t_init, self.t_last = qnorm(q_meas), np.zeros(3), True, t, t
            return True
        dq = qmul(qconj(self.q), q_meas)
        if dq[0] < 0:
            dq = -dq
        th = 2.0 * dq[1:]
        if self.locked and np.linalg.norm(th) > np.radians(cfg.gate_deg):
            self.rejects += 1
            if self.rejects > 5:          # the target really did change: start over
                self.init = False
                self.locked = False
                self.rejects = 0
            return False
        self.rejects = 0
        dtm = max(1e-3, t - self.t_last)
        self.t_last = t
        self.q = qnorm(qmul(self.q, qexp(cfg.alpha * th)))
        self.w = self.w + (cfg.beta / dtm) * th
        self.inn = 0.85 * self.inn + 0.15 * float(np.linalg.norm(th))
        if self.locked:
            if self.inn > 6 * sig:
                self.locked = False
        elif t - self.t_init > 2.0 and self.inn < 3.5 * sig:
            self.locked = True
        return True

    def world_rate(self):
        return qrot(self.q, self.w)

    def momentum(self):
        I = self.cfg.inertia_est if self.cfg.inertia_est is not None else np.ones(3)
        return qrot(self.q, I * self.w)


class Planner:
    """Score every candidate magnet spot by predicted angular momentum removed."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.dirs = fibonacci_dirs(cfg.n_dirs)
        self.scores = np.zeros(cfg.n_dirs)
        self.best = None
        self.plans = 0
        self.blocked = set()        # spots the arm failed to reach
        self.blocked_until = {}     # spots excluded for a while (no collision-free path at the moment)
        self.t_now = 0.0
        self.raw = None
        self.radii = np.full(cfg.n_dirs, cfg.r_magnet)

    def block(self, idx, seconds=None):
        """Exclude a spot: for good (unreachable) or for `seconds` (no path right now)."""
        if idx is not None:
            if seconds is None:
                self.blocked.add(int(idx))
            else:
                self.blocked_until[int(idx)] = self.t_now + seconds
            if self.best == idx:
                self.best = None

    def plan(self, est, sweep, p_cur_rel, feasible=None, radii=None, hold=False):
        """hold=True: the magnet arrived at the current spot less than min_dwell_s ago; keep it unless it
        has become infeasible or worthless."""
        cfg = self.cfg
        self.radii = np.full(len(self.dirs), cfg.r_magnet) if radii is None else np.asarray(radii, float)
        if not est.init:
            return self.best
        H = effective_momentum(cfg, est)
        if np.linalg.norm(H) < 1e-9 and self.best is not None:
            return self.best
        Hu = unit(H)
        c = unit(cfg.reach_dir)
        cur = unit(p_cur_rel) if np.linalg.norm(p_cur_rel) > 1e-6 else c
        I = cfg.inertia_est
        traj, q, w = [], est.q.copy(), est.w.copy()
        nsub = 4
        rate = float(np.linalg.norm(est.w))
        horizon = float(np.clip(2 * np.pi / max(rate, 1e-6), cfg.horizon, cfg.plan_horizon_max))   # about one full turn
        dt = horizon / (cfg.pred_n * nsub)
        for _ in range(cfg.pred_n):
            for _ in range(nsub):
                wd = euler_rate(I, w, np.zeros(3)) if I is not None else np.zeros(3)
                q = qnorm(qmul(q, qexp(w * dt)))
                w = w + wd * dt
            traj.append((q, w))
        RM = cfg.r_magnet
        D = self.dirs
        reach = D @ c
        dH = np.zeros(len(D))
        side = np.zeros(len(D))
        h = cfg.half_extents
        if sweep:                               # achievable sweep direction at each spot (world axes)
            toward = -D
            ax = Hu[None, :] - D * (D @ Hu)[:, None]
            ax = ax / np.maximum(np.linalg.norm(ax, axis=1), 1e-9)[:, None]
            sdir_w = np.cross(ax, toward)
        for qk, wk in traj:                      # vectorized over all candidate spots
            R = R_from_quat(qk)
            pb = (D * self.radii[:, None]) @ R   # magnet positions in body axes (R^T p for each row)
            rp = np.clip(pb, -h, h)
            dvec = pb - rp
            dist = np.maximum(np.linalg.norm(dvec, axis=1), 1e-9)
            e = dvec / dist[:, None]
            g = np.maximum(0.0005, dist - cfg.mag_radius)
            B2 = (cfg.field_length / (cfg.field_length + g)) ** 6
            v = np.cross(wk, rp)
            vt = v - e * np.sum(v * e, axis=1)[:, None]
            if sweep:
                sdir = sdir_w @ R                # same directions in body axes
                sig = np.clip(-cfg.sweep_gain * np.sum(vt * sdir, axis=1), -cfg.sweep_max, cfg.sweep_max)
                vf = sdir * sig[:, None]
            else:
                vf = 0.0
            vr = v - vf
            vrt = vr - e * np.sum(vr * e, axis=1)[:, None]
            Fb = -cfg.k * B2[:, None] * vrt
            tb = np.cross(rp, Fb)
            tw = tb @ R.T
            dH -= tw @ Hu
            if cfg.gimbal_axis is not None and cfg.tilt_penalty > 0:
                side += np.linalg.norm(tw - np.outer(tw @ cfg.gimbal_axis, cfg.gimbal_axis), axis=1)
        raw = np.maximum(0.0, dH - cfg.tilt_penalty * side)
        if cfg.gimbal is not None:
            # the head (a rod along the spin axis) and the boom behind it must clear the ring, pins and yoke
            # everywhere the hull is predicted to send them within the horizon; either boom direction may do
            if not sweep:
                ax = Hu[None, :] - D * (D @ Hu)[:, None]
                ax = ax / np.maximum(np.linalg.norm(ax, axis=1), 1e-9)[:, None]
            R_list = [R_from_quat(qk) for qk, _ in traj[:: max(1, len(traj) // 8)]]
            clear, sign = cfg.gimbal.head_clearance(D * self.radii[:, None], ax, cfg.head_half, cfg.r_head, cfg.boom_len, cfg.boom_r, R_list)
            self.gimbal_clear = clear
            self.boom_sign = sign
            raw = np.where(clear < cfg.gimbal_margin, 0.0, raw)
            # only work from the open side of the ring: the spot direction must stay within acos(ring_side_dot) of the
            # ring's normal for the whole horizon, so the boom reaches over the ring and the wrist stays outside it
            if cfg.ring_side_dot > 0:
                side = np.ones(len(D), bool)
                for Rk in R_list:
                    n_ring = cfg.gimbal.frame(Rk)[2]
                    side &= np.abs(D @ n_ring) >= cfg.ring_side_dot
                raw = np.where(side, raw, 0.0)
        self.raw = raw if self.raw is None else 0.6 * self.raw + 0.4 * raw        # average over rotation phase
        travel = np.arccos(np.clip(D @ cur, -1, 1))                                 # angle the arm must swing
        s = self.raw * (0.55 + 0.45 * (reach + 1) / 2) * (0.6 + 0.4 * np.exp(-travel / cfg.travel_scale))
        s[reach <= cfg.min_reach_dot] = 0.0
        if cfg.pole_dot > 0:
            s[np.abs(D @ Hu) > cfg.pole_dot] = 0.0
        if cfg.gimbal_axis is not None and cfg.equator_dot < 1.0:
            s[np.abs(D @ cfg.gimbal_axis) > cfg.equator_dot] = 0.0
        if cfg.stand_cone_deg > 0:
            s[D[:, 2] < -np.cos(np.radians(cfg.stand_cone_deg))] = 0.0
        if self.blocked:
            s[list(self.blocked)] = 0.0
        for i, tu in list(self.blocked_until.items()):
            if tu > self.t_now:
                s[i] = 0.0
            else:
                del self.blocked_until[i]
        self.scores = s
        order = np.argsort(-s)
        pick = None
        for i in order[:25]:
            if s[i] <= 0:
                break
            if feasible is None or feasible(self.dirs[i] * self.radii[i]):
                pick = int(i)
                break
        if pick is None:
            return self.best
        # the current spot stays valid until a check actually fails (None = not re-checked yet this tick)
        best_ok = self.best is not None and (feasible is None or feasible(self.dirs[self.best] * self.radii[self.best]) is not False)
        if hold and best_ok and s[self.best] > 0:
            pick = self.best                                                        # dwell: stay put
        if self.best is None or s[pick] > cfg.switch_ratio * s[self.best] or not best_ok:
            self.best = pick
        self.plans += 1
        return self.best

    def best_dir(self):
        return None if self.best is None else self.dirs[self.best]

    def best_spot(self):
        return None if self.best is None else self.dirs[self.best] * self.radii[self.best]


@dataclass
class Command:
    phase: str
    p_rel: np.ndarray           # next magnet waypoint, target-centered frame [m]
    axis: np.ndarray            # desired magnet spin axis (unit, base axes)
    sweep_world: np.ndarray     # field sweep velocity at the magnet face (base axes) [m/s]
    motor_rpm: float            # magnet motor speed, positive about +axis
    locked: bool
    spin_dps: float             # estimated tumble rate


class Brain:
    PHASES = ("standby", "approach", "detumble", "stable")

    def __init__(self, cfg, mode="spin"):
        self.cfg = cfg
        self.mode = mode            # "spin" (motor-spun field) or "still"
        self.est = Estimator(cfg)
        self.planner = Planner(cfg)
        self.auto = False
        self.phase = "standby"
        self.wf = 0.0
        self.stable_t = 0.0
        self.plan_acc = 1e9
        self.sweep_speed = 0.0
        self.sweep_dir = np.zeros(3)
        self.axis = None
        self.events = []
        self.t = 0.0
        # extra clearance [m] the mission adds when it cannot see the magnet holder with the camera
        self.position_uncertainty = 0.0
        self._arrived = (None, 0.0)     # (spot index, time) of the last arrival at a planned spot
        self._vt_w, self._toward, self._dt, self._sweep_act = None, np.array([1.0, 0.0, 0.0]), 1 / 30, 0.0

    def set_auto(self, on):
        self.auto = on
        self._phase("approach" if on else "standby")

    def _phase(self, ph):
        if ph != self.phase:
            self.phase = ph
            self.events.append((self.t, ph))

    def measure(self, q_meas, t):
        """Feed one camera attitude fix (target body -> base axes)."""
        before = self.est.locked
        ok = self.est.update(q_meas, t)
        if before and not self.est.locked and self.phase in ("detumble", "stable") and self.auto:
            self._phase("approach")
        return ok

    def predicted_rotations(self, horizon, n=12):
        q, w = self.est.q.copy(), self.est.w.copy()
        I = self.cfg.inertia_est
        out = [R_from_quat(q)]
        dt = horizon / n
        for _ in range(n):
            for _ in range(3):
                wd = euler_rate(I, w, np.zeros(3)) if I is not None else np.zeros(3)
                q = qnorm(qmul(q, qexp(w * dt / 3)))
                w = w + wd * dt / 3
            out.append(R_from_quat(q))
        return out

    def safe_radius(self, dirs):
        """Closest the magnet CENTER may be to the target center, in each direction.

        No lock (or extreme spin): the worst-case sphere the target could ever sweep.
        Locked: the volume the hull is PREDICTED to sweep over about one full turn (at least
        close_horizon seconds), plus the magnet radius and a gap that grows with spin rate.
        For a steady spin that volume is a tight solid of revolution around the momentum
        axis; for a chaotic tumble it grows back toward the full sphere by itself."""
        cfg = self.cfg
        dirs = np.atleast_2d(dirs)
        full = np.full(len(dirs), cfg.r_magnet)
        est = self.est
        rate = float(np.linalg.norm(est.w))
        rate_dps = np.degrees(rate)
        if not (est.init and est.locked) or rate_dps > cfg.close_dps:
            return full
        key = (round(float(self.t), 3), round(rate, 5))
        if getattr(self, "_env_key", None) != key:
            horizon = float(np.clip(2 * np.pi / max(rate, 1e-6) * 1.05, cfg.close_horizon, cfg.envelope_max_horizon))
            n = int(np.clip(horizon / 0.05, 12, 90))
            self._env_R = np.stack(self.predicted_rotations(horizon, n))
            self._env_key = key
        sup = np.max(np.abs(np.einsum("ni,kij->knj", dirs, self._env_R)) @ cfg.half_extents, axis=0)
        gap = cfg.close_gap + cfg.close_gap_per_dps * rate_dps + self.position_uncertainty
        plan_r = np.minimum(full, sup + cfg.r_head + gap)
        return np.maximum(plan_r, self.safety_radius(dirs) + 0.001)

    def safety_radius(self, dirs):
        """Conservative hard limit for the magnet CENTER, per direction (never to be entered)."""
        return self.safety_support(dirs) + self.cfg.r_head + self.cfg.safety_gap

    def plan_support(self, dirs):
        """Support function for motion planning: everywhere the hull is predicted to sweep over
        about one full turn (the same volume the spots are planned on), plus the safety margins.
        A whole joint-space path is checked against this, so it stays valid while it executes."""
        dirs = np.atleast_2d(dirs)
        est = self.est
        if not (est.init and est.locked) or np.degrees(np.linalg.norm(est.w)) > self.cfg.close_dps:
            return np.full(len(dirs), self.cfg.r_keepout + self.position_uncertainty)
        self.safe_radius(dirs[:1])                       # refreshes the cached full-turn rotations
        sup = np.max(np.abs(np.einsum("ni,kij->knj", dirs, self._env_R)) @ self.cfg.half_extents, axis=0)
        extra = self.safety_support(dirs) - np.max(np.abs(np.einsum("ni,kij->knj", dirs, self._saf_R)) @ self.cfg.half_extents, axis=0)
        return np.maximum(sup + extra, self.safety_support(dirs))

    def gimbal_clearance(self, P_rel, radii, plan=False):
        """Clearance of arm spheres (relative to the target center) from the external gimbal, over the attitudes
        the hull is predicted to take (the full-turn set when planning, the safety horizon otherwise). inf when
        the rig has no external gimbal."""
        cfg = self.cfg
        if cfg.gimbal is None or len(np.atleast_2d(P_rel)) == 0:
            return np.inf
        est = self.est
        if not est.init:
            return np.inf
        R_now = R_from_quat(est.q)
        if est.locked:
            self.safety_support(np.array([[1.0, 0, 0]]))
            R_list = [R_now] + list(self._saf_R[:: 2])
            if plan:
                self.safe_radius(np.array([[1.0, 0, 0]]))
                R_list += list(self._env_R[:: max(1, len(self._env_R) // 10)])
        else:
            R_list = [R_now]
        return cfg.gimbal.sphere_clearance(P_rel, radii, R_list) - cfg.safety_gap

    def link_clearance(self, P_rel, radii, m_hat=None, plan=False):
        """Smallest clearance [m] of arm link spheres (points relative to the target center) from the
        conservative hull envelope. A point is clear if it lies outside the envelope along its own
        direction, or beyond the envelope's tangent plane in the magnet's direction (the boom always
        sits in that plane's shadow). Negative = a link could touch the hull within the horizon."""
        P_rel = np.atleast_2d(P_rel)
        if len(P_rel) == 0:
            return np.inf
        r = np.linalg.norm(P_rel, axis=1)
        dirs = P_rel / np.maximum(r, 1e-9)[:, None]
        support = self.plan_support if plan else self.safety_support
        radial = r - support(dirs)
        if m_hat is not None:
            m_hat = unit(m_hat)
            plane = P_rel @ m_hat - float(support(m_hat)[0])
            radial = np.maximum(radial, plane)
        return float(np.min(radial - radii - self.cfg.safety_gap))

    def safety_support(self, dirs):
        """Support function of the conservative envelope: how far the hull can reach in each
        direction within safety_horizon, inflated for uncertainty in the estimated spin axis
        (large when the spin is slow), in the current attitude, and in the magnet position.
        Unlocked: the worst-case bounding sphere."""
        cfg = self.cfg
        dirs = np.atleast_2d(dirs)
        est = self.est
        full = np.full(len(dirs), cfg.r_keepout + self.position_uncertainty)
        if not (est.init and est.locked):
            return full
        rate = float(np.linalg.norm(est.w))
        key = (round(float(self.t), 3), round(rate, 5), "safety")
        if getattr(self, "_saf_key", None) != key:
            self._saf_R = np.stack(self.predicted_rotations(cfg.safety_horizon, 10))
            self._saf_key = key
        sup = np.max(np.abs(np.einsum("ni,kij->knj", dirs, self._saf_R)) @ cfg.half_extents, axis=0)
        theta = rate * cfg.safety_horizon                                    # rotation within the horizon
        eps_axis = min(np.pi / 2, np.arctan2(3 * np.radians(cfg.rate_noise_dps), max(rate, 1e-9)))
        eps_att = 3 * np.radians(cfg.attitude_noise_deg)
        r_body = float(np.linalg.norm(cfg.half_extents))
        margin = r_body * min(1.0, theta * np.sin(eps_axis) + eps_att)
        return np.minimum(full, sup + margin + self.position_uncertainty)

    def rpm_for_axis(self, axis_actual):
        """Signed magnet speed [rpm] about the tool's ACTUAL spin axis (measured, not commanded).

        The sweep law is applied to the sweep direction that this axis really produces, so the braking stays
        dissipative whatever the alignment (Proposition 1 in the paper); a misaligned axis only opposes less
        of the hull's motion. Zero unless braking with a spun magnet and a locked estimate."""
        cfg = self.cfg
        goal = 0.0
        if self._vt_w is not None and axis_actual is not None:
            s_act = np.cross(unit(axis_actual), self._toward)
            if np.linalg.norm(s_act) > 1e-6:
                goal = float(np.clip(-cfg.sweep_gain * np.dot(self._vt_w, unit(s_act)), -cfg.sweep_max, cfg.sweep_max))
        self._sweep_act += (goal - self._sweep_act) * min(1.0, self._dt / cfg.sweep_tau)
        return self._sweep_act / (2 * np.pi * cfg.mag_radius) * 60.0

    def _holding(self, t):
        idx, t_arr = self._arrived
        return self.cfg.min_dwell_s > 0 and idx is not None and idx == self.planner.best and t - t_arr < self.cfg.min_dwell_s

    def model_torque_body(self, p_rel):
        r = eddy_patch(self.cfg, self.est.q, self.est.w, p_rel, vf_body=qrot_inv(self.est.q, self.sweep_dir * self.sweep_speed))
        return None if r is None else r["tb"]

    def tick(self, dt, t, p_mag_rel, feasible=None):
        """Advance the brain by dt given where the magnet actually is (target-centered frame)."""
        cfg = self.cfg
        self.t = t
        self.est.predict(dt, self.model_torque_body(p_mag_rel) if self.est.init else None)
        est = self.est
        self.plan_acc += dt
        self.planner.t_now = t
        if est.init and self.plan_acc >= cfg.plan_period:
            self.plan_acc = 0.0
            radii = self.safe_radius(self.planner.dirs)
            self.planner.plan(est, self.mode == "spin", p_mag_rel, feasible, radii, hold=self._holding(t))
        self.feasible = feasible
        rate = float(np.linalg.norm(est.w))
        self.wf += (rate - self.wf) * min(1.0, dt / 1.0)

        target = self.planner.best_spot()
        if target is not None:          # the safe radius can grow again if the target speeds up
            target = unit(target) * max(np.linalg.norm(target), float(self.safe_radius(unit(target))[0]))
        at_spot = target is not None and np.linalg.norm(p_mag_rel - target) < 0.004
        if target is not None and np.linalg.norm(p_mag_rel - target) < 0.01 and self._arrived[0] != self.planner.best:
            self._arrived = (self.planner.best, t)                  # arrival time at this spot (for the dwell rule)
        if self.phase == "approach" and at_spot and est.locked:
            self._phase("detumble")
        if self.phase == "detumble":
            self.stable_t = self.stable_t + dt if (self.wf < np.radians(cfg.stable_dps) and est.locked) else 0.0
            if self.stable_t > 2.0:
                self._phase("stable")
        elif self.phase == "stable" and self.wf > np.radians(cfg.restart_dps) and est.locked:
            self._phase("detumble")

        # magnet spin axis: parallel to the target's angular momentum (projected perpendicular to
        # the line to the target), like parallel gear shafts; the sweep sign below makes the magnet's near
        # surface move AGAINST the hull's surface. H is fixed in space, so the wrist holds still.
        toward = -unit(p_mag_rel) if np.linalg.norm(p_mag_rel) > 1e-6 else -unit(cfg.reach_dir)
        H = effective_momentum(cfg, est) if est.init else np.zeros(3)
        a = H - toward * np.dot(H, toward)
        if np.linalg.norm(a) > 1e-9 and np.linalg.norm(a) > 0.2 * np.linalg.norm(H):
            a = unit(a)
            if self.axis is not None and np.dot(a, self.axis) < 0:
                a = -a                                   # keep the sign continuous
            self.axis = a
        if self.axis is None or abs(np.dot(self.axis, toward)) > 0.5:
            self.axis = any_perpendicular(toward) if self.axis is None else unit(self.axis - toward * np.dot(self.axis, toward))

        # field sweep: the spinning magnet can only sweep along axis x toward. Command a signed
        # speed against the hull's motion along that direction, up to G times it. Because the
        # sweep always opposes the hull's own motion component, it can only remove energy.
        sdir = unit(np.cross(self.axis, toward))
        goal = 0.0
        self._vt_w, self._toward, self._dt = None, toward, dt
        if self.phase == "detumble" and self.mode == "spin" and est.locked:
            r = eddy_patch(cfg, est.q, est.w, p_mag_rel)
            if r is not None:
                vt_w = qrot(est.q, r["vt"])
                self._vt_w = vt_w
                goal = float(np.clip(-cfg.sweep_gain * np.dot(vt_w, sdir), -cfg.sweep_max, cfg.sweep_max))
        self.sweep_speed += (goal - self.sweep_speed) * min(1.0, dt / cfg.sweep_tau)
        self.sweep_dir = sdir

        waypoint = p_mag_rel.copy()
        if self.phase != "standby" and target is not None:
            waypoint = self.step_toward(p_mag_rel, target, dt)
        rpm = self.sweep_speed / (2 * np.pi * cfg.mag_radius) * 60.0     # signed, positive about +axis
        return Command(self.phase, waypoint, self.axis.copy(), self.sweep_dir * self.sweep_speed, float(rpm),
                       est.locked, float(np.degrees(rate)))

    def step_toward(self, p, target, dt):
        """One step around the target toward `target`, never inside the safe radius.

        Greedy planner on the sphere: try the direct direction and directions turned up to
        180 degrees from it, keep the safe one (workspace check from the mission) that ends
        closest to the goal direction.
        """
        cfg = self.cfg
        feasible = getattr(self, "waypoint_check", None) or getattr(self, "feasible", None)
        r = np.linalg.norm(p)
        if r < 1e-6:
            return target.copy()
        u, tu = p / r, unit(target)
        r_hard = float(self.safety_radius(u)[0])
        if r < r_hard:                                   # too close: back straight out, fast
            return u * min(r + cfg.retreat_speed * dt, r_hard + 0.002)
        ang = float(np.arccos(np.clip(np.dot(u, tu), -1, 1)))
        stepa = min(ang, np.radians(cfg.approach_rate_dps) * dt)
        t0 = tu - u * np.dot(tu, u)
        t0 = any_perpendicular(u) if np.linalg.norm(t0) < 1e-9 else unit(t0)
        best, best_ang = None, None
        for turn in (0, 30, -30, 60, -60, 90, -90, 135, -135, 180):
            tdir = qrot(qexp(u * np.radians(turn)), t0)
            ax = unit(np.cross(u, tdir))
            nu = qrot(qexp(ax * stepa), u) if stepa > 1e-9 else u
            rmin = float(self.safe_radius(nu)[0])
            # orbit on a transit shell just outside the envelope (not wherever the arm started),
            # then come in to the spot's own radius once lined up
            rgoal = max(np.linalg.norm(target) if turn == 0 and ang < 0.05 else max(np.linalg.norm(target), rmin + cfg.transit_gap), rmin + 0.001)
            nr = max(r + np.sign(rgoal - r) * min(abs(rgoal - r), cfg.approach_speed * dt), rmin)
            cand = nu * nr
            if feasible is not None and not feasible(cand):
                continue
            a2 = float(np.arccos(np.clip(np.dot(nu, tu), -1, 1)))
            if best is None or a2 < best_ang - 1e-9:
                best, best_ang = cand, a2
            if turn == 0:
                break                       # the direct step is safe: take it
        if best is None:                    # boxed in: climb toward the top of the target
            up = unit(np.array([0.0, 0.0, 1.0]) - u * u[2]) if abs(u[2]) < 0.99 else any_perpendicular(u)
            nu = qrot(qexp(unit(np.cross(u, up)) * np.radians(cfg.approach_rate_dps) * dt), u)
            best = nu * max(r, float(self.safe_radius(nu)[0]))
        return best
