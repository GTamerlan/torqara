"""Hardware interfaces. The mission loop only talks to these, so the same code runs on the
real arm, on a simulated arm, or on anything else you wrap (ROS, a vendor SDK, ...).

Serial protocol for the included Arduino template (firmware/arm_controller/arm_controller.ino),
one line per message, ASCII, newline terminated:
    host -> board   J <deg_1> ... <deg_n>     move joints (degrees, firmware zero = DH zero)
    host -> board   M <rpm>                   magnet motor speed, signed
    host -> board   S                         stop everything (motor off, hold joints)
    host -> board   ?                         request joint readings
    board -> host   A <deg_1> ... <deg_n>     joint readings (encoders if fitted, else last command)
"""
import time
import numpy as np


class ArmIO:
    def read_joints(self):
        raise NotImplementedError

    def send_joints(self, q):
        raise NotImplementedError

    def stop(self):
        pass


class MotorIO:
    def set_rpm(self, rpm):
        raise NotImplementedError

    def stop(self):
        self.set_rpm(0.0)


class SerialArm(ArmIO, MotorIO):
    def __init__(self, port, n_joints, baud=115200, timeout=0.05):
        try:
            import serial
        except ImportError as e:
            raise RuntimeError("pip install pyserial to talk to the arm over USB") from e
        self.ser = serial.Serial(port, baud, timeout=timeout)
        self.n = n_joints
        self.last = np.zeros(n_joints)
        time.sleep(2.0)          # most Arduinos reset when the port opens
        self.ser.reset_input_buffer()

    def _send(self, line):
        self.ser.write((line + "\n").encode())

    def read_joints(self):
        self._send("?")
        deadline = time.time() + 0.05
        while time.time() < deadline:
            raw = self.ser.readline().decode(errors="ignore").strip()
            if raw.startswith("A "):
                vals = [float(x) for x in raw.split()[1:]]
                if len(vals) == self.n:
                    self.last = np.radians(vals)
                    break
        return self.last.copy()

    def send_joints(self, q):
        self._send("J " + " ".join(f"{np.degrees(x):.3f}" for x in q))

    def set_rpm(self, rpm):
        self._send(f"M {rpm:.1f}")

    def stop(self):
        self._send("S")

    def status(self, timeout=0.3):
        """Teensy firmware only: (state, fault_bits, estop_ok). state 0 not homed, 1 homing, 2 ready, 3 fault."""
        self._send("E")
        deadline = time.time() + timeout
        while time.time() < deadline:
            raw = self.ser.readline().decode(errors="ignore").strip()
            if raw.startswith("E "):
                parts = raw.split()
                return int(parts[1]), int(parts[2], 16), parts[3] == "OK"
        return None

    def home(self, timeout=240.0):
        """Teensy firmware only: home every joint on its optical flag (wrist first), then go to the home pose."""
        self._send("H")
        t0 = time.time()
        while time.time() - t0 < timeout:
            time.sleep(1.0)
            st = self.status()
            if st and st[0] == 2:
                return True
            if st and st[0] == 3:
                return False
        return False


class RefShaper:
    """Second-order reference shaper, as a motion drive's interpolator does it: the joint reference follows the
    commanded position with limited velocity and acceleration, so velocity never jumps (no torque spikes, no
    excitation of the arm's first bending mode)."""

    def __init__(self, q0, vmax, amax):
        self.q = np.asarray(q0, float).copy()
        self.v = np.zeros_like(self.q)
        self.vmax = np.asarray(vmax, float)
        self.amax = np.asarray(amax, float)

    def update(self, target, dt):
        e = np.asarray(target, float) - self.q
        # velocity that still lets the joint stop exactly at the target with amax
        v_des = np.sign(e) * np.minimum(self.vmax, np.sqrt(2 * self.amax * np.abs(e)))
        v_des = np.where(np.abs(e) < 1e-6, 0.0, v_des)
        self.v = np.clip(v_des, self.v - self.amax * dt, self.v + self.amax * dt)
        step = self.v * dt
        # do not overshoot the target inside one step
        step = np.where(np.abs(step) > np.abs(e), e, step)
        self.q = self.q + step
        return self.q.copy(), self.v.copy()


class SimArm(ArmIO):
    """Joint servos with speed and acceleration limits, small encoder noise and an unknown zero offset."""

    def __init__(self, q0, max_speed, encoder_noise_deg=0.02, rng=None, max_accel=None):
        self.q = np.asarray(q0, float).copy()           # true joint angles
        self.cmd = self.q.copy()
        self.max_speed = np.asarray(max_speed, float)
        self.max_accel = 3.0 * self.max_speed if max_accel is None else np.asarray(max_accel, float)
        self.shaper = RefShaper(self.q, self.max_speed, self.max_accel)
        self.noise = np.radians(encoder_noise_deg)
        self.rng = np.random.default_rng(1) if rng is None else rng

    def read_joints(self):
        return self.q + self.rng.normal(0, self.noise, len(self.q))

    def send_joints(self, q):
        self.cmd = np.asarray(q, float).copy()

    def stop(self):
        self.cmd = self.q.copy()

    def update(self, dt):
        self.q, _ = self.shaper.update(self.cmd, dt)


class SimMotor(MotorIO):
    def __init__(self):
        self.rpm = 0.0

    def set_rpm(self, rpm):
        self.rpm = float(rpm)
