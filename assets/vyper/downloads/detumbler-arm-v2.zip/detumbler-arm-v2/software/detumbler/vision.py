"""Camera pose measurement with ArUco markers (OpenCV).

A `MarkerBody` is a rigid object carrying one or more square markers at known places
(the target satellite mock-up, or the magnet holder on the arm). All visible markers are
solved together in one PnP problem, which is far more accurate than any single marker.

First prototype: print markers and glue them to the target's faces. Later the same
interface can be fed by a learned keypoint detector instead (no markers).
"""
from dataclasses import dataclass, field
import numpy as np

try:
    import cv2
except ImportError:  # the rest of the package works without OpenCV (simulation)
    cv2 = None

from .frames import make_T, apply_T, inv_T, T_from_xyz_rpy, rotation_angle_deg


def marker_corners_local(size):
    """Corner order used by OpenCV ArUco: top-left, top-right, bottom-right, bottom-left.
    Marker frame: origin at the center, x right, y up, z out of the printed face."""
    s = size / 2.0
    return np.array([[-s, s, 0], [s, s, 0], [s, -s, 0], [-s, -s, 0]], float)


@dataclass
class MarkerBody:
    name: str
    markers: dict = field(default_factory=dict)   # id -> (T_body_marker 4x4, size in m)

    def add(self, marker_id, T_body_marker, size):
        self.markers[int(marker_id)] = (np.asarray(T_body_marker, float), float(size))

    def corners_in_body(self, marker_id):
        T, s = self.markers[marker_id]
        return apply_T(T, marker_corners_local(s))

    @classmethod
    def from_config(cls, name, entries):
        """entries: list of {id, size, xyz, rpy_deg} as in config/rig_tabletop.toml."""
        b = cls(name)
        for e in entries:
            b.add(e["id"], T_from_xyz_rpy(e["xyz"], e["rpy_deg"]), e["size"])
        return b


def box_face_markers(half_extents, size, first_id=0, inset=0.0005):
    """Markers centered on the six faces of a box, printed face pointing outward."""
    hx, hy, hz = half_extents
    faces = [  # (normal axis direction, xyz of face center, rpy that turns marker z to the normal)
        ([hx + inset, 0, 0], [0, 90, 0]), ([-hx - inset, 0, 0], [0, -90, 0]),
        ([0, hy + inset, 0], [-90, 0, 0]), ([0, -hy - inset, 0], [90, 0, 0]),
        ([0, 0, hz + inset], [0, 0, 0]), ([0, 0, -hz - inset], [180, 0, 0]),
    ]
    return [{"id": first_id + i, "size": size, "xyz": xyz, "rpy_deg": rpy} for i, (xyz, rpy) in enumerate(faces)]


class ArucoPoseTracker:
    def __init__(self, K, dist, dictionary="DICT_4X4_50"):
        if cv2 is None:
            raise RuntimeError("OpenCV (opencv-python) is required for camera tracking")
        self.K = np.asarray(K, float)
        self.dist = np.zeros(5) if dist is None else np.asarray(dist, float)
        self.dictionary = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, dictionary))
        params = cv2.aruco.DetectorParameters()
        params.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
        self.detector = cv2.aruco.ArucoDetector(self.dictionary, params)

    def detect(self, image):
        gray = image if image.ndim == 2 else cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        corners, ids, _ = self.detector.detectMarkers(gray)
        out = {}
        if ids is not None:
            for c, i in zip(corners, ids.flatten()):
                out[int(i)] = c.reshape(4, 2).astype(float)
        return out

    def body_pose(self, detections, body, prior_T_cam_body=None, min_markers=1):
        """Pose of `body` in the camera frame from all its visible markers.

        With two or more markers, all corners go into one PnP solve. With a single marker,
        a flat square has two mirror-image solutions; the one closest to `prior_T_cam_body`
        (the previous frame) is kept, or the lower-error one if there is no prior.
        Returns dict(T_cam_body, n_markers, reproj_px) or None.
        """
        seen = [mid for mid in body.markers if mid in detections]
        if len(seen) < min_markers or not seen:
            return None
        if len(seen) == 1:
            mid = seen[0]
            T_bm, s = body.markers[mid]
            obj = marker_corners_local(s)
            img = detections[mid].astype(np.float64)
            n, rvecs, tvecs, errs = cv2.solvePnPGeneric(obj, img, self.K, self.dist, flags=cv2.SOLVEPNP_IPPE_SQUARE)
            if n == 0:
                return None
            cands = []
            for rv, tv, e in zip(rvecs, tvecs, np.asarray(errs).reshape(-1)):
                R, _ = cv2.Rodrigues(rv)
                T_cb = make_T(R, tv.reshape(3)) @ inv_T(T_bm)
                if prior_T_cam_body is not None:
                    score = rotation_angle_deg(T_cb[:3, :3], prior_T_cam_body[:3, :3])
                else:
                    score = float(e)
                cands.append((score, T_cb, float(e)))
            cands.sort(key=lambda c: c[0])
            return {"T_cam_body": cands[0][1], "n_markers": 1, "reproj_px": cands[0][2], "ambiguous": len(cands) > 1}
        obj = np.vstack([body.corners_in_body(m) for m in seen]).astype(np.float64)
        img = np.vstack([detections[m] for m in seen]).astype(np.float64)
        ok, rvec, tvec = cv2.solvePnP(obj, img, self.K, self.dist, flags=cv2.SOLVEPNP_SQPNP)
        if not ok:
            return None
        rvec, tvec = cv2.solvePnPRefineLM(obj, img, self.K, self.dist, rvec, tvec)
        proj, _ = cv2.projectPoints(obj, rvec, tvec, self.K, self.dist)
        err = float(np.sqrt(np.mean(np.sum((proj.reshape(-1, 2) - img) ** 2, axis=1))))
        R, _ = cv2.Rodrigues(rvec)
        return {"T_cam_body": make_T(R, tvec.reshape(3)), "n_markers": len(seen), "reproj_px": err, "ambiguous": False}


def load_intrinsics(path):
    import json
    with open(path) as f:
        d = json.load(f)
    return np.asarray(d["K"], float), np.asarray(d["dist"], float), tuple(d.get("image_size", (0, 0)))
