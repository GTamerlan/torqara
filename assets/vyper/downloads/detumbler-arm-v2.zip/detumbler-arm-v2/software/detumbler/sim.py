"""A stand-in for the physical world, so the whole real-world pipeline can be exercised
without hardware: the true target tumbling, a real arm that does NOT exactly match its
model (wrong joint zeros), a camera whose true position differs from the calibrated one,
and noisy marker measurements. The mission code only ever sees what real sensors would give.
"""
import numpy as np

from .frames import (make_T, inv_T, apply_T, qmul, qnorm, qexp, qrot, qrot_inv, R_from_quat,
                     quat_from_R, R_from_rotvec, rpy_R, unit)
from .brain import eddy_patch, euler_rate, BrainConfig
from .calibration import fit_camera_to_base
from .hardware import SimArm, SimMotor


def look_at_T(pos, target):
    """Camera pose with the optical axis (camera z) on `target`, image x horizontal, image y down."""
    z = target - pos
    z = z / np.linalg.norm(z)
    x = np.cross(z, np.array([0.0, 0.0, 1.0]))
    x = x / max(np.linalg.norm(x), 1e-9)
    y = np.cross(z, x)
    return make_T(np.c_[x, y, z], pos)


class SimWorld:
    def __init__(self, rig, arm_model, brain_cfg, seed=0, true_inertia=None,
                 joint_zero_error_deg=0.5, cam_rot_noise_deg=0.4, cam_pos_noise_m=0.001,
                 T_base_cam_true=None, spin_dps=(5.0, 50.0, 5.0)):
        self.rng = np.random.default_rng(seed)
        self.cfg_true = BrainConfig(**{**brain_cfg.__dict__})
        if true_inertia is not None:
            self.cfg_true.inertia_est = np.asarray(true_inertia, float)
        elif brain_cfg.inertia_est is not None:   # the real target differs from our estimate
            self.cfg_true.inertia_est = brain_cfg.inertia_est * self.rng.uniform(0.95, 1.05, 3)
        self.I = self.cfg_true.inertia_est
        self.center = np.asarray(rig["target"]["center_in_robot_base_guess"], float)
        self.q = np.array([1.0, 0, 0, 0]) if rig["target"].get("start_upright") else qnorm(self.rng.normal(size=4))
        self.rig = rig
        self.w = np.radians(np.asarray(spin_dps, float))
        self.arm_model = arm_model
        self.arm_true = arm_model.copy_with(np.radians(self.rng.normal(0, joint_zero_error_deg, arm_model.n)))
        if T_base_cam_true is not None:
            self.T_bc_true = T_base_cam_true
        elif rig.get("camera", {}).get("look_at") is not None:
            self.T_bc_true = look_at_T(np.asarray(rig["camera"]["nominal_xyz"], float), np.asarray(rig["camera"]["look_at"], float))
        else:
            self.T_bc_true = make_T(rpy_R(*np.radians([-118, 0, -12])), [0.30, -0.70, 0.55])
        self.marker_in_tool_true = np.asarray(rig["tool_marker"]["xyz_in_tool_guess"], float) + self.rng.normal(0, 0.002, 3)
        self.cam_rot = np.radians(cam_rot_noise_deg)
        self.cam_pos = cam_pos_noise_m
        q0 = arm_model.home.copy() if np.any(arm_model.home) else np.radians([0, 60, 20, 0, 40, 0])[:arm_model.n]
        self.arm_io = SimArm(q0, arm_model.max_speed, rng=self.rng, max_accel=arm_model.max_accel)
        self.motor = SimMotor()
        self.t = 0.0
        self.last_heat = 0.0
        self.last_gap = None
        self.gap_now = np.inf          # current true head-to-hull gap [m]
        self.min_gap = np.inf          # closest true approach of the magnet surface to the hull [m]
        self.collisions = 0
        self.link_contacts = 0         # ticks in which an arm link touched the hull
        self.static_contacts = 0       # ticks in which a link or the magnet touched the stand or table
        self.min_link_gap = np.inf
        self.max_tilt_deg = 0.0        # body z from vertical (an internal gimbal allows about 30 deg)
        self.tool_seen_frac = [0, 0]
        faces = rig.get("tool_marker_face")
        self.tool_faces = None if not faces else [rpy_R(*np.radians(f["rpy_deg"]))[:, 2] for f in faces]
        st = rig.get("stand")
        self.stand = None if not st else (st["center_xy"], st["post_radius"], st["post_top_z"], st["base_radius"], st["base_top_z"])
        self.table_z = rig.get("safety", {}).get("table_z", 0.0)
        tl = rig["target"].get("tilt_limit_deg")
        self.tilt_limit = None if not tl else np.radians(tl)   # gimbal stop (soft silicone bumper)
        self.gimbal = brain_cfg.gimbal                          # external 3-axis gimbal, exact pose from the true attitude
        self.gimbal_contacts = 0
        self.min_gimbal_gap = np.inf
        self.gimbal_events = []
        self.static_events = []

    # ---------------- calibration, done the same way as on the real rig ----------------
    def run_calibration(self, n_poses=24):
        """Move the (true, imperfect) arm through random poses and solve camera -> base."""
        Ts, P = [], []
        while len(Ts) < n_poses:
            q = self.rng.uniform(self.arm_model.lower, self.arm_model.upper) * 0.5
            q[1] = self.rng.uniform(np.radians(40), np.radians(120))
            T_model = self.arm_model.fk(q)
            T_true = self.arm_true.fk(q)
            if T_true[2, 3] < 0.06 or T_true[0, 3] < 0.05:
                continue
            p_cam = apply_T(inv_T(self.T_bc_true), apply_T(T_true, self.marker_in_tool_true))
            if p_cam[2] < 0.2 or not self.tool_marker_visible(T_true, apply_T(T_true, self.marker_in_tool_true)):
                continue
            if self.arm_model.capsules:            # keep calibration poses clear of the target and the table
                Pc, Rc, _ = self.arm_true.collision_points(q)
                if np.min(np.linalg.norm(Pc - self.center, axis=1) - Rc) < 0.14 or np.min(Pc[:, 2] - Rc) < 0.02:
                    continue
            Ts.append(T_model)
            P.append(p_cam + self.rng.normal(0, self.cam_pos, 3))
        return fit_camera_to_base(Ts, np.array(P), marker_in_tool0=np.asarray(self.rig["tool_marker"]["xyz_in_tool_guess"], float))

    # ---------------- sensors ----------------
    def read_camera(self):
        T_bo = make_T(R_from_quat(self.q), self.center)
        T_co = inv_T(self.T_bc_true) @ T_bo
        noise = R_from_rotvec(self.rng.normal(0, self.cam_rot, 3))
        T_co_meas = make_T(T_co[:3, :3] @ noise, T_co[:3, 3] + self.rng.normal(0, self.cam_pos, 3))
        T_tool = self.arm_true.fk(self.arm_io.q)
        p_marker = apply_T(T_tool, self.marker_in_tool_true)
        p_marker_cam = apply_T(inv_T(self.T_bc_true), p_marker) + self.rng.normal(0, self.cam_pos, 3)
        if not self.tool_marker_visible(T_tool, p_marker):
            p_marker_cam = None
        self.tool_seen_frac[0] += p_marker_cam is not None
        self.tool_seen_frac[1] += 1
        return {"t": self.t, "T_cam_target": T_co_meas, "p_cam_tool_marker": p_marker_cam}

    def tool_marker_visible(self, T_tool, p_marker):
        """A face of the tool marker block must face the camera (within ~70 deg) and the
        line of sight must not pass through the target."""
        if self.tool_faces is None:
            return True
        cam = self.T_bc_true[:3, 3]
        view = unit(cam - p_marker)
        if max(float(np.dot(T_tool[:3, :3] @ n, view)) for n in self.tool_faces) < 0.34:
            return False
        c = self.center
        u = cam - p_marker
        t = np.clip(np.dot(c - p_marker, u) / np.dot(u, u), 0, 1)
        return np.linalg.norm(p_marker + t * u - c) > np.linalg.norm(self.cfg_true.half_extents)

    def stop_torque_body(self, k=1.5, c=0.03):
        """The post touching the silicone bumper at the edge of the bottom hole: a stiff, damped
        torque pushing the tilt back inside the limit (returned in body axes). Acts only beyond the
        tilt limit; the damping makes a bounce lose about half its energy, like a soft bumper."""
        R = R_from_quat(self.q)
        bz = R[:, 2]
        tilt = float(np.arccos(np.clip(bz[2], -1, 1)))
        if tilt <= self.tilt_limit:
            return np.zeros(3)
        ax = np.cross(bz, [0.0, 0.0, 1.0])            # rotating about this brings body z back up
        ax = ax / max(np.linalg.norm(ax), 1e-12)
        w_world = R @ self.w
        return R.T @ (k * (tilt - self.tilt_limit) * ax - c * float(np.dot(w_world, ax)) * ax)

    def check_links(self):
        """True contacts of the arm's links with the hull (exact box), the stand and the table."""
        P, R, idx = self.arm_true.collision_points(self.arm_io.q)
        p_head, _ = self.true_magnet()
        if len(P):
            pb = (P - self.center) @ R_from_quat(self.q)          # body axes
            h = self.cfg_true.half_extents
            dist = np.linalg.norm(pb - np.clip(pb, -h, h), axis=1) - R
            self.min_link_gap = min(self.min_link_gap, float(dist.min()))
            if dist.min() < 0:
                self.link_contacts += 1
        allP = np.vstack([P, p_head[None, :]]) if len(P) else p_head[None, :]
        allR = np.r_[R, self.cfg_true.r_head] if len(P) else np.array([self.cfg_true.r_head])
        hit = np.any(allP[:, 2] - allR < self.table_z)
        if self.stand is not None:
            (sx, sy), pr, pz, br, bz = self.stand
            dxy = np.hypot(allP[:, 0] - sx, allP[:, 1] - sy)
            hit = hit or np.any((dxy < pr + allR) & (allP[:, 2] - allR < pz)) or np.any((dxy < br + allR) & (allP[:, 2] - allR < bz))
        if hit:
            self.static_contacts += 1
            if len(self.static_events) < 40:
                low = allP[:, 2] - allR
                i = int(np.argmin(low))
                what = "floor/table" if low[i] < self.table_z else "stand"
                self.static_events.append((round(self.t, 2), "head" if i >= len(P) else self.arm_true.capsules[int(idx[i])][3], what,
                                           [round(float(v), 3) for v in allP[i]]))
        if self.gimbal is not None:
            A, B, rr = self.gimbal.capsule_arrays(R_from_quat(self.q), exact=True)
            dmat = self.gimbal.point_segment_dist(allP - self.center, A, B) - rr[None, :] - allR[:, None]
            g = float(dmat.min())
            self.min_gimbal_gap = min(self.min_gimbal_gap, g)
            if g < 0:
                self.gimbal_contacts += 1
                i, j = np.unravel_index(int(np.argmin(dmat)), dmat.shape)
                cap = "head" if i >= len(P) else self.arm_true.capsules[int(idx[i])][3]
                part = "pin" if j < 2 else ("ring" if j < 2 + self.gimbal.n_ring else ("yoke arm" if j < len(rr) - 1 else "yoke bar"))
                self.gimbal_events.append((round(self.t, 2), cap, part, round(1000 * g, 1)))
        bz = R_from_quat(self.q)[:, 2]
        self.max_tilt_deg = max(self.max_tilt_deg, float(np.degrees(np.arccos(np.clip(bz[2], -1, 1)))))

    def true_magnet(self):
        T = self.arm_true.fk(self.arm_io.q)
        return T[:3, 3], T[:3, 2]

    # ---------------- physics ----------------
    def step(self, dt, substeps=8):
        h = dt / substeps
        for _ in range(substeps):
            self.arm_io.update(h)
            p, axis = self.true_magnet()
            p_rel = p - self.center
            toward = -unit(p_rel)
            omega_m = self.motor.rpm * 2 * np.pi / 60.0
            v_field = omega_m * self.cfg_true.mag_radius * np.cross(axis, toward)
            pb = qrot_inv(self.q, p_rel)
            true_gap = np.linalg.norm(pb - np.clip(pb, -self.cfg_true.half_extents, self.cfg_true.half_extents)) - self.cfg_true.r_head
            self.min_gap = min(self.min_gap, true_gap)
            self.gap_now = true_gap
            if true_gap < 0:
                self.collisions += 1
            r = eddy_patch(self.cfg_true, self.q, self.w, p_rel, vf_body=qrot_inv(self.q, v_field))
            tb = np.zeros(3) if r is None else r["tb"]
            if self.tilt_limit is not None:
                tb = tb + self.stop_torque_body()
            self.last_heat = 0.0 if r is None else r["P"]
            self.last_gap = None if r is None else r["g"]
            f = (lambda w: euler_rate(self.I, w, tb)) if self.I is not None else (lambda w: np.zeros(3))
            w0 = self.w
            k1 = f(w0); k2 = f(w0 + k1 * h / 2); k3 = f(w0 + k2 * h / 2); k4 = f(w0 + k3 * h)
            w1 = w0 + (k1 + 2 * k2 + 2 * k3 + k4) * h / 6
            self.q = qnorm(qmul(self.q, qexp((w0 + w1) * h / 2)))
            self.w = w1
        self.check_links()
        self.t += dt

    def spin_dps(self):
        return float(np.degrees(np.linalg.norm(self.w)))
