"""Optional: measure exactly where the magnet center sits relative to the flange (pivot method).

Fit a pointed tip in the magnet holder's center (or a printed cap with a point). Jog the arm
so the tip touches the SAME fixed point (a dimple in a block) from 8-15 different wrist
orientations, recording the joint angles each time in a CSV (one row per touch, joint angles
in degrees). Then:

    python tools/calibrate_tcp.py touches.csv --tip-to-magnet-mm 0 0 0

Prints the tip offset in the flange frame and the fit error. Put the result (plus any offset
from the tip to the magnet center) in [tool] xyz of your arm config.
"""
import argparse
import csv
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from detumbler.calibration import pivot_calibration
from detumbler.kinematics import Arm


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("csv")
    ap.add_argument("--arm", default="config/arm_prototype_5dof.toml")
    ap.add_argument("--tip-to-magnet-mm", type=float, nargs=3, default=[0, 0, 0])
    args = ap.parse_args()
    arm = Arm.from_toml(args.arm)
    arm.tool = np.eye(4)                       # solve relative to the bare flange
    rows = [[float(x) for x in r] for r in csv.reader(open(args.csv)) if r and not r[0].startswith("#")]
    Ts = [arm.fk(np.radians(r[:arm.n])) for r in rows]
    m, p, rms = pivot_calibration(Ts)
    print(f"{len(Ts)} touches. Tip in flange frame: {np.round(1000 * m, 2)} mm, pivot point: {np.round(1000 * p, 1)} mm, fit RMS {1000 * rms:.2f} mm")
    print(f"Magnet center in flange frame: {np.round(1000 * m + np.asarray(args.tip_to_magnet_mm), 2)} mm  -> [tool] xyz (in meters)")
    if rms > 0.002:
        print("Fit error over 2 mm: check the DH parameters and that every touch was on the same point.")


if __name__ == "__main__":
    main()
