"""Step 4: run the autonomous detumble.

    python tools/run_mission.py --sim                       # full pipeline against the simulated rig
    python tools/run_mission.py --sim --mode still --spin 45 4 -3
    python tools/run_mission.py --port /dev/ttyUSB0 --dry   # real camera + arm, magnet motor disabled
    python tools/run_mission.py --port /dev/ttyUSB0         # the real thing

Real-rig checklist before the first live run:
  - camera intrinsics and camera-to-robot calibrations done (steps 1 and 2), accuracy test run (step 3)
  - run with --dry and NO target first: watch the arm park around an imaginary target
  - then --dry with the target spinning slowly by hand, then live with the motor
  - keep a hand on the power switch. Ctrl+C stops the motor and holds the arm.
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from detumbler.brain import load_rig, BrainConfig, Brain
from detumbler.kinematics import Arm


def run_sim(args, arm, rig):
    from detumbler.simrun import run_sim as rs
    r = rs(args.arm, rig, seconds=args.seconds, seed=args.seed, mode=args.mode,
           visual_correction=not args.no_visual, spin_dps=tuple(args.spin), verbose=True)
    print("\nResult")
    for k in ("calibration_rms_mm", "time_to_detumble_phase_s", "time_to_stable_s", "final_true_spin_dps",
              "magnet_position_error_mm_mean", "magnet_position_error_mm_p95", "min_true_gap_mm", "collisions"):
        v = r[k]
        print(f"  {k:32s} {v:.2f}" if isinstance(v, float) else f"  {k:32s} {v}")
    if args.log:
        import csv
        with open(args.log, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(r["log_rows"][0].keys()))
            w.writeheader()
            w.writerows(r["log_rows"])
        print(f"  log written to {args.log}")


class NoMotor:
    def set_rpm(self, rpm):
        pass

    def stop(self):
        pass


def run_real(args, arm, rig):
    from detumbler.calibration import load_camera_to_base
    from detumbler.camera import CameraPoseSource
    from detumbler.hardware import SerialArm
    from detumbler.mission import MissionRunner
    from detumbler.safety import Safety
    cfg = BrainConfig.from_rig(rig)
    T_bc, marker = load_camera_to_base(rig["camera"]["camera_to_base_file"])
    io = SerialArm(args.port, arm.n)
    st = io.status()
    if st is not None:                       # Teensy firmware: check the E-stop and home before moving
        if not st[2]:
            raise SystemExit("E-stop is pressed or motor power is off. Release it, then run again.")
        if st[0] != 2:
            print("Homing all joints (wrist first)...")
            if not io.home():
                raise SystemExit("Homing failed. Check the home flags and the 'E' status, then send 'R' to reset.")
    motor = NoMotor() if args.dry else io
    cam = CameraPoseSource(rig)
    brain = Brain(cfg, mode=args.mode)
    runner = MissionRunner(arm, io, motor, brain, Safety(rig, cfg, arm), T_bc, marker,
                           com_in_body=rig["target"].get("center_of_mass_in_body"),
                           visual_correction=not args.no_visual, log_path=args.log or "mission_log.csv")
    t0 = time.monotonic()
    started = False
    try:
        while True:
            meas = cam.read()
            t = meas["t"] - t0
            cmd = runner.step(t, meas)
            if not started and t > args.start_after and brain.est.locked:
                brain.set_auto(True)
                started = True
                print("Autopilot engaged.")
            if cmd is not None and int(t * 2) != int((t - 1 / 30) * 2):
                print(f"t={t:6.1f}s {cmd.phase:9s} spin {cmd.spin_dps:6.2f} deg/s  locked={cmd.locked}  rpm {cmd.motor_rpm:7.1f}  {runner.last.get('note', '')}")
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        try:
            motor.set_rpm(0.0)
        finally:
            io.stop()
            cam.close()
            runner.save_log()
            print(f"Log saved to {runner.log_path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="config/arm_prototype_5dof.toml")
    ap.add_argument("--rig", default="config/rig_prototype.toml")
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--port", default=None)
    ap.add_argument("--dry", action="store_true", help="real arm and camera, magnet motor never driven")
    ap.add_argument("--mode", choices=["spin", "still"], default="spin")
    ap.add_argument("--no-visual", action="store_true", help="disable the camera correction of the magnet position")
    ap.add_argument("--spin", type=float, nargs=3, default=[3, 2, 40], help="sim only: initial body rates deg/s")
    ap.add_argument("--seconds", type=float, default=60)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--start-after", type=float, default=3.0)
    ap.add_argument("--log", default=None)
    args = ap.parse_args()
    arm = Arm.from_toml(args.arm)
    rig = load_rig(args.rig)
    if args.sim:
        run_sim(args, arm, rig)
    elif args.port:
        run_real(args, arm, rig)
    else:
        ap.error("use --sim, or --port for the real arm")


if __name__ == "__main__":
    main()
