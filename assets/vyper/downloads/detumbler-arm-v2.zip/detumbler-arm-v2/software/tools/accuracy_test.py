"""Step 3: how accurately does the arm put the magnet where it's told? Measured by the camera.

    python tools/accuracy_test.py --port /dev/ttyUSB0
    python tools/accuracy_test.py --sim

Commands the magnet to a grid of points around where the target will sit (target removed),
and compares where forward kinematics says the tool marker is against where the camera
sees it. Prints the arm's own accuracy, which tells you how much the camera correction in
the mission loop has to fix. Keep this report: it is your arm's accuracy spec.
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from detumbler.brain import load_rig, BrainConfig
from detumbler.calibration import error_stats, load_camera_to_base
from detumbler.frames import apply_T
from detumbler.kinematics import Arm


def grid(center, r):
    out = []
    for dx in (-r, 0, r):
        for dy in (-r, 0, r):
            for dz in (0, r):
                out.append(center + np.array([dx - r, dy, dz]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="config/arm_prototype_5dof.toml")
    ap.add_argument("--rig", default="config/rig_prototype.toml")
    ap.add_argument("--port", default=None)
    ap.add_argument("--sim", action="store_true")
    args = ap.parse_args()
    arm = Arm.from_toml(args.arm)
    rig = load_rig(args.rig)
    center = np.asarray(rig["target"]["center_in_robot_base_guess"], float)
    pts = grid(center, 0.08)
    errs = []
    if args.sim:
        from detumbler.sim import SimWorld
        world = SimWorld(rig, arm, BrainConfig.from_rig(rig), seed=3)
        cal = world.run_calibration()
        T_bc, m = cal["T_base_cam"], cal["marker_in_tool"]
        read = lambda: world.read_camera()["p_cam_tool_marker"]
        def go(q):
            world.arm_io.q = q.copy()
            return world.arm_io.read_joints()
    else:
        from detumbler.hardware import SerialArm
        from detumbler.camera import CameraPoseSource
        T_bc, m = load_camera_to_base(rig["camera"]["camera_to_base_file"])
        io = SerialArm(args.port, arm.n)
        cam = CameraPoseSource(rig)
        def read():
            got = [cam.read()["p_cam_tool_marker"] for _ in range(10)]
            got = [g for g in got if g is not None]
            return None if len(got) < 5 else np.median(got, axis=0)
        def go(q):
            io.send_joints(q)
            time.sleep(2.0)
            return io.read_joints()
    q = None
    try:
        for p in pts:
            ik = arm.ik(p, axis=[0, 0, 1], q0=q, restarts=4)
            if not ik.ok:
                continue
            q = ik.q
            q_meas = go(q)
            seen = read()
            if seen is None:
                print("marker not seen at", np.round(p, 3))
                continue
            predicted = apply_T(arm.fk(q_meas), m)
            measured = apply_T(T_bc, seen)
            errs.append(measured - predicted)
    finally:
        if not args.sim:
            io.stop()
            cam.close()
    st = error_stats(errs)
    print(f"Arm accuracy over {st['count']} points (forward kinematics vs camera):")
    print(f"  mean {st['mean_mm']:.2f} mm, RMS {st['rms_mm']:.2f} mm, 95% {st['p95_mm']:.2f} mm, max {st['max_mm']:.2f} mm")
    print(f"  average offset (x, y, z): {np.round(st['bias_mm'], 2)} mm")
    print("The mission loop measures and removes most of this with the camera (visual correction).")


if __name__ == "__main__":
    main()
