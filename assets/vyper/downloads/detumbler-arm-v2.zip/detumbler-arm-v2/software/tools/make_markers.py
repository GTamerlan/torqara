"""Print-ready ArUco markers for the target faces and the magnet holder, plus a ChArUco
board for camera calibration.

    python tools/make_markers.py --out markers/

Print at 100% scale (no "fit to page"), then MEASURE the black square with calipers and
put the measured size into config/rig_prototype.toml. A 1 mm size error is a ~2% distance error.
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import cv2
import numpy as np

from detumbler.brain import load_rig

DPI = 300


def mm_to_px(mm):
    return int(round(mm / 25.4 * DPI))


def marker_png(dictionary, marker_id, size_m, path, label):
    side = mm_to_px(size_m * 1000)
    img = cv2.aruco.generateImageMarker(dictionary, marker_id, side, borderBits=1)
    pad = mm_to_px(8)
    img = cv2.copyMakeBorder(img, pad, pad + mm_to_px(6), pad, pad, cv2.BORDER_CONSTANT, value=255)
    cv2.putText(img, label, (pad, img.shape[0] - mm_to_px(2)), cv2.FONT_HERSHEY_SIMPLEX, 1.2, 0, 2)
    cv2.imwrite(path, img)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rig", default="config/rig_prototype.toml")
    ap.add_argument("--out", default="markers")
    args = ap.parse_args()
    rig = load_rig(args.rig)
    os.makedirs(args.out, exist_ok=True)
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, rig["camera"].get("aruco_dictionary", "DICT_4X4_50")))
    for m in rig["target_marker"]:
        marker_png(d, m["id"], m["size"], os.path.join(args.out, f"target_id{m['id']}.png"),
                   f"target face id {m['id']}  black square = {m['size']*1000:.0f} mm")
    tm = rig["tool_marker"]
    faces = rig.get("tool_marker_face") or [{"id": tm["id"], "size": tm["size"]}]
    for f in faces:
        marker_png(d, f["id"], f["size"], os.path.join(args.out, f"tool_id{f['id']}.png"),
                   f"magnet boom block id {f['id']}  {f['size']*1000:.0f} mm")
    board = cv2.aruco.CharucoBoard((7, 5), 0.035, 0.026, d)
    img = board.generateImage((mm_to_px(7 * 35) + 2 * mm_to_px(10), mm_to_px(5 * 35) + 2 * mm_to_px(10)), marginSize=mm_to_px(10))
    cv2.imwrite(os.path.join(args.out, "charuco_7x5_35mm.png"), img)
    print(f"Wrote markers and calibration board to {args.out}/ at {DPI} dpi. Print at 100% scale.")


if __name__ == "__main__":
    main()
