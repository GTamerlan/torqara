"""Step 2: where is the camera relative to the robot? (and where exactly is the marker on the tool?)

    python tools/calibrate_camera_to_robot.py --port /dev/ttyUSB0      # real arm
    python tools/calibrate_camera_to_robot.py --sim                    # try it on the simulated rig

The arm visits ~24 poses in front of the camera with the wrist turned different ways. At
each one the camera measures the tool marker and forward kinematics says where the tool is.
The solver finds the camera pose in the robot base frame and the marker's offset on the
tool. Keep the target OFF the table while this runs. Expect a fit RMS of 1-3 mm; over 5 mm
usually means wrong DH numbers, a loose camera, or the marker size typed in wrong.
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from detumbler.brain import load_rig, BrainConfig
from detumbler.calibration import fit_camera_to_base, save_json, error_stats
from detumbler.frames import apply_T, inv_T, rotation_angle_deg
from detumbler.kinematics import Arm


def calibration_poses(arm, rig, n, rng):
    """Random reachable tool poses around (not through) the target, with varied wrist angles,
    each clear of the target, its stand and the table, with the boom's marker block facing the camera."""
    from detumbler.safety import Safety
    from detumbler.frames import rpy_R
    center = np.asarray(rig["target"]["center_in_robot_base_guess"], float)
    safety = Safety(rig, BrainConfig.from_rig(rig), arm)
    cam = np.asarray(rig["camera"].get("nominal_xyz", [0.3, -0.7, 0.55]), float)
    faces = [rpy_R(*np.radians(f["rpy_deg"]))[:, 2] for f in rig.get("tool_marker_face", [])]
    m_guess = np.asarray(rig["tool_marker"]["xyz_in_tool_guess"], float)
    poses = []
    tries = 0
    while len(poses) < n and tries < 8000:
        tries += 1
        p = center + rng.uniform([-0.22, -0.25, -0.02], [0.05, 0.25, 0.30])
        if np.linalg.norm(p - center) < 0.17:
            continue
        axis = rng.normal(size=3)
        axis /= np.linalg.norm(axis)
        ik = arm.ik(p, axis, q0=poses[-1] if poses else None, restarts=3, iters=150, rng=rng)
        if not ik.ok or arm.fk(ik.q)[2, 3] < rig["safety"]["min_tool_z"]:
            continue
        P, R, _ = arm.collision_points(ik.q)
        T = arm.fk(ik.q)
        if len(P):
            if safety.static_clearance(np.vstack([P, T[:3, 3]]), np.r_[R, 0.025]) < 0:
                continue
            if np.min(np.linalg.norm(P - center, axis=1) - R) < 0.14:
                continue
        if faces:
            pm = T[:3, :3] @ m_guess + T[:3, 3]
            v = (cam - pm) / np.linalg.norm(cam - pm)
            if max(float(np.dot(T[:3, :3] @ f, v)) for f in faces) < 0.5:
                continue
        poses.append(ik.q)
    return poses


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="config/arm_prototype_5dof.toml")
    ap.add_argument("--rig", default="config/rig_prototype.toml")
    ap.add_argument("--port", default=None)
    ap.add_argument("--sim", action="store_true")
    ap.add_argument("--poses", type=int, default=24)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    arm = Arm.from_toml(args.arm)
    rig = load_rig(args.rig)
    rng = np.random.default_rng(0)
    poses = calibration_poses(arm, rig, args.poses, rng)
    print(f"Planned {len(poses)} calibration poses.")

    Ts, P = [], []
    if args.sim:
        from detumbler.sim import SimWorld
        world = SimWorld(rig, arm, BrainConfig.from_rig(rig), seed=3)
        for q in poses:
            world.arm_io.q = q.copy()
            meas = world.read_camera()
            if meas["p_cam_tool_marker"] is None:
                continue
            Ts.append(arm.fk(world.arm_io.read_joints()))
            P.append(meas["p_cam_tool_marker"])
    else:
        from detumbler.hardware import SerialArm
        from detumbler.camera import CameraPoseSource
        io = SerialArm(args.port, arm.n)
        cam = CameraPoseSource(rig)
        try:
            for i, q in enumerate(poses):
                io.send_joints(q)
                time.sleep(2.5)                       # let the arm settle; increase for a wobbly arm
                q_meas = io.read_joints()
                pts = []
                for _ in range(10):                   # average 10 frames
                    m = cam.read()
                    if m["p_cam_tool_marker"] is not None:
                        pts.append(m["p_cam_tool_marker"])
                if len(pts) < 5:
                    print(f"pose {i + 1}: tool marker not seen, skipped")
                    continue
                Ts.append(arm.fk(q_meas))
                P.append(np.median(pts, axis=0))
                print(f"pose {i + 1}/{len(poses)} recorded")
        finally:
            io.stop()
            cam.close()

    res = fit_camera_to_base(Ts, np.array(P), marker_in_tool0=rig["tool_marker"]["xyz_in_tool_guess"])
    print(f"Camera -> robot fit RMS {1000 * res['rms']:.2f} mm (max {1000 * res['residuals'].max():.2f} mm) over {len(Ts)} poses")
    print(f"Marker offset on the tool: {np.round(1000 * res['marker_in_tool'], 1)} mm")
    if args.sim:
        print(f"[sim] true camera position error {1000 * np.linalg.norm(res['T_base_cam'][:3, 3] - world.T_bc_true[:3, 3]):.2f} mm, "
              f"rotation error {rotation_angle_deg(res['T_base_cam'][:3, :3], world.T_bc_true[:3, :3]):.3f} deg")
    # a simulated calibration never overwrites the real one
    out = args.out or (rig["camera"]["camera_to_base_file"].replace(".json", "_SIM.json") if args.sim
                       else rig["camera"]["camera_to_base_file"])
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    save_json(out, {"T_base_cam": res["T_base_cam"], "marker_in_tool": res["marker_in_tool"],
                    "rms_m": res["rms"], "poses": len(Ts)})
    print(f"Saved {out}")


if __name__ == "__main__":
    main()
