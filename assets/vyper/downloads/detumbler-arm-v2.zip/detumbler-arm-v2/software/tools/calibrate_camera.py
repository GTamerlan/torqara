"""Step 1: camera lens calibration (intrinsics) with the printed ChArUco board.

    python tools/calibrate_camera.py --frames 25

Hold the board in front of the camera at many angles and distances, covering the corners
of the image. Press SPACE to keep a frame, Q to finish. Aim for a reprojection error
under 0.5 px. Re-run whenever you change the focus, zoom or resolution.

    python tools/calibrate_camera.py --images "shots/*.png"   # or calibrate from saved photos
"""
import argparse
import glob
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import cv2
import numpy as np

from detumbler.brain import load_rig


def collect(board, detector, images):
    obj, img, size = [], [], None
    for im in images:
        gray = im if im.ndim == 2 else cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        size = gray.shape[::-1]
        corners, ids, _, _ = detector.detectBoard(gray)
        if ids is not None and len(ids) >= 8:
            o, i = board.matchImagePoints(corners, ids)
            obj.append(o)
            img.append(i)
    return obj, img, size


def calibrate(board, detector, images):
    obj, img, size = collect(board, detector, images)
    if len(obj) < 8:
        raise SystemExit(f"Only {len(obj)} usable views; need at least 8 (25 is better).")
    rms, K, dist, _, _ = cv2.calibrateCamera(obj, img, size, None, None)
    return rms, K, dist, size, len(obj)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rig", default="config/rig_prototype.toml")
    ap.add_argument("--frames", type=int, default=25)
    ap.add_argument("--images", default=None, help="glob of saved images instead of the live camera")
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    rig = load_rig(args.rig)
    cam = rig["camera"]
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, cam.get("aruco_dictionary", "DICT_4X4_50")))
    board = cv2.aruco.CharucoBoard((7, 5), 0.035, 0.026, d)
    detector = cv2.aruco.CharucoDetector(board)
    images = []
    if args.images:
        images = [cv2.imread(p) for p in sorted(glob.glob(args.images))]
    else:
        cap = cv2.VideoCapture(cam.get("index", 0))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, cam.get("width", 1280))
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cam.get("height", 720))
        while len(images) < args.frames:
            ok, frame = cap.read()
            if not ok:
                continue
            view = frame.copy()
            corners, ids, _, _ = detector.detectBoard(frame)
            if ids is not None:
                cv2.aruco.drawDetectedCornersCharuco(view, corners, ids)
            cv2.putText(view, f"kept {len(images)}/{args.frames}  SPACE keep, Q finish", (20, 40), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 200, 255), 2)
            cv2.imshow("calibrate camera", view)
            k = cv2.waitKey(1) & 0xFF
            if k == ord(" ") and ids is not None and len(ids) >= 8:
                images.append(frame)
            elif k == ord("q"):
                break
        cap.release()
        cv2.destroyAllWindows()
    rms, K, dist, size, n = calibrate(board, detector, images)
    out = args.out or cam["intrinsics_file"]
    os.makedirs(os.path.dirname(out) or ".", exist_ok=True)
    with open(out, "w") as f:
        json.dump({"K": K.tolist(), "dist": dist.ravel().tolist(), "image_size": list(size), "rms_px": rms, "views": n}, f, indent=2)
    print(f"Saved {out}: reprojection RMS {rms:.3f} px from {n} views. Under 0.5 px is good; over 1 px, redo it.")


if __name__ == "__main__":
    main()
