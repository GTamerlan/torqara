"""Self-checks for the whole real-world stack. No hardware needed.

    python tests/run_tests.py          # a few minutes
    python tests/run_tests.py --quick  # skips the full mission simulations
"""
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np

from detumbler.frames import (qmul, qexp, qlog, qrot, R_from_quat, quat_from_R, R_from_rotvec, make_T, inv_T,
                              apply_T, rotation_angle_deg, rpy_R, unit)
from detumbler.kinematics import Arm
from detumbler.calibration import fit_rigid, fit_camera_to_base, pivot_calibration
from detumbler.brain import load_rig, BrainConfig, Brain, Estimator
from detumbler.vision import cv2

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARM = os.path.join(HERE, "config", "arm_example_6dof.toml")
RIG = os.path.join(HERE, "config", "rig_tabletop.toml")
results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(f"[{'PASS' if cond else 'FAIL'}] {name}  {detail}")


def test_frames(rng):
    worst = 0.0
    for _ in range(200):
        rv = rng.normal(size=3)
        q = qexp(rv)
        R = R_from_quat(q)
        worst = max(worst, np.abs(R - R_from_quat(quat_from_R(R))).max(), np.linalg.norm(qrot(q, [1, 2, 3]) - R @ [1, 2, 3]),
                    np.linalg.norm(R_from_rotvec(qlog(q)) - R))
    T = make_T(rpy_R(0.3, -0.2, 1.1), [0.1, 0.2, 0.3])
    check("rotations and transforms are consistent", worst < 1e-9 and np.allclose(inv_T(T) @ T, np.eye(4)), f"worst {worst:.1e}")


def test_kinematics(rng):
    arm = Arm.from_toml(ARM)
    q = rng.uniform(arm.lower, arm.upper) * 0.6
    J = arm.jacobian(q)
    Jn = np.zeros((3, arm.n))
    for i in range(arm.n):
        d = np.zeros(arm.n); d[i] = 1e-6
        Jn[:, i] = (arm.fk(q + d)[:3, 3] - arm.fk(q - d)[:3, 3]) / 2e-6
    check("Jacobian matches finite differences", np.abs(J[:3] - Jn).max() < 1e-7, f"max diff {np.abs(J[:3] - Jn).max():.1e}")
    ok, errs = 0, []
    for _ in range(30):
        qt = rng.uniform(arm.lower, arm.upper) * 0.8
        T = arm.fk(qt)
        r = arm.ik(T[:3, 3], T[:3, 2], rng=rng)
        ok += r.ok
        errs.append(r.pos_err)
    check("inverse kinematics hits position + spin axis", ok >= 29, f"{ok}/30 solved, worst {1000 * max(errs):.2f} mm")
    q = np.radians([0, 60, 20, 0, 40, 0])
    goal = arm.fk(q)[:3, 3] + np.array([-0.05, 0.08, -0.04])
    path_dev = 0.0
    start = arm.fk(q)[:3, 3]
    for _ in range(300):
        q, _ = arm.dls_step(q, goal, axis=[0, 1, 0], max_joint_step=np.radians(1))
        p = arm.fk(q)[:3, 3]
        dline = (goal - start) / np.linalg.norm(goal - start)
        path_dev = max(path_dev, np.linalg.norm((p - start) - dline * np.dot(p - start, dline)))
    check("resolved-rate steps converge along a near-straight path",
          np.linalg.norm(arm.fk(q)[:3, 3] - goal) < 1e-3 and path_dev < 0.02,
          f"final {1000 * np.linalg.norm(arm.fk(q)[:3, 3] - goal):.2f} mm, max path deviation {1000 * path_dev:.1f} mm")


def test_calibration(rng):
    A = rng.normal(size=(30, 3))
    T = make_T(R_from_rotvec(rng.normal(size=3)), rng.normal(size=3))
    Tf, rms, _ = fit_rigid(A, apply_T(T, A))
    check("rigid point fit recovers a known transform", np.allclose(Tf, T, atol=1e-9))
    arm = Arm.from_toml(ARM)
    T_bc = make_T(rpy_R(*np.radians([-110, 3, -8])), [0.05, -0.62, 0.48])
    m_true = np.array([0.012, -0.018, 0.035])
    Ts, P = [], []
    while len(Ts) < 20:
        q = rng.uniform(arm.lower, arm.upper) * 0.6
        Tt = arm.fk(q)
        if Tt[2, 3] < 0.05:
            continue
        Ts.append(Tt)
        P.append(apply_T(inv_T(T_bc), apply_T(Tt, m_true)) + rng.normal(0, 0.0007, 3))
    r = fit_camera_to_base(Ts, np.array(P))
    pe = 1000 * np.linalg.norm(r["T_base_cam"][:3, 3] - T_bc[:3, 3])
    check("camera-to-robot calibration with 0.7 mm noise", pe < 2.0 and np.linalg.norm(r["marker_in_tool"] - m_true) < 0.002,
          f"camera {pe:.2f} mm, {rotation_angle_deg(r['T_base_cam'][:3, :3], T_bc[:3, :3]):.3f} deg off; marker {1000 * np.linalg.norm(r['marker_in_tool'] - m_true):.2f} mm off")
    tip, piv = np.array([0.004, -0.006, 0.071]), np.array([0.35, 0.1, 0.15])
    Tl = []
    for _ in range(15):
        R = R_from_rotvec(rng.normal(0, 0.5, 3))
        Tl.append(make_T(R, piv - R @ tip + rng.normal(0, 0.0003, 3)))
    m, p, rms = pivot_calibration(Tl)
    check("tool-center pivot calibration", np.linalg.norm(m - tip) < 0.001, f"tip {1000 * np.linalg.norm(m - tip):.2f} mm off")


def test_vision(rng):
    if cv2 is None:
        check("marker pose from camera images (skipped: no OpenCV)", True)
        return
    from detumbler.vision import MarkerBody, ArucoPoseTracker, box_face_markers, marker_corners_local
    K = np.array([[900, 0, 640], [0, 900, 360], [0, 0, 1.0]])
    body = MarkerBody.from_config("target", box_face_markers([0.08, 0.065, 0.055], 0.06))
    d = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_4X4_50)
    tr = ArucoPoseTracker(K, np.zeros(5))
    errs_t, errs_r = [], []
    for _ in range(15):
        T_co = make_T(R_from_rotvec(rng.normal(0, 1.0, 3)), [rng.uniform(-0.05, 0.05), rng.uniform(-0.03, 0.03), rng.uniform(0.55, 0.75)])
        img = np.full((720, 1280), 90, np.uint8)
        faces = []
        for mid, (Tbm, s) in body.markers.items():
            Tcm = T_co @ Tbm
            c = Tcm[:3, 3]
            if np.dot(Tcm[:3, 2], -c) / np.linalg.norm(c) > 0.05:
                faces.append((np.linalg.norm(c), mid, Tcm, s))
        for _, mid, Tcm, s in sorted(faces, reverse=True):
            mk = cv2.copyMakeBorder(cv2.aruco.generateImageMarker(d, mid, 200, borderBits=1), 40, 40, 40, 40, cv2.BORDER_CONSTANT, value=255)
            dst, _ = cv2.projectPoints(marker_corners_local(s * 280 / 200), cv2.Rodrigues(Tcm[:3, :3])[0], Tcm[:3, 3], K, np.zeros(5))
            H = cv2.getPerspectiveTransform(np.float32([[0, 0], [279, 0], [279, 279], [0, 279]]), dst.reshape(4, 2).astype(np.float32))
            warped = cv2.warpPerspective(mk, H, (1280, 720))
            mask = cv2.warpPerspective(np.full_like(mk, 255), H, (1280, 720), flags=cv2.INTER_NEAREST)
            img[mask > 0] = warped[mask > 0]
        img = np.clip(img + rng.normal(0, 3, img.shape), 0, 255).astype(np.uint8)
        res = tr.body_pose(tr.detect(img), body, prior_T_cam_body=T_co)
        if res:
            errs_t.append(1000 * np.linalg.norm(res["T_cam_body"][:3, 3] - T_co[:3, 3]))
            errs_r.append(rotation_angle_deg(res["T_cam_body"][:3, :3], T_co[:3, :3]))
    check("marker pose from rendered camera images", len(errs_t) >= 14 and np.mean(errs_t) < 3 and np.mean(errs_r) < 1.0,
          f"{len(errs_t)}/15 seen, mean {np.mean(errs_t):.2f} mm / {np.mean(errs_r):.2f} deg")


def test_brain(rng):
    rig = load_rig(RIG)
    cfg = BrainConfig.from_rig(rig)
    est = Estimator(cfg)
    q, w = qexp(rng.normal(size=3)), np.radians([3.0, 40.0, 2.0])
    I = cfg.inertia_est
    for k in range(300):
        dt = 1 / 30
        for _ in range(10):
            wd = np.array([(I[1] - I[2]) * w[1] * w[2] / I[0], (I[2] - I[0]) * w[2] * w[0] / I[1], (I[0] - I[1]) * w[0] * w[1] / I[2]])
            q = qmul(q, qexp(w * dt / 10)); q /= np.linalg.norm(q)
            w = w + wd * dt / 10
        est.predict(dt)
        est.update(qmul(q, qexp(rng.normal(0, np.radians(0.5), 3))), k * dt)
    err = np.degrees(np.linalg.norm(qrot(q, w) - est.world_rate()))
    check("tumble estimator locks on and tracks the spin", est.locked and err < 1.5, f"rate error {err:.2f} deg/s after 10 s")
    b = Brain(cfg)
    b.est = est
    b.t = 10.0
    dirs = b.planner.dirs
    saf = b.safety_radius(dirs)
    plan = b.safe_radius(dirs)
    # brute-force check: the true hull over the next second never reaches the safety radius
    worst = 1.0
    qq, ww = q.copy(), w.copy()
    for _ in range(30):
        for _ in range(5):
            wd = np.array([(I[1] - I[2]) * ww[1] * ww[2] / I[0], (I[2] - I[0]) * ww[2] * ww[0] / I[1], (I[0] - I[1]) * ww[0] * ww[1] / I[2]])
            qq = qmul(qq, qexp(ww / 150)); qq /= np.linalg.norm(qq)
            ww = ww + wd / 150
        sup = np.abs(dirs @ R_from_quat(qq)) @ cfg.half_extents
        worst = min(worst, float(np.min(saf - cfg.mag_radius - sup)))
    check("safety envelope contains the true hull for the next second", worst > 0, f"smallest clearance {1000 * worst:.1f} mm")
    check("planning radius never inside the safety radius", np.all(plan >= saf), "")


def test_sweep_dissipation(rng):
    """Proposition 1 of the paper, in the code: with the rotor speed computed for the tool's ACTUAL axis,
    the eddy force never adds energy to the target, whatever the axis misalignment, attitude or spin."""
    from detumbler.brain import eddy_patch
    from detumbler.frames import qrot_inv
    cfg = BrainConfig.from_rig(load_rig(os.path.join(HERE, "config", "rig_prototype.toml")))
    worst, n_spun, n = -np.inf, 0, 0
    for _ in range(300):
        b = Brain(cfg, mode="spin")
        b.est.init, b.est.locked = True, True
        b.est.q = unit(rng.normal(size=4))
        b.est.w = np.radians(rng.uniform(5, 60)) * unit(rng.normal(size=3))
        b.set_auto(True)
        b.phase = "detumble"
        d = unit(rng.normal(size=3))
        p_rel = d * (float(np.linalg.norm(cfg.half_extents)) + cfg.r_head + rng.uniform(0.002, 0.03))
        b.tick(1 / 30, 1.0, p_rel)
        axis_act = unit(rng.normal(size=3))                  # any tool axis at all, aligned or not
        b._sweep_act = 0.0
        b._dt = cfg.sweep_tau                                # one full filter step: the commanded speed itself
        rpm = b.rpm_for_axis(axis_act)
        toward = -d
        vf = rpm * 2 * np.pi / 60 * cfg.mag_radius * np.cross(axis_act, toward)
        r = eddy_patch(cfg, b.est.q, b.est.w, p_rel, vf_body=qrot_inv(b.est.q, vf))
        if r is None:
            continue
        power = float(r["Fb"] @ np.cross(b.est.w, r["rp"]))    # F . v = dE/dt of the target
        static = eddy_patch(cfg, b.est.q, b.est.w, p_rel, vf_body=np.zeros(3))
        p_static = float(static["Fb"] @ np.cross(b.est.w, static["rp"]))
        worst = max(worst, power - p_static)                 # spinning must never brake less than static
        n += 1
        n_spun += abs(rpm) > 1e-6
    check("sweep law removes at least as much energy as a static magnet, for any axis", worst <= 1e-12 and n_spun > 0.8 * n,
          f"{n} random states, rotor running in {n_spun}, worst extra power {worst:.2e} W")


PROTO_ARM = os.path.join(HERE, "config", "arm_prototype_5dof.toml")
PROTO_RIG = os.path.join(HERE, "config", "rig_prototype.toml")


def test_prototype(rng):
    """The CAD-matched 5-axis prototype: spots reachable without any link entering the hull envelope,
    and the link check really catches a forearm through the target."""
    from detumbler.safety import Safety
    from detumbler.brain import fibonacci_dirs
    arm = Arm.from_toml(PROTO_ARM)
    rig = load_rig(PROTO_RIG)
    cfg = BrainConfig.from_rig(rig)
    saf = Safety(rig, cfg, arm)
    b = Brain(cfg)
    b.est.init, b.est.locked, b.est.q, b.est.w, b.t = True, True, np.array([1.0, 0, 0, 0]), np.radians([2, 1, 40.0]), 1.0
    c = np.asarray(rig["target"]["center_in_robot_base_guess"], float)
    ok = tot = 0
    for d in fibonacci_dirs(260):
        if abs(d[2]) > cfg.equator_dot or d[0] > 0.3:          # the spots the planner may use on this rig (robot side)
            continue
        p = c + float(b.safe_radius(d)[0]) * d
        if not saf.workspace_ok(p):
            continue
        a = np.array([0, 0, 1.0]) - d * d[2]
        tot += 1
        r = arm.ik(p, axis=a / np.linalg.norm(a), restarts=6, iters=200, rng=rng)
        if r.ok:
            P, R, _ = arm.collision_points(r.q)
            if b.link_clearance(P - c, R, d) >= 0 and saf.static_clearance(np.vstack([P, p]), np.r_[R, cfg.r_head]) >= 0:
                ok += 1
    check("prototype arm reaches the equatorial spots with every link clear", tot > 0 and ok >= 0.8 * tot, f"{ok}/{tot} spots")
    # forearm straight through the target: must be flagged
    q_bad = arm.ik(c + np.array([0.0, 0.0, 0.0]), axis=None, restarts=8, iters=300, rng=rng).q
    P, R, _ = arm.collision_points(q_bad)
    check("link check flags an arm driven into the target", b.link_clearance(P - c, R, None) < 0, "")


V2_ARM = os.path.join(HERE, "config", "arm_v2_5dof.toml")
V2_RIG = os.path.join(HERE, "config", "rig_v2.toml")


def test_v2(rng):
    """Arm v2 on the free-gimbal rig: the drive interpolator respects the limits, the gimbal geometry is sane, and
    the arm reaches the spots on the open side of the ring with every link clear of the hull envelope AND the gimbal."""
    from detumbler.hardware import RefShaper
    from detumbler.safety import Safety
    from detumbler.brain import fibonacci_dirs
    from detumbler.gimbal import ExternalGimbal
    sh = RefShaper(np.zeros(2), vmax=[1.0, 2.0], amax=[2.0, 4.0])
    vmax_seen = np.zeros(2)
    amax_seen = np.zeros(2)
    v_prev = np.zeros(2)
    dt = 1e-3
    for k in range(3000):
        q, v = sh.update(np.array([1.5, -3.0]) if k < 1500 else np.zeros(2), dt)
        vmax_seen = np.maximum(vmax_seen, np.abs(v))
        amax_seen = np.maximum(amax_seen, np.abs(v - v_prev) / dt)
        v_prev = v
    check("drive interpolator keeps velocity and acceleration within limits", np.all(vmax_seen <= [1.0 + 1e-9, 2.0 + 1e-9]) and np.all(amax_seen <= [2.0 + 1e-6, 4.0 + 1e-6]),
          f"v max {vmax_seen}, a max {amax_seen}")
    rig = load_rig(V2_RIG)
    g = ExternalGimbal(rig["gimbal"])
    R = np.eye(3)
    A, B, r = g.capsule_arrays(R, exact=True)
    # at the home attitude the ring is horizontal: a point straight above the center at 0.3 m is far from it, a point
    # on the ring circle is inside it
    far = g.sphere_clearance(np.array([[0, 0, 0.3]]), [0.0], [R])
    on = g.sphere_clearance(np.array([[rig["gimbal"]["ring_radius"], 0, 0]]), [0.0], [R])
    check("gimbal model: ring horizontal at home, pins along x", far > 0.05 and on < 0 and abs(A[0][1]) < 1e-9, f"above {far:.3f} m, on the ring {on:.3f} m")
    arm = Arm.from_toml(V2_ARM)
    cfg = BrainConfig.from_rig(rig)
    saf = Safety(rig, cfg, arm)
    b = Brain(cfg)
    b.est.init, b.est.locked, b.est.q, b.est.w, b.t = True, True, np.array([1.0, 0, 0, 0]), np.radians([40.0, 2, 1]), 1.0
    c = np.asarray(rig["target"]["center_in_robot_base_guess"], float)
    ok = tot = 0
    for d in fibonacci_dirs(260):
        if d[2] < cfg.ring_side_dot or d[0] > 0.3:               # open side of the ring, robot side
            continue
        p = c + float(b.safe_radius(d)[0]) * d
        if not saf.workspace_ok(p):
            continue
        a = np.array([1.0, 0, 0]) - d * d[0]
        tot += 1
        for sgn in (1.0, -1.0):
            r_ik = arm.ik(p, axis=sgn * a / np.linalg.norm(a), restarts=6, iters=200, rng=rng)
            if r_ik.ok:
                P, Rr, _ = arm.collision_points(r_ik.q)
                if b.link_clearance(P - c, Rr, d) >= 0 and saf.static_clearance(np.vstack([P, p]), np.r_[Rr, cfg.r_head]) >= 0 \
                        and b.gimbal_clearance(np.vstack([P, p]) - c, np.r_[Rr, cfg.r_head]) >= 0:
                    ok += 1
                    break
    check("arm v2 reaches the spots over the ring with every link clear of hull and gimbal", tot > 0 and ok >= 0.4 * tot, f"{ok}/{tot} spots (either boom direction; the planner only uses spots that pass this check)")


def test_v2_mission():
    from detumbler.simrun import run_sim
    t0 = time.time()
    r = run_sim(V2_ARM, load_rig(V2_RIG), seconds=60, seed=11, mode="spin", spin_dps=(40, 4, 2))
    ok = r["collisions"] == 0 and r["link_contacts"] == 0 and r["static_contacts"] == 0 and r["gimbal_contacts"] == 0 and r["final_true_spin_dps"] < 30
    check("full mission, arm v2 on the free-gimbal rig (kinematic world): no contacts, braking", ok,
          f"40 deg/s -> {r['final_true_spin_dps']:.2f} deg/s, magnet gap >= {r['min_true_gap_mm']:.1f} mm, gimbal gap >= {r['min_gimbal_gap_mm']:.1f} mm, "
          f"contacts {r['collisions']}/{r['link_contacts']}/{r['static_contacts']}/{r['gimbal_contacts']} ({time.time() - t0:.0f} s)")


def test_missions():
    from detumbler.simrun import run_sim
    rig = load_rig(RIG)
    for name, spin, mode in (("flat spin 50 deg/s", (5, 50, 5), "spin"), ("chaotic flip", (2, 40, 3), "still")):
        t0 = time.time()
        r = run_sim(ARM, rig, seconds=50, seed=12, mode=mode, spin_dps=spin)
        ok = r["collisions"] == 0 and r["final_true_spin_dps"] < 1.5
        stable = "not yet" if r["time_to_stable_s"] is None else f"{r['time_to_stable_s']:.1f} s"
        check(f"full mission (example arm), {name}, {mode} magnet", ok,
              f"spin {spin} -> {r['final_true_spin_dps']:.2f} deg/s, stable at {stable}, min gap {r['min_true_gap_mm']:.1f} mm, "
              f"contacts {r['collisions']}, magnet position known to {r['magnet_position_error_mm_mean']:.2f} mm ({time.time() - t0:.0f} s)")


def test_prototype_mission():
    from detumbler.simrun import run_sim
    t0 = time.time()
    r = run_sim(PROTO_ARM, load_rig(PROTO_RIG), seconds=60, seed=11, mode="spin", spin_dps=(3, 2, 40))
    ok = r["collisions"] == 0 and r["link_contacts"] == 0 and r["static_contacts"] == 0 and r["final_true_spin_dps"] < 1.5
    stable = "not yet" if r["time_to_stable_s"] is None else f"{r['time_to_stable_s']:.1f} s"
    check("full mission, 5-axis prototype on its gimbal rig", ok,
          f"40 deg/s -> {r['final_true_spin_dps']:.2f} deg/s, stable at {stable}, magnet gap >= {r['min_true_gap_mm']:.1f} mm, "
          f"links >= {r['min_link_gap_mm']:.1f} mm, contacts {r['collisions']}/{r['link_contacts']}/{r['static_contacts']} ({time.time() - t0:.0f} s)")


if __name__ == "__main__":
    rng = np.random.default_rng(42)
    test_frames(rng)
    test_kinematics(rng)
    test_calibration(rng)
    test_vision(rng)
    test_brain(rng)
    test_sweep_dissipation(rng)
    test_prototype(rng)
    test_v2(rng)
    if "--quick" not in sys.argv:
        test_missions()
        test_prototype_mission()
        test_v2_mission()
    failed = [n for n, ok, _ in results if not ok]
    print(f"\n{len(results) - len(failed)}/{len(results)} checks passed")
    sys.exit(1 if failed else 0)
