// Detumbler arm controller (template)
// Board: Arduino Mega / ESP32, PCA9685 servo driver for the joints, H-bridge for the magnet motor.
// Talks the line protocol in detumbler/hardware.py:
//   J d1 .. dN   joint targets in degrees (firmware 0 deg == DH zero of each joint)
//   M rpm        magnet motor speed, signed
//   S            stop: motor off, hold joints where they are
//   ?            reply with "A d1 .. dN" (current joint angles)
//
// This is a starting point, not a finished controller. Fill in the per-joint calibration
// table for YOUR servos and wiring before powering the arm.
//
// Important hardware notes
// - Hobby servos report no position. This sketch replies with its own interpolated command,
//   so the host's visual correction (camera watching the magnet holder) is what makes the
//   gap accurate. Joint encoders improve things a lot.
// - Do NOT use magnetic encoders (AS5600 and similar) or Hall sensors near the magnet:
//   a 40 mm N52 magnet will corrupt them. Use optical encoders or keep them 15+ cm away.
// - Keep steel screws, brackets and the motor's own steel away from the magnet; mount it on
//   an aluminum or plastic hub, and balance it before spinning above a few hundred rpm.

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

const int N_JOINTS = 6;
Adafruit_PWMServoDriver pwm(0x40);

struct Joint {
  uint8_t ch;         // PCA9685 channel
  float us_zero;      // pulse width (microseconds) at the joint's DH zero
  float us_per_deg;   // microseconds per degree; negative flips direction
  float min_deg, max_deg;
  float max_dps;      // firmware speed limit (second safety layer, keep <= the host config)
};

// TODO: measure these for your arm (move each joint to its DH zero, note the pulse width;
// move it +90 deg, note again; us_per_deg = difference / 90).
Joint J[N_JOINTS] = {
  {0, 1500, 10.0, -170, 170, 60},
  {1, 1500, 10.0,  -10, 190, 45},
  {2, 1500, 10.0, -150, 150, 60},
  {3, 1500, 10.0, -180, 180, 90},
  {4, 1500, 10.0, -120, 120, 90},
  {5, 1500, 10.0, -180, 180, 120},
};

// Magnet motor: DC gearmotor or BLDC driver with direction + PWM inputs.
const int MOTOR_PWM_PIN = 9;
const int MOTOR_DIR_PIN = 8;
const float MOTOR_MAX_RPM = 600.0;   // rpm at full PWM, measure it; open loop is approximate

float cmd_deg[N_JOINTS];
float cur_deg[N_JOINTS];
float motor_rpm = 0;
unsigned long last_cmd_ms = 0;
const unsigned long WATCHDOG_MS = 300;   // no host command for this long: motor off, hold joints
unsigned long last_step_ms = 0;
String line;

void writeJoint(int i, float deg) {
  float us = J[i].us_zero + deg * J[i].us_per_deg;
  pwm.writeMicroseconds(J[i].ch, (uint16_t)constrain(us, 500, 2500));
}

void setMotor(float rpm) {
  rpm = constrain(rpm, -MOTOR_MAX_RPM, MOTOR_MAX_RPM);
  motor_rpm = rpm;
  digitalWrite(MOTOR_DIR_PIN, rpm >= 0 ? HIGH : LOW);
  analogWrite(MOTOR_PWM_PIN, (int)(255.0 * fabs(rpm) / MOTOR_MAX_RPM));
}

void reply() {
  Serial.print("A");
  for (int i = 0; i < N_JOINTS; i++) { Serial.print(' '); Serial.print(cur_deg[i], 3); }
  Serial.println();
}

void handle(String s) {
  s.trim();
  if (s.length() == 0) return;
  char c = s.charAt(0);
  if (c == 'J') {
    int idx = 0, start = 1;
    while (idx < N_JOINTS && start < (int)s.length()) {
      int sp = s.indexOf(' ', start + 1);
      if (sp < 0) sp = s.length();
      String tok = s.substring(start, sp); tok.trim();
      if (tok.length()) {
        cmd_deg[idx] = constrain(tok.toFloat(), J[idx].min_deg, J[idx].max_deg);
        idx++;
      }
      start = sp;
    }
    last_cmd_ms = millis();
  } else if (c == 'M') {
    setMotor(s.substring(1).toFloat());
    last_cmd_ms = millis();
  } else if (c == 'S') {
    setMotor(0);
    for (int i = 0; i < N_JOINTS; i++) cmd_deg[i] = cur_deg[i];
  } else if (c == '?') {
    reply();
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(MOTOR_DIR_PIN, OUTPUT);
  pinMode(MOTOR_PWM_PIN, OUTPUT);
  setMotor(0);
  pwm.begin();
  pwm.setOscillatorFrequency(27000000);
  pwm.setPWMFreq(50);
  for (int i = 0; i < N_JOINTS; i++) { cur_deg[i] = 0; cmd_deg[i] = 0; writeJoint(i, 0); }
  last_step_ms = millis();
}

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n') { handle(line); line = ""; }
    else if (line.length() < 120) line += ch;
  }
  unsigned long now = millis();
  if (now - last_step_ms >= 20) {                 // 50 Hz servo update, speed limited
    float dt = (now - last_step_ms) / 1000.0;
    last_step_ms = now;
    for (int i = 0; i < N_JOINTS; i++) {
      float step = constrain(cmd_deg[i] - cur_deg[i], -J[i].max_dps * dt, J[i].max_dps * dt);
      cur_deg[i] += step;
      writeJoint(i, cur_deg[i]);
    }
  }
  if (now - last_cmd_ms > WATCHDOG_MS && motor_rpm != 0) setMotor(0);   // host went quiet
}
