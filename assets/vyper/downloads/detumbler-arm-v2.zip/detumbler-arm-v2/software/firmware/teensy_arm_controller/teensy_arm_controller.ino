// Detumbler prototype arm controller -- Teensy 4.1
//
// Drives the five joint steppers (step/dir), reads a CUI AMT22 capacitive absolute encoder on the
// back shaft of every motor (immune to the magnet, unlike magnetic encoders), homes each joint on an
// optical flag, commands the magnet's BLDC through an ODrive S1, and watches the E-stop chain.
//
// Host protocol (115200 baud over USB, one command per line). Same as detumbler/hardware.py SerialArm:
//   J d1 d2 d3 d4 d5   joint targets in degrees (DH convention, firmware 0 = DH zero)
//   M rpm              magnet speed, signed (positive = right-handed about the tool z axis)
//   S                  stop: magnet off, joints hold where they are
//   ?                  reply "A d1 .. d5" (joint angles from the encoders)
//   H                  home all joints (wrist first), then go to the home pose
//   E                  reply "E <state> <fault bits> <estop>"
//   R                  clear faults (only after the E-stop is released and power is back)
//
// Safety layers in this file (the host software has its own, stricter ones):
//   - per-joint position limits, speed limits and acceleration ramps
//   - step-loss detection: encoder vs. commanded position, > STEP_LOSS_DEG -> fault, stop
//   - host watchdog: no command for 300 ms -> magnet off, joints hold
//   - E-stop input from the safety relay: steppers disabled, magnet off, fault latched until 'R'
//   - nothing moves until the arm has been homed
//
// Wiring summary (see the build plan for the full table):
//   Steppers: STEP/DIR/EN per axis -> DM542T (J1, J2, 24 V, 2.8 A) and TMC2209 (J3-J5, 1.5-1.7 A)
//   Encoders: AMT22 on SPI (SCK 13, MOSI 11, MISO 12), one chip select per axis
//   Home flags: optical slot sensors, open-collector to 3.3 V with pull-ups
//   ODrive S1: Serial2 (pins 7 RX2, 8 TX2), 115200 baud, axis0 in velocity control with its AMT10x encoder
//   E-stop: safety relay auxiliary NO contact to pin 22 (LOW = E-stop OK)

#include <Arduino.h>
#include <SPI.h>

const int N = 5;

struct Axis {
  // pins
  uint8_t step, dir, en, cs, home;
  // calibration -- MEASURE AND FILL IN for your build
  float steps_per_deg;     // 200 steps * microsteps * gear ratio / 360
  int8_t dir_sign;         // +1 or -1 so that positive steps = positive DH angle
  int8_t enc_sign;         // +1 or -1 so that encoder counts increase with positive DH angle
  float home_deg;          // DH angle at which the home flag triggers
  int8_t home_dir;         // direction to seek the flag (+1 / -1)
  float min_deg, max_deg;  // soft limits (inside the mechanical stops)
  float vmax_dps;          // max speed [deg/s]  (keep <= the host config)
  float amax_dps2;         // max acceleration [deg/s^2]
  // state
  volatile int32_t pos_steps;
  volatile float rate_sps;   // signed step rate written by the 1 kHz loop, read by the step ISR
  float target_deg;
  float vel_dps;
  int32_t enc_turns;
  int16_t enc_last;
  float enc_deg;
};

// 16 microsteps everywhere. Ratios: J1, J2, J3 = 50:1 strain-wave; J4 = 5.18 planetary x 5 belt; J5 = 30:1 strain-wave.
Axis ax[N] = {
  // step dir en  cs home  steps/deg                  ds es  home   hd   min    max    vmax amax
  {  2,   3,  4, 10,  30,  200 * 16 * 50.0 / 360.0,   1, 1,  170.0, +1, -170.0, 170.0, 40,  80 },
  {  5,   6,  4, 36,  31,  200 * 16 * 50.0 / 360.0,   1, 1,  180.0, +1,    0.0, 180.0, 36,  60 },
  { 24,  25,  4, 37,  32,  200 * 16 * 50.0 / 360.0,   1, 1, -140.0, -1, -140.0, 140.0, 60, 120 },
  { 26,  27,  4, 38,  33,  200 * 16 * 25.9 / 360.0,   1, 1,    0.0, +1, -350.0, 350.0, 120, 240 },
  { 28,  29,  4, 39,  34,  200 * 16 * 30.0 / 360.0,   1, 1,  115.0, +1, -115.0, 115.0, 90, 180 },
};
// NOTE: J4 has no hard stop inside +-350 deg; its home flag sits at 0 deg and the cable loop allows +-355.

const uint8_t PIN_ESTOP_OK = 22;     // LOW = safety relay closed (E-stop released, motor power on)
const uint8_t PIN_STATUS_LED = 23;
const float STEP_LOSS_DEG = 0.6;     // joint-side error that counts as lost steps
const uint32_t WATCHDOG_MS = 300;
const float HOME_SPEED_DPS = 8.0;
const float MAGNET_MAX_RPM = 600.0;

enum State { NOT_HOMED, HOMING, READY, FAULT };
volatile State state = NOT_HOMED;
uint32_t faults = 0;                 // bit i: axis i step loss; bit 8: limit; bit 9: estop; bit 10: encoder
uint32_t last_cmd_ms = 0;
float magnet_rpm = 0;
IntervalTimer stepTimer;
const float ISR_HZ = 40000.0;
volatile float phase[N];

// ---------------------------------------------------------------- step generation (40 kHz)
void stepISR() {
  for (int i = 0; i < N; i++) {
    float r = ax[i].rate_sps;
    if (r == 0) continue;
    phase[i] += fabsf(r) / ISR_HZ;
    if (phase[i] >= 1.0f) {
      phase[i] -= 1.0f;
      bool fwd = r > 0;
      digitalWriteFast(ax[i].dir, (fwd ^ (ax[i].dir_sign < 0)) ? HIGH : LOW);
      delayNanoseconds(200);
      digitalWriteFast(ax[i].step, HIGH);
      delayNanoseconds(2500);          // DM542T needs >= 2.5 us pulses
      digitalWriteFast(ax[i].step, LOW);
      ax[i].pos_steps += fwd ? 1 : -1;
    }
  }
}

// ---------------------------------------------------------------- AMT22 capacitive encoders (SPI)
SPISettings amt22(2000000, MSBFIRST, SPI_MODE0);

bool amt22Read(uint8_t cs, int16_t &pos14) {
  SPI.beginTransaction(amt22);
  digitalWriteFast(cs, LOW);
  delayMicroseconds(3);
  uint8_t hi = SPI.transfer(0x00);
  delayMicroseconds(3);
  uint8_t lo = SPI.transfer(0x00);
  delayMicroseconds(3);
  digitalWriteFast(cs, HIGH);
  SPI.endTransaction();
  uint16_t v = ((uint16_t)hi << 8) | lo;
  // checksum: K1 (bit 15) = odd parity of odd bits, K0 (bit 14) = odd parity of even bits
  bool k1 = (v >> 15) & 1, k0 = (v >> 14) & 1;
  bool odd = 1, even = 1;
  for (int b = 13; b >= 1; b -= 2) odd ^= (v >> b) & 1;
  for (int b = 12; b >= 0; b -= 2) even ^= (v >> b) & 1;
  if (k1 != odd || k0 != even) return false;
  pos14 = v & 0x3FFF;
  return true;
}

// motor revolutions -> joint degrees: the encoder sits on the motor, so unwrap turns
void updateEncoder(int i) {
  int16_t p;
  if (!amt22Read(ax[i].cs, p)) { faults |= (1u << 10); return; }
  int d = p - ax[i].enc_last;
  if (d > 8192) ax[i].enc_turns--;
  else if (d < -8192) ax[i].enc_turns++;
  ax[i].enc_last = p;
  float motor_rev = ax[i].enc_turns + p / 16384.0f;
  float deg_per_rev = 200.0f * 16.0f / ax[i].steps_per_deg;
  ax[i].enc_deg = ax[i].enc_sign * motor_rev * deg_per_rev;
}

float stepsToDeg(int i) { return ax[i].pos_steps / ax[i].steps_per_deg; }

// encoder offset is set at homing so that enc_deg + enc_offset = DH angle
float enc_offset[N];
float jointDeg(int i) { return ax[i].enc_deg + enc_offset[i]; }

// ---------------------------------------------------------------- ODrive S1 (magnet spin motor)
void magnetSet(float rpm) {
  rpm = constrain(rpm, -MAGNET_MAX_RPM, MAGNET_MAX_RPM);
  magnet_rpm = rpm;
  Serial2.print("v 0 ");
  Serial2.print(rpm / 60.0f, 4);     // turns per second
  Serial2.print(" 0\n");
}

void magnetInit() {
  Serial2.begin(115200);
  delay(50);
  Serial2.print("w axis0.controller.config.control_mode 2\n");   // velocity control
  Serial2.print("w axis0.requested_state 8\n");                  // closed loop
  magnetSet(0);
}

// ---------------------------------------------------------------- motion (1 kHz)
void enableDrivers(bool on) {
  for (int i = 0; i < N; i++) digitalWriteFast(ax[i].en, on ? LOW : HIGH);   // EN active low
}

void stopAll() {
  for (int i = 0; i < N; i++) { ax[i].rate_sps = 0; ax[i].vel_dps = 0; ax[i].target_deg = stepsToDeg(i); }
  magnetSet(0);
}

void fault(uint32_t bits) {
  faults |= bits;
  state = FAULT;
  stopAll();
  enableDrivers(false);
}

void motionTick(float dt) {
  if (state != READY) return;
  for (int i = 0; i < N; i++) {
    Axis &a = ax[i];
    float pos = stepsToDeg(i);
    float err = a.target_deg - pos;
    // speed that can still stop in time (trapezoidal profile), capped at vmax
    float v_stop = sqrtf(2.0f * a.amax_dps2 * fabsf(err)) * (err >= 0 ? 1 : -1);
    float v_des = constrain(v_stop, -a.vmax_dps, a.vmax_dps);
    if (fabsf(err) < 0.002f) v_des = 0;
    float dv = constrain(v_des - a.vel_dps, -a.amax_dps2 * dt, a.amax_dps2 * dt);
    a.vel_dps += dv;
    a.rate_sps = a.vel_dps * a.steps_per_deg;
  }
}

void checkTick() {
  if (digitalReadFast(PIN_ESTOP_OK) == HIGH && state != FAULT) fault(1u << 9);
  if (state != READY) return;
  for (int i = 0; i < N; i++) {
    updateEncoder(i);
    if (fabsf(jointDeg(i) - stepsToDeg(i)) > STEP_LOSS_DEG) fault(1u << i);
  }
  if (millis() - last_cmd_ms > WATCHDOG_MS && magnet_rpm != 0) magnetSet(0);
}

// ---------------------------------------------------------------- homing: wrist first, then elbow, shoulder, base
bool homeAxis(int i) {
  Axis &a = ax[i];
  uint32_t t0 = millis();
  a.rate_sps = a.home_dir * HOME_SPEED_DPS * a.steps_per_deg;
  while (digitalReadFast(a.home) == HIGH) {             // flag interrupts the beam -> LOW
    if (digitalReadFast(PIN_ESTOP_OK) == HIGH) { a.rate_sps = 0; return false; }
    if (millis() - t0 > 60000) { a.rate_sps = 0; return false; }
    delay(1);
  }
  a.rate_sps = 0;
  delay(50);
  noInterrupts();
  a.pos_steps = (int32_t)lroundf(a.home_deg * a.steps_per_deg);
  interrupts();
  updateEncoder(i);
  enc_offset[i] = a.home_deg - a.enc_deg;
  a.target_deg = a.home_deg;
  a.vel_dps = 0;
  return true;
}

void homeAll() {
  state = HOMING;
  enableDrivers(true);
  const int order[N] = {4, 3, 2, 1, 0};
  for (int k = 0; k < N; k++) {
    if (!homeAxis(order[k])) { fault(1u << 8); return; }
  }
  // home pose of the CAD / software: [0, 90, 0, 0, 0]
  const float home_pose[N] = {0, 90, 0, 0, 0};
  state = READY;
  for (int i = 0; i < N; i++) ax[i].target_deg = home_pose[i];
}

// ---------------------------------------------------------------- host commands
String line;

void replyAngles() {
  Serial.print("A");
  for (int i = 0; i < N; i++) { Serial.print(' '); Serial.print(state == NOT_HOMED ? stepsToDeg(i) : jointDeg(i), 3); }
  Serial.println();
}

void handle(String s) {
  s.trim();
  if (!s.length()) return;
  char c = s.charAt(0);
  last_cmd_ms = millis();
  if (c == 'J') {
    if (state != READY) return;
    float v[N];
    int n = 0, start = 1;
    while (n < N && start < (int)s.length()) {
      while (start < (int)s.length() && s.charAt(start) == ' ') start++;
      int sp = s.indexOf(' ', start);
      if (sp < 0) sp = s.length();
      if (sp > start) v[n++] = s.substring(start, sp).toFloat();
      start = sp;
    }
    if (n != N) return;
    for (int i = 0; i < N; i++) {
      if (v[i] < ax[i].min_deg || v[i] > ax[i].max_deg) { faults |= (1u << 8); }
      ax[i].target_deg = constrain(v[i], ax[i].min_deg, ax[i].max_deg);
    }
  } else if (c == 'M') {
    if (state == READY) magnetSet(s.substring(1).toFloat());
  } else if (c == 'S') {
    stopAll();
  } else if (c == '?') {
    replyAngles();
  } else if (c == 'H') {
    if (digitalReadFast(PIN_ESTOP_OK) == LOW) homeAll();
  } else if (c == 'E') {
    Serial.print("E "); Serial.print((int)state); Serial.print(' '); Serial.print(faults, HEX);
    Serial.print(' '); Serial.println(digitalReadFast(PIN_ESTOP_OK) == LOW ? "OK" : "PRESSED");
  } else if (c == 'R') {
    if (digitalReadFast(PIN_ESTOP_OK) == LOW) { faults = 0; state = NOT_HOMED; }   // must home again
  }
}

void setup() {
  Serial.begin(115200);
  for (int i = 0; i < N; i++) {
    pinMode(ax[i].step, OUTPUT); pinMode(ax[i].dir, OUTPUT); pinMode(ax[i].en, OUTPUT);
    pinMode(ax[i].cs, OUTPUT); digitalWriteFast(ax[i].cs, HIGH);
    pinMode(ax[i].home, INPUT_PULLUP);
    phase[i] = 0;
  }
  pinMode(PIN_ESTOP_OK, INPUT_PULLUP);
  pinMode(PIN_STATUS_LED, OUTPUT);
  enableDrivers(false);
  SPI.begin();
  for (int i = 0; i < N; i++) { int16_t p = 0; amt22Read(ax[i].cs, p); ax[i].enc_last = p; ax[i].enc_turns = 0; }
  magnetInit();
  stepTimer.begin(stepISR, 1e6 / ISR_HZ);
}

uint32_t t_motion = 0, t_check = 0;

void loop() {
  while (Serial.available()) {
    char ch = Serial.read();
    if (ch == '\n') { handle(line); line = ""; }
    else if (line.length() < 120) line += ch;
  }
  uint32_t now = micros();
  if (now - t_motion >= 1000) { motionTick((now - t_motion) * 1e-6f); t_motion = now; }
  if (now - t_check >= 5000) { checkTick(); t_check = now; }
  digitalWriteFast(PIN_STATUS_LED, state == READY ? HIGH : ((millis() / 250) & 1));
}
