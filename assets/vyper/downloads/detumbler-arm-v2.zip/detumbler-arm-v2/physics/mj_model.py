"""Build a MuJoCo model of arm v2 + the gimballed target from the CAD mass model.

Bodies are world-aligned at the CAD home pose (so every body frame is the robot base frame translated to a
point on its joint axis). Masses, centers and inertia tensors come straight from the CAD solids; the actuators
are position servos limited to the catalog peak torque, with the motor rotor inertia reflected through the
101:1 gear. Collision shapes are the same capsules the robot software uses. Visual meshes are the CAD parts.

    python mj_model.py      -> out/mujoco/detumbler_v2.xml (+ meshes/)
"""
import json
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import design2 as D  # noqa: E402

OUT = HERE
ZA = D.Z3
# joint k: (name, axis (world, home), point on the axis [mm], body name)
LINK_DEF = [
    ("J1", (0, 0, 1), (0.0, 0.0, 0.0), "turret"),
    ("J2", (0, 1, 0), (0.0, 0.0, D.Z2), "upper"),
    ("J3", (0, 1, 0), (0.0, 0.0, ZA), "forearm"),
    ("J4", (1, 0, 0), (0.0, 0.0, ZA), "fork"),
    ("J5", (0, 1, 0), (D.X5, 0.0, ZA), "head"),
]
# reflected rotor inertia of the HJ2 motors at the output [kg m^2]: catalog 125 g cm^2 (70), 240 (80); others scaled
ARMATURE = {52: 4.0e-6, 70: 1.25e-5, 80: 2.4e-5, 90: 4.0e-5, 110: 9.0e-5}
# position-servo stiffness: harmonic drive torsional stiffness (the gear is the compliant element)
KP = {j: D.K_TORSION[int(D.HJ2[D.JOINT_ACTUATOR[j]]["od"])] for j in D.JOINT_ACTUATOR}


def aggregate(bodies, link):
    """Total mass, center [m] and inertia tensor about the center [kg m^2] of all parts on a link."""
    parts = [b for b in bodies if b["link"] == link]
    M = sum(b["m"] for b in parts)
    c = sum(np.asarray(b["com"], float) * b["m"] for b in parts) / M / 1e3
    J = np.zeros((3, 3))
    for b in parts:
        I = np.asarray(b.get("I", [0, 0, 0, 0, 0, 0]), float)
        Ib = np.array([[I[0], I[3], I[4]], [I[3], I[1], I[5]], [I[4], I[5], I[2]]])
        d = np.asarray(b["com"], float) / 1e3 - c
        J += Ib + b["m"] * (np.dot(d, d) * np.eye(3) - np.outer(d, d))
    return M, c, J


def inertial_xml(M, c_rel, J):
    w, V = np.linalg.eigh(J)
    w = np.maximum(w, 1e-9)
    if np.linalg.det(V) < 0:
        V[:, 0] *= -1
    # quaternion of V (rotation matrix -> wxyz)
    tr = np.trace(V)
    if tr > 0:
        s = np.sqrt(tr + 1) * 2
        q = [0.25 * s, (V[2, 1] - V[1, 2]) / s, (V[0, 2] - V[2, 0]) / s, (V[1, 0] - V[0, 1]) / s]
    else:
        i = int(np.argmax(np.diag(V)))
        j, k = (i + 1) % 3, (i + 2) % 3
        s = np.sqrt(1 + V[i, i] - V[j, j] - V[k, k]) * 2
        q = [0, 0, 0, 0]
        q[0] = (V[k, j] - V[j, k]) / s
        q[1 + i] = 0.25 * s
        q[1 + j] = (V[j, i] + V[i, j]) / s
        q[1 + k] = (V[k, i] + V[i, k]) / s
    return (f'<inertial pos="{c_rel[0]:.6f} {c_rel[1]:.6f} {c_rel[2]:.6f}" quat="{q[0]:.6f} {q[1]:.6f} {q[2]:.6f} {q[3]:.6f}" '
            f'mass="{M:.5f}" diaginertia="{w[0]:.4e} {w[1]:.4e} {w[2]:.4e}"/>')


def capsule_xml(p1, p2, r, origin, name, cls):
    a = (np.asarray(p1, float) - origin) / 1e3
    b = (np.asarray(p2, float) - origin) / 1e3
    return f'<geom name="{name}" class="{cls}" type="capsule" fromto="{a[0]:.4f} {a[1]:.4f} {a[2]:.4f} {b[0]:.4f} {b[1]:.4f} {b[2]:.4f}" size="{r / 1e3:.4f}"/>'


def export_meshes(comps, origins):
    """One coarse STL per component, with vertices expressed in the component's body frame."""
    import cadquery as cq
    os.makedirs(f"{OUT}/meshes", exist_ok=True)
    from interference import is_fastener
    for cname, parts in comps.items():
        shapes = [s for n, s, _c, _m in parts if not is_fastener(n) and s.Volume() > 300]
        comp = cq.Compound.makeCompound(shapes).translate(cq.Vector(*(-np.asarray(origins[cname], float))))
        cq.exporters.export(cq.Workplane(obj=comp), f"{OUT}/meshes/{cname}.stl", tolerance=0.4, angularTolerance=0.4)


def build(with_meshes=True):
    import gen_configs2 as G
    bodies = json.load(open(os.path.join(HERE, "..", "cad", "mass_model.json")))
    tc = np.asarray(D.TARGET_CENTER, float)
    origins = {"ARM_BASE": np.zeros(3), "ARM_L1_TURRET": np.array(LINK_DEF[0][2]), "ARM_L2_UPPER": np.array(LINK_DEF[1][2]),
               "ARM_L3_FOREARM": np.array(LINK_DEF[2][2]), "ARM_L4_FORK": np.array(LINK_DEF[3][2]), "ARM_L5_HEAD": np.array(LINK_DEF[4][2]),
               "ARM_L6_ROTOR": np.array(D.MAGNET_CENTER), "TARGET_STAND": tc, "TARGET_YOKE": tc, "TARGET_RING": tc, "TARGET_BOX": tc}
    if with_meshes:
        import cad2_rig
        comps = cad2_rig.components(with_scene=False)
        export_meshes(comps, origins)
    mesh_assets = "".join(f'<mesh name="{c}" file="meshes/{c}.stl" scale="0.001 0.001 0.001"/>' for c in origins) if with_meshes else ""

    def vis(cname):
        return f'<geom class="visual" type="mesh" mesh="{cname}"/>' if with_meshes else ""

    L = ['<mujoco model="detumbler_arm_v2">', '<compiler angle="radian" autolimits="true"/>',
         '<option timestep="0.001" gravity="0 0 -9.81" integrator="implicitfast"/>',
         '<default>', '  <default class="visual"><geom contype="0" conaffinity="0" group="1" density="0" rgba="0.75 0.76 0.78 1"/></default>',
         '  <default class="col"><geom contype="1" conaffinity="1" group="3" rgba="0.2 0.6 0.9 0.3"/></default>',
         '  <default class="nocol"><geom contype="0" conaffinity="0" group="3" rgba="0.9 0.5 0.2 0.3"/></default>',
         '  <joint damping="0.5"/>', '</default>',
         f'<asset>{mesh_assets}<texture name="grid" type="2d" builtin="checker" rgb1=".15 .17 .2" rgb2=".2 .22 .26" width="512" height="512"/>'
         '<material name="grid" texture="grid" texrepeat="8 8"/></asset>', '<worldbody>',
         f'<light pos="0 -2 3" dir="0 0.5 -1" diffuse="0.8 0.8 0.8"/>',
         f'<geom name="floor" type="plane" size="3 3 0.1" pos="0 0 {(-D.BASE_PLATE["t"] - D.PEDESTAL["h"]) / 1e3:.3f}" material="grid" contype="0" conaffinity="0"/>']
    # base (static): visual only
    L.append(f'<body name="ARM_BASE" pos="0 0 0">{vis("ARM_BASE")}</body>')
    # arm chain
    cnames = ["ARM_L1_TURRET", "ARM_L2_UPPER", "ARM_L3_FOREARM", "ARM_L4_FORK", "ARM_L5_HEAD"]
    prev = np.zeros(3)
    depth = 0
    for k, (jname, axis, point, _bn) in enumerate(LINK_DEF, start=1):
        cname = cnames[k - 1]
        p = np.asarray(point, float)
        rel = (p - prev) / 1e3
        a = D.HJ2[D.JOINT_ACTUATOR[jname]]
        lim = D.JOINT_LIMITS[jname]
        M, c, J = aggregate(bodies, k)
        L.append(f'<body name="{cname}" pos="{rel[0]:.4f} {rel[1]:.4f} {rel[2]:.4f}">')
        L.append(f'  <joint name="{jname}" type="hinge" axis="{axis[0]} {axis[1]} {axis[2]}" range="{np.radians(lim[0]):.4f} {np.radians(lim[1]):.4f}" '
                 f'armature="{ARMATURE[int(a["od"])] * D.RATIO ** 2:.4f}" damping="{2.0 if k <= 3 else 0.8}" frictionloss="{0.6 if k <= 3 else 0.2}"/>')
        L.append("  " + inertial_xml(M, c - p / 1e3, J))
        L.append("  " + vis(cname))
        for li, name, p1, p2, r in G.CAPSULES:
            if li == k:
                L.append("  " + capsule_xml(p1, p2, r, p, f"cap_{k}_{name.replace(' ', '_').replace('+', '').replace('-', 'm')}", "col"))
        prev = p
        depth += 1
    # rotor on the head
    M, c, J = aggregate(bodies, 6)
    pm = np.asarray(D.MAGNET_CENTER, float)
    rel = (pm - prev) / 1e3
    L.append(f'<body name="ARM_L6_ROTOR" pos="{rel[0]:.4f} {rel[1]:.4f} {rel[2]:.4f}">')
    L.append(f'  <joint name="spindle" type="hinge" axis="1 0 0" damping="2e-5" frictionloss="1e-3"/>')
    L.append("  " + inertial_xml(M, c - pm / 1e3, J))
    L.append("  " + vis("ARM_L6_ROTOR"))
    L.append(f'  <site name="magnet" pos="0 0 0" size="0.004"/>')
    L.append("</body>")
    L += ["</body>"] * depth
    # target stand (static) + gimbal chain: yaw (yoke) -> pitch (ring) -> roll (hull)
    L.append(f'<body name="TARGET_STAND" pos="{tc[0] / 1e3:.4f} {tc[1] / 1e3:.4f} {tc[2] / 1e3:.4f}">{vis("TARGET_STAND")}')
    for code, cname, jname, axis in ((10, "TARGET_YOKE", "gimbal_yaw", (0, 0, 1)), (11, "TARGET_RING", "gimbal_pitch", (0, 1, 0)), (12, "TARGET_BOX", "gimbal_roll", (1, 0, 0))):
        M, c, J = aggregate(bodies, code)
        if code in (11, 12):
            # ring and hull are balanced onto the gimbal center with trim masses (the CAD offsets of 0.2 mm would
            # already give gravity torques larger than the eddy torque; the build plan calls for < 0.02 mm)
            c = tc / 1e3
        L.append(f'<body name="{cname}" pos="0 0 0">')
        fl = {"gimbal_yaw": 2e-4, "gimbal_pitch": 1e-4, "gimbal_roll": 1e-4}[jname]      # ceramic bearing friction [N m]
        L.append(f'  <joint name="{jname}" type="hinge" axis="{axis[0]} {axis[1]} {axis[2]}" damping="1e-5" frictionloss="{fl}"/>')
        L.append("  " + inertial_xml(M, c - tc / 1e3, J))
        L.append("  " + vis(cname))
    hx, hy, hz = D.TARGET["x"] / 2e3, D.TARGET["y"] / 2e3, D.TARGET["z"] / 2e3
    L.append(f'  <geom name="hull_box" class="nocol" type="box" size="{hx} {hy} {hz}"/>')
    L.append('  <site name="hull" pos="0 0 0" size="0.004"/>')
    L += ["</body>"] * 4
    L.append("</worldbody>")
    # actuators: plain torque motors, torque-limited to the catalog peak; the servo loop (1 kHz cyclic position
    # mode with interpolated references, as an EtherCAT drive does it) runs in mj_world.py
    L.append("<actuator>")
    for jname, *_ in LINK_DEF:
        a = D.HJ2[D.JOINT_ACTUATOR[jname]]
        L.append(f'<motor name="{jname}_servo" joint="{jname}" ctrlrange="-{a["peak"]} {a["peak"]}" forcerange="-{a["peak"]} {a["peak"]}"/>')
    L.append('<velocity name="spindle_drive" joint="spindle" kv="0.02" forcerange="-0.08 0.08"/>')
    L.append("</actuator>")
    L.append("<sensor>")
    for jname, *_ in LINK_DEF:
        L.append(f'<actuatorfrc name="{jname}_torque" actuator="{jname}_servo"/>')
    L.append('<frameangvel name="hull_angvel" objtype="site" objname="hull"/>')
    L.append('<framequat name="hull_quat" objtype="site" objname="hull"/>')
    L.append("</sensor>")
    L.append("</mujoco>")
    os.makedirs(OUT, exist_ok=True)
    path = f"{OUT}/detumbler_v2.xml"
    open(path, "w").write("\n".join(L))
    return path


if __name__ == "__main__":
    import mujoco
    path = build(with_meshes="--no-meshes" not in sys.argv)
    m = mujoco.MjModel.from_xml_path(path)
    d = mujoco.MjData(m)
    mujoco.mj_forward(m, d)
    print("model ok:", m.nbody, "bodies", m.njnt, "joints", m.nu, "actuators", "total mass", round(sum(m.body_mass), 3))
    for i in range(m.nbody):
        print(f"  {mujoco.mj_id2name(m, mujoco.mjtObj.mjOBJ_BODY, i):16s} mass {m.body_mass[i]:7.3f}  inertia {np.round(m.body_inertia[i], 5)}")
    # gravity torques at home: compare with sizing
    mujoco.mj_inverse(m, d)
    print("gravity torques at home [N m]:", np.round(d.qfrc_inverse[:5], 2))
