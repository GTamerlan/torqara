import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Run a detumble mission with the real mission software driving the MuJoCo physics model of arm v2.

    python mj_run.py --seconds 120 --spin 40 4 2 --seed 11 --out out/physics/run_a.json
"""
import argparse
import json
import os
import sys
import time
import numpy as np
import tomllib

HERE = os.path.dirname(os.path.abspath(__file__))
SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "cad", "source"))
sys.path.insert(0, SW)
import detumbler.simrun as simrun  # noqa: E402
from mj_world import MjWorld  # noqa: E402

simrun.SimWorld = MjWorld            # the mission code and its loop are untouched; only the world is physical


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default=f"{SW}/config/arm_v2_5dof.toml")
    ap.add_argument("--rig", default=f"{SW}/config/rig_v2.toml")
    ap.add_argument("--seconds", type=float, default=120)
    ap.add_argument("--spin", type=float, nargs=3, default=[40, 4, 2])
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--mode", default="spin")
    ap.add_argument("--record-every", type=int, default=2)
    ap.add_argument("--out", default=f"{HERE}/results/run.json")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    rig = tomllib.load(open(a.rig, "rb"))
    holder = {}
    orig = MjWorld.__init__

    def init(self, *args, **kw):
        orig(self, *args, **kw)
        holder["world"] = self
    MjWorld.__init__ = init
    t0 = time.time()
    res = simrun.run_sim(a.arm, rig, seconds=a.seconds, seed=a.seed, mode=a.mode, spin_dps=tuple(a.spin), verbose=not a.quiet,
                         record_every=a.record_every)
    world = holder["world"]
    res["physics"] = world.physics_summary()
    res["torque_log"] = world.torque_log[:: 3]
    res["spin_dps"] = a.spin
    res["seed"] = a.seed
    res["wall_time_s"] = round(time.time() - t0, 1)
    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    json.dump(res, open(a.out, "w"))
    keys = ["time_to_detumble_phase_s", "time_to_stable_s", "final_true_spin_dps", "min_true_gap_mm", "collisions", "link_contacts",
            "static_contacts", "gimbal_contacts", "min_gimbal_gap_mm", "magnet_position_error_mm_mean", "wall_time_s"]
    print("\nResult (physics)")
    for k in keys:
        print(f"  {k:32s} {res.get(k)}")
    for j, r in res["physics"]["joints"].items():
        print(f"  {j}: peak {r['peak_torque_Nm']} N m ({r['peak_over_rated']}x rated), rms {r['rms_torque_Nm']} N m, "
              f"tracking err max {r['max_tracking_error_deg']} deg mean {r['mean_tracking_error_deg']} deg")
    print("  realtime factor", res["physics"]["realtime_factor"], "rotor rpm", res["physics"]["rotor_rpm_final"])


if __name__ == "__main__":
    main()
