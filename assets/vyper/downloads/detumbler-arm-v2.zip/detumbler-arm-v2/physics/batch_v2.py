import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Batch of simulated missions on the v2 rig: kinematic simulator (python batch_v2.py) or MuJoCo physics
(python batch_v2.py --physics). Results go to out/results/<name>.json; a summary to out/results/summary_*.json."""
import json
import os
import sys
import time
import tomllib
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "cad", "source"))
sys.path.insert(0, SW)
import detumbler.simrun as simrun  # noqa: E402

PHYS = "--physics" in sys.argv
if PHYS:
    from mj_world import MjWorld
    simrun.SimWorld = MjWorld

CASES = [  # name, body rates deg/s (roll about the pins, pitch, yaw at t=0), seed, mode, seconds
    ("A_roll40_s11", (40, 4, 2), 11, "spin", 180),
    ("A_roll40_s12", (40, 4, 2), 12, "spin", 180),
    ("A_roll40_still_s11", (40, 4, 2), 11, "still", 180),
    ("B_roll25_s11", (25, 6, 3), 11, "spin", 180),
    ("C_roll60_s11", (60, 3, 2), 11, "spin", 180),
    ("D_mixed15_s11", (15, 10, 5), 11, "spin", 180),
    ("A_roll40_s13", (40, 4, 2), 13, "spin", 180),
    ("E_endover_s11", (5, 40, 8), 11, "spin", 120),
]
if "--quick" in sys.argv:
    CASES = [c for c in CASES if c[0] in ("A_roll40_s11", "E_endover_s11")]
if "--only" in sys.argv:
    CASES = [c for c in CASES if c[0] == sys.argv[sys.argv.index("--only") + 1]]
if "--seconds" in sys.argv:
    _s = float(sys.argv[sys.argv.index("--seconds") + 1])
    CASES = [(n, sp, sd, m, min(sec, _s)) for n, sp, sd, m, sec in CASES]

OUT = os.path.join(HERE, "results", "physics" if PHYS else "kinematic")
os.makedirs(OUT, exist_ok=True)
rig = tomllib.load(open(f"{SW}/config/rig_v2.toml", "rb"))
summary = []
for name, spin, seed, mode, seconds in CASES:
    f = f"{OUT}/{name}.json"
    if os.path.exists(f) and "--force" not in sys.argv:
        r = json.load(open(f))
        summary.append(r["summary"])
        print("have", name)
        continue
    t0 = time.time()
    holder = {}
    if PHYS:
        orig = MjWorld.__init__

        def init(self, *a, **k):
            orig(self, *a, **k)
            holder["w"] = self
        MjWorld.__init__ = init
    res = simrun.run_sim(f"{SW}/config/arm_v2_5dof.toml", rig, seconds=seconds, seed=seed, mode=mode, spin_dps=spin, record_every=2)
    if PHYS:
        MjWorld.__init__ = orig
        res["physics"] = holder["w"].physics_summary()
        res["torque_log"] = holder["w"].torque_log[::3]
    rows = res.pop("log_rows")
    notes = {}
    for r in rows:
        notes[r["note"] or "braking / tracking"] = notes.get(r["note"] or "braking / tracking", 0) + 1
    spin_hist = [(r["t"], r["spin_est_dps"]) for r in rows[::15]]
    rpm_max = max(abs(r["rpm"]) for r in rows)
    s = {"name": name, "spin0_dps": list(spin), "seed": seed, "mode": mode, "seconds": seconds,
         "time_to_stable_s": res["time_to_stable_s"], "final_true_spin_dps": res["final_true_spin_dps"],
         "min_true_gap_mm": res["min_true_gap_mm"], "collisions": res["collisions"], "link_contacts": res["link_contacts"],
         "static_contacts": res["static_contacts"], "gimbal_contacts": res["gimbal_contacts"], "min_gimbal_gap_mm": res["min_gimbal_gap_mm"],
         "magnet_position_error_mm_mean": res["magnet_position_error_mm_mean"], "tool_marker_seen_frac": res["tool_marker_seen_frac"],
         "ticks_by_note": notes, "rpm_max": rpm_max, "wall_s": round(time.time() - t0)}
    if PHYS:
        s["physics"] = res["physics"]
    res["summary"] = s
    res["spin_hist"] = spin_hist
    json.dump(res, open(f, "w"))
    summary.append(s)
    print(name, "stable at", s["time_to_stable_s"], "final", round(s["final_true_spin_dps"], 2), "gap", round(s["min_true_gap_mm"], 1),
          "contacts", s["collisions"], s["link_contacts"], s["static_contacts"], s["gimbal_contacts"], f"({s['wall_s']} s)", flush=True)
json.dump(summary, open(f"{OUT}/summary.json", "w"), indent=1)
print("done")
