import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Physics stand-in for the world: the same mission software drives a MuJoCo model of arm v2 (real masses, joint
servos with torque limits and gear compliance, spinning rotor) and the gimballed hull (ring and yoke inertia,
free gimbal joints). The eddy-current torque from the paper's model is applied to the hull body each step.

Drop-in replacement for detumbler.sim.SimWorld (same constructor, same bookkeeping), so simrun.run_sim works
unchanged: `mj_run.py` patches it in.
"""
import os
import sys
import numpy as np
import mujoco

HERE = os.path.dirname(os.path.abspath(__file__))
SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "..", "cad", "source"))
sys.path.insert(0, SW)
from detumbler.sim import SimWorld  # noqa: E402
from detumbler.hardware import ArmIO, RefShaper  # noqa: E402
from detumbler.frames import R_from_quat, qrot_inv, unit  # noqa: E402
from detumbler.brain import eddy_patch  # noqa: E402

MODEL_XML = os.path.join(HERE, "detumbler_v2.xml")


class MjArm(ArmIO):
    """The arm's joints live in MuJoCo. Encoder angles = true angles - zero offsets (the controller never knows
    the offsets; the camera correction has to find them, as on the real arm)."""

    # DH joint angle (software) <-> MuJoCo hinge angle (zero at the CAD home, right-handed about the CAD axes)
    S = np.array([1.0, -1.0, -1.0, 1.0, -1.0])
    HOME = np.radians([0.0, 90.0, 0.0, 0.0, 0.0])

    def __init__(self, model, data, offsets, max_speed, encoder_noise_deg=0.002, rng=None):
        self.m, self.d = model, data
        self.off = np.asarray(offsets, float)
        self.max_speed = np.asarray(max_speed, float)
        self.noise = np.radians(encoder_noise_deg)
        self.rng = np.random.default_rng(1) if rng is None else rng
        self.cmd = self.q.copy()

    def to_mj(self, q_true_dh):
        return self.S * (np.asarray(q_true_dh, float) - self.HOME)

    def from_mj(self, qpos):
        return self.HOME + self.S * np.asarray(qpos, float)

    @property
    def q(self):
        """Encoder angles (DH convention): true angles minus the unknown zero offsets."""
        return self.from_mj(self.d.qpos[:5]) - self.off

    def read_joints(self):
        return self.q + self.rng.normal(0, self.noise, 5)

    def send_joints(self, q):
        self.cmd = np.asarray(q, float).copy()
        self.ref_next = self.to_mj(self.cmd + self.off)       # the servo loop ramps to this over the next tick

    def stop(self):
        self.cmd = self.q.copy()
        self.ref_next = self.d.qpos[:5].copy()

    def update(self, dt):
        pass                                     # MuJoCo steps the joints


class MjWorld(SimWorld):
    def __init__(self, rig, arm_model, brain_cfg, seed=0, spin_dps=(40.0, 4.0, 2.0), **kw):
        super().__init__(rig, arm_model, brain_cfg, seed=seed, spin_dps=spin_dps, **kw)
        self.m = mujoco.MjModel.from_xml_path(MODEL_XML)
        self.d = mujoco.MjData(self.m)
        offsets = self.arm_true.dh[:, 3] - arm_model.dh[:, 3]          # the true arm's zero errors
        q0 = self.arm_io.q.copy()                                        # SimArm's start pose (encoder angles)
        self.arm_io = MjArm(self.m, self.d, offsets, arm_model.max_speed, rng=self.rng)
        self.d.qpos[:5] = self.arm_io.to_mj(q0 + offsets)
        self.arm_io.ref_next = self.d.qpos[:5].copy()
        self.ref = self.d.qpos[:5].copy()
        # the drive's interpolator: reference follows the 30 Hz command with the design's velocity and
        # acceleration limits, evaluated at the 1 kHz servo rate (in MuJoCo joint coordinates)
        self.shaper = RefShaper(self.d.qpos[:5].copy(), arm_model.max_speed, arm_model.max_accel)
        # servo gains: 0.2 deg of error at rated torque; damping for the reflected rotor + link inertia
        import design2 as D
        import json as _json
        loads = _json.load(open(os.path.join(HERE, "..", "docs", "loads.json")))
        self.kp = np.zeros(5)
        self.kd = np.zeros(5)
        for i, j in enumerate(("J1", "J2", "J3", "J4", "J5")):
            a = D.HJ2[D.JOINT_ACTUATOR[j]]
            self.kp[i] = a["rated"] / np.radians(0.2)
            J_eff = self.m.dof_armature[i] + loads["joints"][j]["inertia_stretched_kgm2"]
            self.kd[i] = 2 * 0.9 * np.sqrt(self.kp[i] * J_eff)
        self.peak = np.array([D.HJ2[D.JOINT_ACTUATOR[j]]["peak"] for j in ("J1", "J2", "J3", "J4", "J5")])
        self.rated = np.array([D.HJ2[D.JOINT_ACTUATOR[j]]["rated"] for j in ("J1", "J2", "J3", "J4", "J5")])
        self.ki = self.kp * 4.0                 # integral action (0.25 s), so gravity leaves no steady-state error
        self.i_term = np.zeros(5)
        # gimbal: at zero angles the hull axes coincide with the world axes; body rates map to (yaw, pitch, roll)
        self.j_gimbal = [mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_JOINT, n) for n in ("gimbal_yaw", "gimbal_pitch", "gimbal_roll")]
        w0 = np.radians(np.asarray(spin_dps, float))
        for jid, wv in zip(self.j_gimbal, (w0[2], w0[1], w0[0])):
            self.d.qvel[self.m.jnt_dofadr[jid]] = wv
        self.hull_id = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, "TARGET_BOX")
        self.rotor_id = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_BODY, "ARM_L6_ROTOR")
        self.s_quat = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SENSOR, "hull_quat")
        self.s_angvel = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_SENSOR, "hull_angvel")
        self.a_spindle = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_ACTUATOR, "spindle_drive")
        self.j_spindle = mujoco.mj_name2id(self.m, mujoco.mjtObj.mjOBJ_JOINT, "spindle")
        mujoco.mj_forward(self.m, self.d)
        self._sync_target()
        self.torque_log = []            # (t, 5 joint torques, 5 tracking errors [rad], rotor rpm, gimbal angles)
        self.peak_torque = np.zeros(5)
        self.max_track_err = np.zeros(5)
        self.sum_track_err = np.zeros(5)
        self.n_track = 0
        self.eddy_torque_log = []
        self.sim_time_ratio = []

    def _sync_target(self):
        q = self.d.sensordata[self.m.sensor_adr[self.s_quat]: self.m.sensor_adr[self.s_quat] + 4].copy()
        w_world = self.d.sensordata[self.m.sensor_adr[self.s_angvel]: self.m.sensor_adr[self.s_angvel] + 3].copy()
        self.q = q / np.linalg.norm(q)
        self.w = R_from_quat(self.q).T @ w_world

    def step(self, dt, substeps=None):
        import time as _time
        t0 = _time.perf_counter()
        n = int(round(dt / self.m.opt.timestep))
        omega_m = self.motor.rpm * 2 * np.pi / 60.0
        self.d.ctrl[self.a_spindle] = omega_m
        target = self.arm_io.ref_next.copy()
        h = self.m.opt.timestep
        for k in range(n):
            # servo loop at 1 kHz: shaped reference (velocity + acceleration limited), PD with velocity feedforward
            ref, vref = self.shaper.update(target, h)
            e = ref - self.d.qpos[:5]
            self.i_term = np.clip(self.i_term + self.ki * e * h, -self.rated, self.rated)     # anti-windup at rated torque
            tau = self.kp * e + self.i_term + self.kd * (vref - self.d.qvel[:5])
            self.d.ctrl[:5] = np.clip(tau, -self.peak, self.peak)
            self.ref = ref
            p, axis = self.true_magnet()
            p_rel = p - self.center
            toward = -unit(p_rel)
            v_field = omega_m * self.cfg_true.mag_radius * np.cross(axis, toward)
            pb = qrot_inv(self.q, p_rel)
            true_gap = np.linalg.norm(pb - np.clip(pb, -self.cfg_true.half_extents, self.cfg_true.half_extents)) - self.cfg_true.r_head
            self.min_gap = min(self.min_gap, true_gap)
            self.gap_now = true_gap
            if true_gap < 0:
                self.collisions += 1
            r = eddy_patch(self.cfg_true, self.q, self.w, p_rel, vf_body=qrot_inv(self.q, v_field))
            tb = np.zeros(3) if r is None else r["tb"]
            self.last_heat = 0.0 if r is None else r["P"]
            self.last_gap = None if r is None else r["g"]
            R = R_from_quat(self.q)
            tw = R @ tb
            self.d.xfrc_applied[self.hull_id, 3:6] = tw
            self.d.xfrc_applied[self.rotor_id, 3:6] = -tw * 0.0          # reaction on the rotor is tiny; kept explicit
            mujoco.mj_step(self.m, self.d)
            self._sync_target()
        self.check_links()
        tq = self.d.actuator_force[:5].copy()
        err = self.ref - self.d.qpos[:5]
        self.err_now = err
        self.peak_torque = np.maximum(self.peak_torque, np.abs(tq))
        self.max_track_err = np.maximum(self.max_track_err, np.abs(err))
        self.sum_track_err += np.abs(err)
        self.n_track += 1
        gim = [float(self.d.qpos[self.m.jnt_qposadr[j]]) for j in self.j_gimbal]
        rpm = float(self.d.qvel[self.m.jnt_dofadr[self.j_spindle]]) * 60 / (2 * np.pi)
        self.torque_log.append((round(self.t, 4), tq.tolist(), err.tolist(), rpm, gim, float(np.linalg.norm(tw))))
        self.t += dt
        self.sim_time_ratio.append((_time.perf_counter() - t0) / dt)

    def physics_summary(self):
        import design2 as D
        joints = ["J1", "J2", "J3", "J4", "J5"]
        out = {}
        for i, j in enumerate(joints):
            a = D.HJ2[D.JOINT_ACTUATOR[j]]
            out[j] = dict(actuator=D.JOINT_ACTUATOR[j], peak_torque_Nm=round(float(self.peak_torque[i]), 2),
                          rated_Nm=a["rated"], peak_Nm=a["peak"], peak_over_rated=round(float(self.peak_torque[i]) / a["rated"], 2),
                          max_tracking_error_deg=round(float(np.degrees(self.max_track_err[i])), 3),
                          mean_tracking_error_deg=round(float(np.degrees(self.sum_track_err[i] / max(1, self.n_track))), 4))
        tl = np.array([row[1] for row in self.torque_log])
        rms = np.sqrt(np.mean(tl ** 2, axis=0)) if len(tl) else np.zeros(5)
        for i, j in enumerate(joints):
            out[j]["rms_torque_Nm"] = round(float(rms[i]), 2)
        return dict(joints=out, realtime_factor=round(float(np.mean(self.sim_time_ratio)), 2) if self.sim_time_ratio else None,
                    rotor_rpm_final=round(self.torque_log[-1][3], 1) if self.torque_log else None)
