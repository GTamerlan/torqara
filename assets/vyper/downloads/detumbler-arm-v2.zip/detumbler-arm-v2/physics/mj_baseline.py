import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Free decay of the hull on the gimbal with the arm parked (no magnet): the stand's own friction, for reference."""
import sys, os, json, tomllib, numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, HERE); sys.path.insert(0, os.path.join(HERE, "..", "cad", "source")); sys.path.insert(0, SW)
from detumbler.kinematics import Arm
from detumbler.brain import BrainConfig
from mj_world import MjWorld
rig = tomllib.load(open(f"{SW}/config/rig_v2.toml", "rb"))
arm = Arm.from_toml(f"{SW}/config/arm_v2_5dof.toml")
cfg = BrainConfig.from_rig(rig)
out = {}
for spin in ((40, 4, 2), (10, 1, 0.5)):
    w = MjWorld(rig, arm, cfg, seed=1, spin_dps=spin)
    w.motor.set_rpm(0.0)
    rows = []
    for i in range(int(300 / (1 / 30))):
        w.arm_io.send_joints(w.arm_io.read_joints()); w.step(1 / 30)
        if i % 150 == 0:
            rows.append((round(w.t, 1), round(float(np.degrees(np.linalg.norm(w.w))), 3)))
    out[str(spin)] = rows
    print(spin, rows[::6])
os.makedirs(f"{HERE}/results", exist_ok=True)
json.dump(out, open(f"{HERE}/results/free_decay.json", "w"), indent=1)
