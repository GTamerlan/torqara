# Detumbler arm v2: design, loads and simulation report

**Status: designed, checked and simulated. Nothing has been built.** Every number below comes from the CAD model (`cad/source/design2.py`), the loads script, the parts list, or simulation of the robot software.

## 1. What was built in CAD

- A five-axis arm, 1127 mm reach fully stretched, 13.9 kg moving mass, on a floor pedestal.
- Every joint is a Leadshine HJ2 harmonic integrated actuator: brushless motor, 101:1 harmonic gear (zero backlash), 24-bit encoder and EtherCAT drive in one sealed unit, holding brake on the gravity joints. This is how industrial cobot joints are built, and it is the main reason the arm is smooth: no belts, no steppers, no backlash, 1 kHz closed loop.
  - J1: HJ2-90-NK (50.0/102.0 N m, 1.229 kg); J2: HJ2-110-BK (84.0/194.0 N m, 2.6 kg); J3: HJ2-90-BK (50.0/102.0 N m, 1.6 kg); J4: HJ2-70-NK (9.6/34.0 N m, 0.598 kg); J5: HJ2-70-BK (9.6/34.0 N m, 0.8 kg)
- Links: roll-wrapped carbon tubes (60 mm upper arm, 50 mm forearm) bonded into machined 6061 hubs with cross pins. Hubs bolt to the actuator flanges with counterbored screws on the actuators' bolt patterns.
- Magnet head: a K&J BY0Y0X0-N52 block 2 x 2 x 1 in (0.574 kg) potted in a carbon tube, spun about one of its 2 in edges by a maxon EC-i 40 through a bellows coupling, on full-ceramic bearings, inside a polycarbonate guard. 3000 rpm capable; the braking law uses up to 4 m/s of field sweep (about 1504 rpm). Everything around the rotor is non-conductive (printed PA12-CF, polycarbonate, titanium shaft, ceramic bearings) so the field only brakes the hull.
- Target: a 200 x 160 x 140 mm box of 1.5 mm 1100 aluminum with ArUco markers on all six faces, hanging in a free three-axis gimbal: roll pins in the hull, a horizontal G10 ring on pitch pins, a printed yoke on a vertical yaw shaft. No limits on any axis. G10, printed polymer and ceramic bearings throughout, so the gimbal itself is not braked by the magnet.
- Two global-shutter cameras and two LED panels on a mast; an EtherCAT controller cabinet (fanless PC, 48 V 1.5 kW supply, safety relay and contactor, ODrive for the spindle).

## 2. Is it buildable

- Interference check over all 32 fastener engagements and every other part pair: **0 interferences**. Screws overlap only the tapped holes they engage (reported separately).
- 17 machined aluminum parts, 12 printed parts, 166 fasteners, all with real holes, counterbores, clearance fits (bearings +0.05 mm, tubes +0.3 mm, actuator bodies +0.3 mm) and press fits (pins) in the model.
- Everything after J5 that is not aluminum is either non-conductive or rotates with the magnet (no eddy currents in the head itself).
- Before machining:
  - HJ2 bolt patterns (count, thread, PCD) on the output flange and body: taken from the usual layout, not from the vendor drawing. Download the 2D drawing / STEP for each size from store.leadshine.com and update HJ2[...] before cutting the hubs.
  - HJ2 connector position and cable exit (the hubs leave a 30 mm cable window; move it if the connector is elsewhere).
  - Magnet block: confirm 50.8 x 50.8 x 25.4 mm nominal, measure the actual block and pot it with 0.3 mm epoxy clearance.
  - Carbon tube actual OD/ID: roll-wrapped tubes are +-0.2 mm; ream the hub bores to the delivered tube.
  - Rotor balance: balance the finished rotor to ISO 1940 G2.5 at 3000 rpm before fitting the guard.

## 3. Loads and margins

Mass model: CAD mass properties (out/mass_model.json). Head (everything after J5, rotor included): 2.456 kg.

| Joint | Actuator | Worst gravity torque | Peak demand (gravity + max accel) | Rated / peak | Margin on rated | Margin on peak |
|---|---|---|---|---|---|---|
| J1 | HJ2-90-NK | 0.0 N m | 3.51 N m | 50.0 / 102.0 N m | 14.23x | 29.03x |
| J2 | HJ2-110-BK | 65.86 N m | 69.27 N m | 84.0 / 194.0 N m | 1.21x | 2.8x |
| J3 | HJ2-90-BK | 22.95 N m | 24.6 N m | 50.0 / 102.0 N m | 2.03x | 4.15x |
| J4 | HJ2-70-NK | 2.82 N m | 2.84 N m | 9.6 / 34.0 N m | 3.38x | 11.98x |
| J5 | HJ2-70-BK | 2.85 N m | 3.03 N m | 9.6 / 34.0 N m | 3.17x | 11.22x |

Everyday poses: home J2 22.9 N m; reaching forward with the forearm horizontal J2 60.7 N m (72% of continuous rating). The worst case (1.21x on the continuous rating) is the arm fully horizontal; if the arm will spend long periods there, a gas-spring counterbalance on J2 is the cheap upgrade.

Spindle: rotor 0.734 kg, 9.6 m/s rim speed at 3000 rpm, angular momentum 0.0732 N m s. Gyroscopic torque on the wrist at the arm's fastest slew: 0.115 N m (4% of the wrist's gravity load): the spinning magnet is not a problem for the arm. Field at the spindle motor 8.94 mT, at the J5 actuator 1.32 mT.

Stiffness: at full stretch the head weight sags the tip 2.11 mm (mostly harmonic-gear wind-up, 0.43 mm from the tubes); first bending mode about 8.73 Hz. The camera measures and removes the static sag; the drive's velocity and acceleration limits keep commanded motion far below that mode.

## 4. Physics simulation

A MuJoCo model built from the CAD (masses, centers and inertia tensors of every part; actuator rotor inertia reflected through the 101:1 gear; 1 kHz servo loops with the design's velocity and acceleration limits, integral action and the catalog peak torque as the hard limit; the rotor as a spinning body; the hull, ring and yoke as free gimbal bodies with ceramic-bearing friction) is driven by the unchanged mission software: camera model, calibration, estimator, planner, safety envelopes, joint-space planner. The eddy-current torque from the paper's model is applied to the hull.

| Case | Body rates at t=0 (roll about the pins, pitch, yaw) deg/s | Magnet | Stopped at | Final spin deg/s | Min head-hull gap mm | Min gimbal gap mm | Contacts | Peak joint torque / rated | Max tracking error deg |
|---|---|---|---|---|---|---|---|---|---|
| A_roll40_s11 | 40, 4, 2 | spun | 20 s | 0.0 | 6.1 | -5.1 | 18 | 0.79x (J2) | 0.33 |
| A_roll40_s12 | 40, 4, 2 | spun | 23 s | 0.0 | 19.5 | -26.4 | 1332 | 0.77x (J5) | 0.33 |
| A_roll40_still_s11 | 40, 4, 2 | static | 24 s | 0.0 | 7.2 | 5.8 | 0 | 0.74x (J5) | 0.30 |
| B_roll25_s11 | 25, 6, 3 | spun | 33 s | 0.0 | 33.3 | 1.6 | 0 | 1.07x (J2) | 0.33 |
| C_roll60_s11 | 60, 3, 2 | spun | 39 s | 0.0 | 13.3 | -30.7 | 165 | 0.88x (J2) | 0.31 |

With the arm parked and the magnet off, the hull on this gimbal coasts from 40 deg/s to a stop in about 60 s on bearing friction alone (ceramic bearings, 1e-04 N m modeled), so the stand's own friction is part of every physics result; the free-decay run is the baseline to subtract.

**Read the contacts column honestly.** In every physics case the magnet head stayed clear of the hull (no hull contacts). The contacts counted are with the test stand's own ring or yoke: seeds 11 and 12 of case A and case C brushed or pressed into the ring (5 to 31 mm overlap in the model, for 0.6 to 40 s), always while the arm was backing out as the ring swung toward it. Case B briefly asked J2 for 7% more than its continuous rating (well inside the 2.3x peak rating). Two further cases were run before the workspace restarts cut the batch short: a mixed tumble (15, 10, 5 deg/s) where the arm never found a spot clear of the moving ring and the hull stopped on bearing friction alone, and an end-over-end tumble (5, 40, 8 deg/s) where the ring sweeps the whole workspace and the arm cannot work at all. The ring-avoidance logic is the open software item: it predicts the ring from the hull's estimated attitude, and near gimbal lock that prediction is poor.

## 5. Kinematic simulation (the same cases, no friction, no servo dynamics)

| Case | Body rates at t=0 deg/s | Magnet | Stopped at | Final spin deg/s | Min head-hull gap mm | Min gimbal gap mm | Contacts |
|---|---|---|---|---|---|---|---|
| A_roll40_s11 | 40, 4, 2 | spun | not within the run | 19.9 | 20.0 | -5.4 | 20 |
| A_roll40_s12 | 40, 4, 2 | spun | not within the run | 24.0 | 39.0 | 10.9 | 0 |
| A_roll40_still_s11 | 40, 4, 2 | static | not within the run | 14.0 | 9.9 | -5.0 | 80 |
| B_roll25_s11 | 25, 6, 3 | spun | 169 s | 0.7 | -18.1 | 5.3 | 379 |

## 6. What the gimbal taught us

A ring-and-yoke gimbal gives the target three free axes, but the ring (380 mm across) moves with the hull's roll axis. When the hull tumbles end over end (fast rotation about the ring's pitch axis) the ring sweeps a complete sphere around the target once per turn, and no arm coming from outside can stay near the hull: case E shows it. With a fast spin about the pin axis and slower motion on the other two (how real debris usually tumbles: a major-axis spin with a wobble) the ring moves slowly and the planner works around it. The software now treats the ring, pins and yoke as moving obstacles predicted over the planning horizon, brakes only from the open side of the ring, backs out along the ring's normal when the ring approaches, and re-checks every spot's reachability every 2 s. The free-rotation stand is right for roll-dominant tumbles; a tilt-limited internal mount (or a spherical air bearing) is the alternative when every axis must spin fast.

Balance matters more than expected: the eddy torque is of order 1 mN m, and a 0.2 mm offset of the hull's center of mass from the gimbal center gives a 3.5 mN m gravity torque. The hull and ring must be balanced to better than 0.02 mm (trim screws, pendulum test) before any braking test means anything.

## 7. Parts list and budget

- 41 purchased line items, $11,740 in parts ($5,082 of it at list prices found in October 2026, the rest estimates or quotes), $13,500 with 15% contingency. Drive train alone (5 actuators, spindle motor and driver, magnet): $4,574.
- `bom/Detumbler_Arm_v2_Parts_List.xlsx`: purchased parts, machined parts with masses, printed parts, fastener counts.

## 8. Files

- `cad/Detumbler_Arm_v2_Assembly.step`, `cad/components/*.step` (13 components, every part named), `cad/stl_printed/` (printed parts), `cad/renders/`, `cad/source/` (CadQuery source: `design2.py` is the single source of truth).
- `fusion/DetumblerArmV2/`: Fusion script that imports the components, builds the nine joints and replays the physics run.
- `physics/`: the MuJoCo model (`detumbler_v2.xml` + meshes), `mj_world.py` (the physics world the mission code drives), `mj_run.py`, `batch_v2.py`, results.
- `software/`: the robot software with the new `detumbler/gimbal.py`, the drive interpolator (`RefShaper`), the gimbal-aware planner and safety logic, and the configs `config/arm_v2_5dof.toml`, `config/rig_v2.toml` generated from the CAD.
- `loads_report.md`, `interference_report.json`, `bom/`.

## 9. Next steps

1. Order the five actuators and the magnet (longest lead items), download the actuator drawings and confirm the bolt patterns in `design2.py`.
2. Build the target stand first (cheapest, and it validates the balancing procedure and the camera tracking).
3. Machine the hubs, bond the tubes, assemble the arm on the pedestal; run the EtherCAT drives with the mission software's `ArmIO` against the simulator first.
4. Camera software: the vision pipeline exists (ArUco on six faces, tool marker block, camera-to-robot calibration); the next piece is the two-camera fusion and the gimbal-ring occlusion handling, which the simulation shows is needed.
5. Optional: J2 gas-spring counterbalance; a spherical air bearing stand for fast multi-axis tumbles.
