"""Scene around the arm: camera mast with two global-shutter cameras and lights, controller cabinet."""
import os
import sys
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import design2 as D  # noqa: E402
from cad2_lib import cyl, tube, box, rbox, fuse, along, holes, screws, pcd_points, CLEARANCE  # noqa: E402
from cad_lib import extrusion  # noqa: E402

FLOOR = -D.BASE_PLATE["t"] - D.PEDESTAL["h"]
TC = np.array(D.TARGET_CENTER)
CAMERAS = [  # name, position (robot frame, mm), look-at
    ("cam_A", (TC[0] - 350.0, -850.0, TC[2] + 500.0), TC),
    ("cam_B", (TC[0] + 350.0, -850.0, TC[2] + 500.0), TC),
]
MAST_X = TC[0]
MAST_Y = -950.0


def camera_body(pos, look):
    pos, look = np.asarray(pos, float), np.asarray(look, float)
    d = look - pos
    d /= np.linalg.norm(d)
    body = box((-19, 19), (-19, 19), (-14, 0))                  # 38 mm board camera housing, lens along +z
    lens = cyl(7.0, (0, 0, 0), (0, 0, 14))
    return [("camera_housing", along(body, pos, d), "printed", "printed"), ("camera_lens_6mm", along(lens, pos, d), "black", "alu")]


def camera_mast_parts():
    P = []
    zf = FLOOR
    base = rbox((MAST_X - 200, MAST_X + 200), (MAST_Y - 150, MAST_Y + 150), (zf, zf + 12), 15)
    P.append(("mast_base_plate", base, "alu", "alu"))
    P.append(("mast_post_4040", extrusion(40, (MAST_X, MAST_Y, zf + 12), (MAST_X, MAST_Y, TC[2] + 560)), "extrusion", "alu"))
    P.append(("mast_crossbar_4040", extrusion(40, (MAST_X - 400, MAST_Y + 40, TC[2] + 520), (MAST_X + 400, MAST_Y + 40, TC[2] + 520)), "extrusion", "alu"))
    P.append(("mast_corner_bracket_plate", box((MAST_X - 30, MAST_X + 30), (MAST_Y + 20, MAST_Y + 20.0 + 0.0), (TC[2] + 500, TC[2] + 540)) if False else
             box((MAST_X - 30, MAST_X + 30), (MAST_Y + 60, MAST_Y + 66), (TC[2] + 480, TC[2] + 560)), "steel", "steel"))
    for name, pos, look in CAMERAS:
        pos = np.asarray(pos, float)
        P.append((f"{name}_bracket", box((pos[0] - 20, pos[0] + 20), (MAST_Y + 60, pos[1] - 26), (pos[2] - 6, pos[2] + 6)), "alu", "alu"))
        P += [(f"{name}_{n}", s, c, m) for n, s, c, m in camera_body(pos, look)]
    # two LED panels either side, aimed at the target
    for i, s in enumerate((-1, 1)):
        pos = np.array([MAST_X + s * 380, MAST_Y + 40, TC[2] + 585])
        d = TC - pos
        d /= np.linalg.norm(d)
        panel = box((-60, 60), (-40, 40), (-10, 0))
        P.append((f"led_panel_{i}", along(panel, pos, d), "white", "alu"))
    return P


def controller_parts():
    P = []
    zf = FLOOR
    x0, y0 = -420.0, -700.0
    w, dpt, h = 500.0, 210.0, 400.0
    enc = box((x0, x0 + w), (y0, y0 + dpt), (zf, zf + h)).cut(box((x0 + 2, x0 + w - 2), (y0 - 1, y0 + dpt - 2), (zf + 2, zf + h - 2)))
    P.append(("cabinet_steel_enclosure", enc, "alu_dark", "steel"))
    rail_z = (zf + h * 0.72, zf + h * 0.42, zf + h * 0.14)
    for i, z in enumerate(rail_z):
        P.append((f"din_rail_{i}", box((x0 + 20, x0 + w - 20), (y0 + dpt - 12, y0 + dpt - 4), (z - 17.5, z + 17.5)), "steel", "steel"))
    items = [  # name, x, z-row, size (w, d, h), color
        ("psu_RSP-1500-48", 30, 0, (280, 90, 100), "steel"),
        ("safety_relay_PNOZ_s3", 330, 0, (45, 100, 100), "pcb_blue"),
        ("contactor_48V", 390, 0, (60, 100, 100), "anod_black"),
        ("ethercat_pc_fanless", 30, 1, (250, 120, 70), "alu"),
        ("odrive_S1_spindle_driver", 300, 1, (70, 100, 25), "pcb"),
        ("io_module_estop_chain", 390, 1, (60, 100, 70), "pcb_blue"),
        ("breaker_and_terminals", 30, 2, (420, 60, 60), "alu_dark"),
    ]
    for name, dx, row, (iw, idp, ih), col in items:
        z = rail_z[row]
        y1 = y0 + dpt - 16
        P.append((name, rbox((x0 + dx, x0 + dx + iw), (y1 - idp, y1), (z - ih / 2, z + ih / 2), 2), col, "steel"))
    # cable glands on top, E-stop on the front
    for i, xg in enumerate((80, 160, 240, 320)):
        enc = enc.cut(cyl(9.2, (x0 + xg, y0 + dpt / 2, zf + h - 3), (x0 + xg, y0 + dpt / 2, zf + h + 1)))
        P.append((f"cable_gland_{i}", cyl(9, (x0 + xg, y0 + dpt / 2, zf + h - 2), (x0 + xg, y0 + dpt / 2, zf + h + 14)), "anod_black", "steel"))
    P[0] = ("cabinet_steel_enclosure", enc, "alu_dark", "steel")
    P.append(("estop_button", cyl(20, (x0 + w - 60, y0 + 1, zf + h - 60), (x0 + w - 60, y0 - 22, zf + h - 60)), "red", "steel"))
    return P


COMPONENTS = [("CAMERA_MAST", camera_mast_parts), ("CONTROLLER", controller_parts)]

if __name__ == "__main__":
    for n, fn in COMPONENTS:
        p = fn()
        print(n, len(p), [q[0] for q in p if not q[1].isValid()])
