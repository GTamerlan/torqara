import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad2_rig, interference as I
t=time.time()
comps = cad2_rig.components()
inter, thread = I.check(comps)
print(f"checked {sum(len(v) for v in comps.values())} parts in {time.time()-t:.0f}s: {len(inter)} interferences, {len(thread)} fastener engagements")
for r in inter[:60]: print("  INTERFERENCE", r)
import json; json.dump({"interferences": inter, "thread_engagements": thread}, open("out/interference_report.json","w"), indent=1)
