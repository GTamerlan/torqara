"""Pairwise interference check over a components dict {comp: [(name, shape, color, material), ...]}.

Screws, pins and set screws engage their tapped holes on purpose (modeled as the tap drill), so overlaps between a
fastener and a part are reported separately as 'thread engagement' unless they exceed the engaged-thread volume.
Everything else that overlaps by more than `tol` mm^3 is a real interference.
"""
import itertools
import numpy as np
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
from OCP.Bnd import Bnd_Box
from OCP.BRepBndLib import BRepBndLib

FASTENER_WORDS = ("screw", "pin", "bolt")


def bbox(shape):
    b = Bnd_Box()
    BRepBndLib.Add_s(shape.wrapped, b, False)
    return np.array(b.Get())


def overlap(a, b):
    try:
        op = BRepAlgoAPI_Common(a.wrapped, b.wrapped)
        op.Build()
        if not op.IsDone():
            return 0.0
        from cadquery import Shape
        return Shape.cast(op.Shape()).Volume()
    except Exception:
        return 0.0


def is_fastener(name):
    toks = name.lower().replace("-", "_").split("_")
    return any(any(t.startswith(w) for w in FASTENER_WORDS) for t in toks)


def check(comps, tol=2.0, pairs_within_component=True, pairs_across=None, moving_pairs_skip=()):
    """Returns (interferences, thread_engagements): lists of (compA, partA, compB, partB, volume_mm3)."""
    items = []
    for cname, parts in comps.items():
        for pname, shape, _c, _m in parts:
            items.append((cname, pname, shape, bbox(shape)))
    inter, thread = [], []
    for (ca, pa, sa, ba), (cb, pb, sb, bb) in itertools.combinations(items, 2):
        if ca == cb and not pairs_within_component:
            continue
        if (ca, cb) in moving_pairs_skip or (cb, ca) in moving_pairs_skip:
            continue
        if pairs_across is not None and ca != cb and (ca, cb) not in pairs_across and (cb, ca) not in pairs_across:
            continue
        # bounding boxes first
        if (ba[0] > bb[3] + 0.01 or bb[0] > ba[3] + 0.01 or ba[1] > bb[4] + 0.01 or bb[1] > ba[4] + 0.01
                or ba[2] > bb[5] + 0.01 or bb[2] > ba[5] + 0.01):
            continue
        v = overlap(sa, sb)
        if v <= tol:
            continue
        rec = (ca, pa, cb, pb, round(v, 1))
        if is_fastener(pa) != is_fastener(pb):
            thread.append(rec)
        else:
            inter.append(rec)
    inter.sort(key=lambda r: -r[4])
    thread.sort(key=lambda r: -r[4])
    return inter, thread
