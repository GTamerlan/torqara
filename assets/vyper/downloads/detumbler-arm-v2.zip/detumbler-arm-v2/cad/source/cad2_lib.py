import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, "..", ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Real-part library for arm v2: actuators with their bolt patterns, screws, bearings, tubes, hubs with holes.

Everything is built in local coordinates along +z and placed with `along()` / `place()` from cad_lib.
A "part" is a list of (name, shape, color) tuples; `holes()` cuts real holes into a solid.
"""
import math
import os
import sys
import numpy as np
import cadquery as cq

sys.path.insert(0, _HERE)
from cad_lib import V, COL, color, cyl, tube, box, rbox, fuse, rot_to, place, along, mass_props, bearing_local, aruco_bits  # noqa: F401,E402

# ISO 4762 socket head cap screws: thread -> (nominal d, head d, head h, hex key). Clearance hole = ISO 273 medium.
SCREW = {"M3": (3.0, 5.5, 3.0, 2.5), "M4": (4.0, 7.0, 4.0, 3.0), "M5": (5.0, 8.5, 5.0, 4.0), "M6": (6.0, 10.0, 6.0, 5.0),
         "M8": (8.0, 13.0, 8.0, 6.0), "M10": (10.0, 16.0, 10.0, 8.0)}
CLEARANCE = {"M3": 3.4, "M4": 4.5, "M5": 5.5, "M6": 6.6, "M8": 9.0, "M10": 11.0}
TAP_DRILL = {"M3": 2.5, "M4": 3.3, "M5": 4.2, "M6": 5.0, "M8": 6.8, "M10": 8.5}


def pcd_points(n, pcd, phase_deg=0.0):
    return [(pcd / 2 * math.cos(a), pcd / 2 * math.sin(a)) for a in np.radians(phase_deg) + np.linspace(0, 2 * math.pi, n, endpoint=False)]


def screw_local(thread, length):
    """Socket head cap screw along -z: head top at z = head_h, bearing face at z = 0, shank to z = -length."""
    d, hd, hh, key = SCREW[thread]
    head = cyl(hd / 2, (0, 0, 0), (0, 0, hh))
    sock = cq.Workplane("XY").workplane(offset=hh).polygon(6, key / math.cos(math.pi / 6)).extrude(-min(0.6 * hh, 3.0)).val()
    head = head.cut(sock)
    shank = cyl(d / 2, (0, 0, -length), (0, 0, 0))
    return fuse(head, shank)


def screws(thread, length, pts, p0, d, spin_deg=0.0):
    """A set of screws at xy points in a local frame whose +z is `d` and origin `p0` (head sits on the z=0 face,
    shank goes toward -z). Returned as one fused solid."""
    s = screw_local(thread, length)
    parts = [s.translate(V(x, y, 0)) for x, y in pts]
    return along(fuse(*parts), p0, d, spin_deg)


def holes(solid, dia, pts, p0, d, depth=1e3, counterbore=None, spin_deg=0.0):
    """Cut round holes (dia) at xy points of the local frame (origin p0, +z = d) going toward -z from z=+1.
    counterbore=(dia, depth) adds a counterbore from the z=0 face toward -z."""
    cutters = [cyl(dia / 2, (x, y, -depth), (x, y, 1.0)) for x, y in pts]
    if counterbore:
        cd, cdep = counterbore
        cutters += [cyl(cd / 2, (x, y, -cdep), (x, y, 1.0)) for x, y in pts]
    return solid.cut(along(fuse(*cutters), p0, d, spin_deg))


def bore(solid, dia, p0, p1):
    return solid.cut(cyl(dia / 2, p0, p1))


# ------------------------------------------------------------------------------------------------- actuator
def hj2_flange_d(cfg):
    n, thr, pcd = cfg["out_bolts"]
    return 2 * math.floor((pcd / 2 + TAP_DRILL[thr] / 2 + 1.5))


def hj2_local(cfg):
    """Leadshine HJ2 integrated actuator along +z: output flange face at z = 0, body toward -z, rear face at
    z = -L. Output flange: raised 3 mm disc with the tapped output pattern. Rear face: tapped body pattern.
    Hollow bore through. EtherCAT in/out + power connectors on the side near the rear."""
    od, L, bore_d = cfg["od"], cfg["L"], cfg["bore"]
    fd = hj2_flange_d(cfg)
    body = cyl(od / 2, (0, 0, -L), (0, 0, -3.0))
    body = body.cut(cyl(od / 2 - 1.5, (0, 0, -L + 1.5), (0, 0, -L + 1.6)))     # cosmetic parting line
    body = body.cut(cyl(od / 2 - 1.5, (0, 0, -3.0 - 0.1), (0, 0, -3.0)))
    n, thr, pcd = cfg["body_bolts"]
    body = holes(body, TAP_DRILL[thr], pcd_points(n, pcd), (0, 0, -L), (0, 0, -1), depth=12.0)   # rear tapped holes
    body = body.cut(cyl(bore_d / 2, (0, 0, -L - 1), (0, 0, 1)))
    flange = cyl(fd / 2, (0, 0, -3.0), (0, 0, 0.0)).cut(cyl(bore_d / 2 + 2.0, (0, 0, -4), (0, 0, 1)))
    n, thr, pcd = cfg["out_bolts"]
    flange = holes(flange, TAP_DRILL[thr], pcd_points(n, pcd), (0, 0, 0), (0, 0, 1), depth=3.0)
    # connectors: two M8 EtherCAT + one power, on the side at the rear
    conns = fuse(*[cyl(5.5, (od / 2, y, -L + 12), (od / 2 + 9, y, -L + 12)) for y in (-12, 0, 12)])
    return [("actuator_body", body, "anod_black"), ("actuator_output_flange", flange, "alu_dark"),
            ("actuator_connectors", conns, "steel")]


def hj2(cfg, p_flange, d_out, spin_deg=0.0, prefix=""):
    """Actuator placed with its output flange face at p_flange, output pointing along d_out."""
    return [(prefix + n, along(s, p_flange, d_out, spin_deg), c) for n, s, c in hj2_local(cfg)]


def cb_screws(thread, plate_t, engage, pts, p_top, d, spin_deg=0.0):
    """Counterbored screws through a plate: p_top is the plate's outer face, d points out of that face. The head
    sits (head_h + 0.5) below the face; the shank goes through the plate and `engage` mm into the part beyond."""
    hh = SCREW[thread][2]
    d = np.asarray(d, float) / np.linalg.norm(d)
    return screws(thread, plate_t - hh - 0.5 + engage, pts, np.asarray(p_top, float) - d * (hh + 0.5), d, spin_deg)


def flange_screws(cfg, p_flange, d_out, plate_t, spin_deg=0.0):
    """Counterbored screws that hold a hub plate (thickness plate_t) onto the output flange."""
    n, thr, pcd = cfg["out_bolts"]
    d = np.asarray(d_out, float)
    return cb_screws(thr, plate_t, 2.5, pcd_points(n, pcd), np.asarray(p_flange, float) + d * plate_t, d, spin_deg)


def body_screws(cfg, p_flange, d_out, plate_t, spin_deg=0.0):
    """Counterbored screws that hold the actuator's rear face against a mounting plate."""
    n, thr, pcd = cfg["body_bolts"]
    d = np.asarray(d_out, float)
    p_rear = np.asarray(p_flange, float) - d * cfg["L"]
    return cb_screws(thr, plate_t, 10.0, pcd_points(n, pcd), p_rear - d * plate_t, -d, spin_deg)


def hub_plate_holes(solid, cfg, p_flange, d_out, plate_t, spin_deg=0.0):
    """Clearance + counterbore holes in a hub plate sitting on the output flange (plate from the flange face to
    plate_t along d_out), plus the center hole for the hollow bore."""
    n, thr, pcd = cfg["out_bolts"]
    hd, hh = SCREW[thr][1], SCREW[thr][2]
    d = np.asarray(d_out, float)
    top = np.asarray(p_flange, float) + d * plate_t
    solid = holes(solid, CLEARANCE[thr], pcd_points(n, pcd), top, d, depth=plate_t + 1, counterbore=(hd + 0.6, hh + 0.5), spin_deg=spin_deg)
    return solid.cut(cyl(cfg["bore"] / 2 + 3.0, top + d * 1, top - d * (plate_t + 1)))


def body_plate_holes(solid, cfg, p_flange, d_out, plate_t, spin_deg=0.0):
    """Clearance + counterbore holes in a plate that the actuator's rear face bolts to (plate from the rear face
    outward along -d_out by plate_t), plus the cable hole."""
    n, thr, pcd = cfg["body_bolts"]
    hd, hh = SCREW[thr][1], SCREW[thr][2]
    d = np.asarray(d_out, float)
    outer = np.asarray(p_flange, float) - d * (cfg["L"] + plate_t)
    solid = holes(solid, CLEARANCE[thr], pcd_points(n, pcd), outer, -d, depth=plate_t + 1, counterbore=(hd + 0.6, hh + 0.5), spin_deg=spin_deg)
    return solid.cut(cyl(cfg["bore"] / 2 + 6.0, outer - d * 1, outer + d * (plate_t + 1)))


# ------------------------------------------------------------------------------------------------- tubes + bonded sockets
def carbon_tube(od, wall, p0, p1):
    return tube(od / 2, od / 2 - wall, p0, p1)


def cross_pins(od, p_center, axis, n=2, pitch=14.0, thread="M4"):
    """Radial pins through a bonded tube socket: n rows of two pins, 90 deg apart, M4 socket set screws."""
    axis = np.asarray(axis, float) / np.linalg.norm(axis)
    u = np.cross(axis, [0, 0, 1.0]) if abs(axis[2]) < 0.9 else np.cross(axis, [1.0, 0, 0])
    u /= np.linalg.norm(u)
    v = np.cross(axis, u)
    d = SCREW[thread][0]
    parts = []
    for i in range(n):
        c = np.asarray(p_center, float) + axis * (i - (n - 1) / 2) * pitch
        for w in (u, v):
            parts.append(cyl(d / 2, c - w * (od / 2 + 1), c + w * (od / 2 + 1)))
    return fuse(*parts)


# ------------------------------------------------------------------------------------------------- misc
def bearing(cfg, p0, d, prefix="bearing"):
    """Ball bearing from a bore of diameter cfg['od'] starting at p0 (inner face) toward d by cfg['w']."""
    parts = bearing_local(cfg["od"], cfg["bore"], cfg["w"])
    out = []
    for (s, c), n in zip(parts, ("_outer", "_inner", "_seal")):
        out.append((prefix + n, along(s, p0, d), "ceramic" if "ceramic" in cfg.get("name", "") and n != "_seal" else c))
    return out


COL.setdefault("ceramic", (0.93, 0.93, 0.90, 1))
COL.setdefault("ti", (0.60, 0.62, 0.66, 1))
COL.setdefault("pa_cf", (0.16, 0.17, 0.19, 1))
COL.setdefault("magnet_n", (0.80, 0.20, 0.20, 1))
COL.setdefault("magnet_s", (0.20, 0.30, 0.80, 1))


def marker_block(center, side, marker, ids, plate_t=2.0):
    """Printed cube with four ArUco marker plates on its +-y and +-z faces (x along the boom)."""
    from cad_lib import marker_plate_local
    c = np.asarray(center, float)
    cube = rbox((c[0] - side / 2, c[0] + side / 2), (c[1] - side / 2, c[1] + side / 2), (c[2] - side / 2, c[2] + side / 2), 3, edges="|X")
    parts = [("tool_marker_block_printed", cube, "printed")]
    for mid, n in zip(ids, ([0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1])[:len(ids)]):
        n = np.asarray(n, float)
        for (s, col), nm in zip(marker_plate_local(mid, marker, side - 4, plate_t), ("_plate", "_ink")):
            # plate built along +z with image up = +y; we want image up = +x (toward the magnet)
            R = rot_to(n)
            # rotate about the plate normal so that local +y maps to world +x
            up = R @ np.array([0, 1.0, 0])
            ang = math.atan2(np.dot(np.cross(up, [1.0, 0, 0]), n), np.dot(up, [1.0, 0, 0]))
            Rn = rot_to(n) @ np.array([[math.cos(ang), -math.sin(ang), 0], [math.sin(ang), math.cos(ang), 0], [0, 0, 1]])
            parts.append((f"tool_marker_{mid}{nm}", place(s, Rn, c + n * side / 2), col))
    return parts
