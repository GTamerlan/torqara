import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, "..", ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Write the Fusion script folder for arm v2 (out/fusion/DetumblerArmV2) from the first prototype's generic
script: same builder/replayer, new component list, joints and limits, plus a trajectory.json converted from a
recorded simulation (kinematic or physics run).

    python fusion2.py <sim result json with 'trajectory'>
"""
import json
import math
import os
import re
import shutil
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "render"))
import design2 as D  # noqa: E402
from render2 import poses2  # noqa: E402

SRC = _os.path.join(_PKG, "fusion", "DetumblerArmV2", "DetumblerArmV2.py")
OUT = os.path.join(HERE, "out", "fusion", "DetumblerArmV2")
TC = tuple(float(v) for v in D.TARGET_CENTER)
MC = tuple(float(v) for v in D.MAGNET_CENTER)
FIXED = ["CAMERA_MAST", "CONTROLLER", "TARGET_STAND", "ARM_BASE"]
MOVING = ["TARGET_YOKE", "TARGET_RING", "TARGET_BOX", "ARM_L1_TURRET", "ARM_L2_UPPER", "ARM_L3_FOREARM", "ARM_L4_FORK", "ARM_L5_HEAD", "ARM_L6_ROTOR"]
L = D.JOINT_LIMITS
JOINTS = [
    ("J1 base yaw", "ARM_L1_TURRET", "ARM_BASE", (0.0, 0.0, 0.0), "z", L["J1"]),
    ("J2 shoulder", "ARM_L2_UPPER", "ARM_L1_TURRET", (0.0, 0.0, D.Z2), "y", L["J2"]),
    ("J3 elbow", "ARM_L3_FOREARM", "ARM_L2_UPPER", (0.0, 0.0, D.Z3), "y", L["J3"]),
    ("J4 forearm roll", "ARM_L4_FORK", "ARM_L3_FOREARM", (0.0, 0.0, D.Z3), "x", L["J4"]),
    ("J5 wrist pitch", "ARM_L5_HEAD", "ARM_L4_FORK", (D.X5, 0.0, D.Z3), "y", L["J5"]),
    ("Magnet spin", "ARM_L6_ROTOR", "ARM_L5_HEAD", MC, "x", None),
    ("Gimbal yaw", "TARGET_YOKE", "TARGET_STAND", TC, "z", None),
    ("Gimbal pitch", "TARGET_RING", "TARGET_YOKE", TC, "y", None),
    ("Gimbal roll", "TARGET_BOX", "TARGET_RING", TC, "x", None),
]
AX = {"x": np.array([1.0, 0, 0]), "y": np.array([0, 1.0, 0]), "z": np.array([0, 0, 1.0])}


def mat(flat):
    return np.array(flat, float).reshape(4, 4).T


def rot_about(p, a, ang):
    a = a / np.linalg.norm(a)
    K = np.array([[0, -a[2], a[1]], [a[2], 0, -a[0]], [-a[1], a[0], 0]])
    R = np.eye(3) + math.sin(ang) * K + (1 - math.cos(ang)) * K @ K
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = np.asarray(p, float) - R @ np.asarray(p, float)
    return T


def signed_angle(R, a):
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]]) / 2.0
    return math.atan2(float(v @ a), (np.trace(R) - 1) / 2.0)


def convert(src, out):
    d = json.load(open(src))
    tr = d["trajectory"]
    frames, worst, prev = [], 0.0, {}
    for f in tr:
        P = {k: mat(v) for k, v in poses2(f["q_deg"], f["target_quat"], f["magnet_spin_deg"]).items()}
        vals, rebuilt = {}, {}
        for name, child, parent, pt, ax, _lim in JOINTS:
            Tp = np.eye(4) if parent in FIXED else P[parent]
            rel = np.linalg.inv(Tp) @ P[child]
            ang = signed_angle(rel[:3, :3], AX[ax])
            if name in prev:
                ang = prev[name] + (ang - prev[name] + math.pi) % (2 * math.pi) - math.pi
            prev[name] = ang
            vals[name] = round(math.degrees(ang), 4)
            Tpb = np.eye(4) if parent in FIXED else rebuilt[parent]
            rebuilt[child] = Tpb @ rot_about(pt, AX[ax], ang)
        for k in rebuilt:
            worst = max(worst, float(np.max(np.abs(rebuilt[k] - P[k]))))
        frames.append({"t": f["t"], "phase": f["phase"], "spin_dps": f["spin_dps"], "magnet_rpm": f["rpm"],
                       "gap_mm": f.get("gap_mm"), "joints_deg": vals})
    dt = round(tr[1]["t"] - tr[0]["t"], 6)
    s = d.get("summary", {})
    meta = {"source": f"detumbler v2 simulation {s.get('name', '')}: tumble {s.get('spin0_dps')} deg/s, seed {s.get('seed')}, "
                      f"{'physics (MuJoCo)' if 'physics' in d else 'kinematic simulator'}",
            "units": "degrees; every joint measured from the as-built (home) pose, right-hand rule about its +X/+Y/+Z axis", "summary": s}
    json.dump({"dt": dt, "meta": meta, "joints": [j[0] for j in JOINTS], "frames": frames}, open(out, "w"), separators=(",", ":"))
    print(f"{len(frames)} frames, dt {dt}s; chain rebuilt from joint values matches FK to {worst:.2e}")
    return worst


def write_script():
    s = open(SRC).read()
    s = re.sub(r'FIXED = \[.*?\]\n', f"FIXED = {FIXED!r}\n", s, count=1, flags=re.S)
    s = re.sub(r'MOVING = \[.*?\]\n', f"MOVING = {MOVING!r}\n", s, count=1, flags=re.S)
    jl = "JOINTS = [\n" + "".join(f"    {j!r},\n" for j in JOINTS) + "]\n"
    s = re.sub(r'JOINTS = \[.*?\n\]\n', jl, s, count=1, flags=re.S)
    s = s.replace("Detumbler rig for Autodesk Fusion: builds the assembly with real joints, then replays a simulated mission.",
                  "Detumbler arm v2 for Autodesk Fusion: builds the assembly with real joints, then replays a simulated mission.")
    s = s.replace("imports every component STEP from ./step (table, arm links,\ntarget, camera, controller)",
                  "imports every component STEP from ./step (pedestal and arm links,\ntarget hull and its free three-axis gimbal, camera mast, controller)")
    s = s.replace("origin on the table under the arm,", "origin on the arm's base plate under the J1 axis,")
    s = s.replace('"Detumbler rig"', '"Detumbler arm v2"')
    s = s.replace("The rig is built;", "The model is built;")
    os.makedirs(f"{OUT}/step", exist_ok=True)
    open(f"{OUT}/DetumblerArmV2.py", "w").write(s)
    man = json.load(open(os.path.dirname(SRC) + "/DetumblerRig.manifest"))
    man["description"][""] = "Builds the detumbler arm v2 with its target gimbal, with real joints, and replays a simulated mission."
    json.dump(man, open(f"{OUT}/DetumblerArmV2.manifest", "w"), indent=2)
    for c in FIXED + MOVING:
        src = f"{HERE}/out/cad/components/{c}.step"
        if os.path.exists(src):
            shutil.copy2(src, f"{OUT}/step/{c}.step")
        else:
            print("missing STEP for", c)


if __name__ == "__main__":
    write_script()
    if len(sys.argv) > 1:
        convert(sys.argv[1], f"{OUT}/trajectory.json")
    print("wrote", OUT)
