"""Arm v2 links: base, turret, upper arm, forearm, wrist fork, head, rotor. Home pose, robot base frame, mm.

Each link function returns a list of (part name, shape, color, material). Fasteners are real screws (ISO 4762)
in real holes: every hub plate has clearance + counterbore holes on the actuator's bolt pattern, every bonded
carbon-tube socket has cross pins, every bearing sits in a bore. Where a link body would cover the hub screws,
the hub is a separate disc (screwed to the actuator first) and the body bolts to the disc.
"""
import math
import sys
import os
import numpy as np
import cadquery as cq

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import design2 as D  # noqa: E402
from cad2_lib import (V, cyl, tube, box, rbox, fuse, along, place, rot_to, hj2, flange_screws, body_screws, cb_screws,  # noqa: E402
                      hub_plate_holes, body_plate_holes, holes, bore, carbon_tube, cross_pins, screws,
                      bearing, pcd_points, SCREW, CLEARANCE, TAP_DRILL, marker_block)

ZA = D.Z3
A = {j: D.HJ2[D.JOINT_ACTUATOR[j]] for j in D.JOINT_ACTUATOR}
X, Y, Z = np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])

# joint flange positions, output directions and pattern phase (home)
J1_P, J1_D, J1_S = (0.0, 0.0, D.Z1F), Z, -90.0
J2_P, J2_D, J2_S = (0.0, D.J2_FLANGE_Y, D.Z2), Y, 195.0
J3_P, J3_D, J3_S = (0.0, D.J3_FLANGE_Y, ZA), -Y, 90.0
J4_P, J4_D, J4_S = (D.J4_FLANGE_X, 0.0, ZA), X, 90.0
J5_P, J5_D, J5_S = (D.X5, D.J5_FLANGE_Y, ZA), -Y, 90.0


def act_parts(j, p, d, spin):
    return [(n, s, c, "actuator") for n, s, c in hj2(A[j], p, d, spin, prefix=f"{j}_")]


def brg_parts(cfg, p0, d, prefix):
    return [(n, s, c, "ceramic" if "seal" not in n else "rubber") for n, s, c in bearing(cfg, p0, d, prefix=prefix)]


# ------------------------------------------------------------------------------------------------- link 0: base
def base_parts():
    a = A["J1"]
    P = []
    ped = D.PEDESTAL
    zf = -D.BASE_PLATE["t"] - ped["h"]
    foot = rbox((-ped["foot"][0] / 2, ped["foot"][0] / 2), (-ped["foot"][1] / 2, ped["foot"][1] / 2), (zf - ped["foot"][2], zf), 20)
    foot = holes(foot, 12.0, [(sx * 260, sy * 260) for sx in (-1, 1) for sy in (-1, 1)], (0, 0, zf), Z)
    P.append(("pedestal_foot_plate", foot, "steel", "steel"))
    P.append(("pedestal_column", tube(ped["od"] / 2, ped["od"] / 2 - ped["wall"], (0, 0, zf), (0, 0, -D.BASE_PLATE["t"] - 12)), "steel", "steel"))
    top_ring = tube(ped["od"] / 2 + 15, ped["od"] / 2 - ped["wall"], (0, 0, -D.BASE_PLATE["t"] - 12), (0, 0, -D.BASE_PLATE["t"]))
    top_ring = holes(top_ring, TAP_DRILL["M10"], pcd_points(6, ped["od"] + 10, 30), (0, 0, -D.BASE_PLATE["t"]), Z, depth=20)
    P.append(("pedestal_top_ring", top_ring, "steel", "steel"))
    for i in range(4):
        ang = math.radians(45 + 90 * i)
        c = (260 * math.cos(ang), 260 * math.sin(ang))
        P.append((f"leveling_foot_{i}", cyl(22, (c[0], c[1], zf - ped["foot"][2] - 30), (c[0], c[1], zf - ped["foot"][2])), "rubber", "steel"))
    bp = D.BASE_PLATE
    plate = rbox((-bp["x"] / 2, bp["x"] / 2), (-bp["y"] / 2, bp["y"] / 2), (-bp["t"], 0.0), 15)
    plate = bore(plate, 100.0, (0, 0, -bp["t"] - 1), (0, 0, 1))
    plate = holes(plate, CLEARANCE["M10"], pcd_points(6, ped["od"] + 10, 30), (0, 0, 0), Z, depth=bp["t"] + 1,
                  counterbore=(SCREW["M10"][1] + 0.6, SCREW["M10"][2] + 0.5))
    plate = holes(plate, TAP_DRILL["M8"], pcd_points(6, 150.0), (0, 0, 0), Z, depth=16)
    P.append(("base_plate", plate, "alu", "alu"))
    P.append(("plate_to_pedestal_screws_M10", cb_screws("M10", bp["t"], 16, pcd_points(6, ped["od"] + 10, 30), (0, 0, 0), Z), "anod_black", "steel"))
    # J1 housing: a cup; the actuator hangs from the cup floor by its rear face (screws driven from below, through the plate hole)
    z_rear = D.Z1F - a["L"]
    floor_t = 12.0
    cup = cyl(65.0, (0, 0, 0), (0, 0, D.Z1F - 6))
    cup = cup.cut(cyl(a["od"] / 2 + 0.3, (0, 0, z_rear), (0, 0, D.Z1F)))
    cup = cup.cut(cyl(50.0, (0, 0, -1), (0, 0, z_rear - floor_t)))
    cup = fuse(cup, cyl(85.0, (0, 0, 0), (0, 0, 8.0)).cut(cyl(50.0, (0, 0, -1), (0, 0, 9))))
    cup = holes(cup, CLEARANCE["M8"], pcd_points(6, 150.0), (0, 0, 8.0), Z, depth=9, counterbore=(SCREW["M8"][1] + 0.6, SCREW["M8"][2] + 0.5))
    cup = body_plate_holes(cup, a, J1_P, J1_D, floor_t, J1_S)
    cup = cup.cut(box((-20, 20), (-70, -40), (z_rear + 2, D.Z1F - 6)))          # connector window
    P.append(("J1_housing_cup", cup, "alu", "alu"))
    P.append(("cup_to_plate_screws_M8", cb_screws("M8", 8.0, 14, pcd_points(6, 150.0), (0, 0, 8.0), Z), "anod_black", "steel"))
    P.append(("J1_body_screws_M5", body_screws(a, J1_P, J1_D, floor_t, J1_S), "anod_black", "steel"))
    P += act_parts("J1", J1_P, J1_D, J1_S)
    return P


# ------------------------------------------------------------------------------------------------- link 1: turret
def turret_parts():
    a1, a2 = A["J1"], A["J2"]
    P = []
    disc_t = 15.0
    disc = cyl(50.0, (0, 0, D.Z1F), (0, 0, D.Z1F + disc_t))
    y_rear = D.J2_FLANGE_Y - a2["L"]
    pt = 12.0
    plate = rbox((-75, 75), (y_rear - pt, y_rear), (D.Z1F + 1, D.Z2 + 75), 14, edges="|Y")
    rib = rbox((-55, 55), (y_rear - pt + 1, -42), (D.Z1F + 1, D.Z2 - 58), 6, edges="|Z")
    tur = fuse(disc, plate, rib)
    tur = hub_plate_holes(tur, a1, J1_P, J1_D, disc_t, J1_S)
    tur = body_plate_holes(tur, a2, J2_P, J2_D, pt, J2_S)
    tur = tur.cut(box((-38, 38), (y_rear - pt - 1, -62), (D.Z1F + disc_t + 4, D.Z1F + disc_t + 26)))   # cable pass
    P.append(("turret_bracket", tur, "alu", "alu"))
    P.append(("J1_flange_screws_M5", flange_screws(a1, J1_P, J1_D, disc_t, J1_S), "anod_black", "steel"))
    P.append(("J2_body_screws_M5", body_screws(a2, J2_P, J2_D, pt, J2_S), "anod_black", "steel"))
    P += act_parts("J2", J2_P, J2_D, J2_S)
    return P


# ------------------------------------------------------------------------------------------------- link 2: upper arm
UPPER_BLOCK_PTS = [(43, -25.5), (43, 25.5), (-43, -25.5), (-43, 25.5)]      # (x, z-Z2) block-to-disc screws, r = 50


def upper_parts():
    a2, a3 = A["J2"], A["J3"]
    ut = D.UPPER_TUBE
    P = []
    ht = D.UPPER_HUB_T
    y0 = D.J2_FLANGE_Y
    # hub disc: screwed to the J2 flange first; 4 tapped M6 for the block
    disc = cyl(55.0, (0, y0, D.Z2), (0, y0 + ht, D.Z2))
    disc = hub_plate_holes(disc, a2, J2_P, J2_D, ht, J2_S)
    disc = holes(disc, TAP_DRILL["M6"], UPPER_BLOCK_PTS, (0, y0 + ht, D.Z2), Y, depth=ht - 1)
    P.append(("upper_hub_disc", disc, "alu", "alu"))
    P.append(("J2_flange_screws_M5", flange_screws(a2, J2_P, J2_D, ht, J2_S), "anod_black", "steel"))
    # block: holds the tube socket, bolted to the disc with 4 long M6 through its full depth
    yb0, yb1 = y0 + ht, D.UPPER_Y + ut["od"] / 2 + 8
    plate = rbox((-52, 52), (yb0, yb0 + 10), (D.Z2 - 42, D.Z2 + 64), 10, edges="|Y")
    boss = cyl(ut["od"] / 2 + 8, (0, D.UPPER_Y, D.Z2 - 8), (0, D.UPPER_Y, D.Z2 + 64))
    web = rbox((-20, 20), (yb0 + 9, D.UPPER_Y), (D.Z2 - 30, D.Z2 + 56), 4, edges="|Y")
    blk = fuse(plate, boss, web).cut(box((-60, 60), (yb0 - 20, yb0), (D.Z2 - 60, D.Z2 + 80)))      # nothing below the plate face
    blk = bore(blk, ut["od"] + 0.3, (0, D.UPPER_Y, D.Z2), (0, D.UPPER_Y, D.Z2 + 65))
    blk = holes(blk, CLEARANCE["M6"], UPPER_BLOCK_PTS, (0, yb0 + 10, D.Z2), Y, depth=11, counterbore=(SCREW["M6"][1] + 0.6, SCREW["M6"][2] + 0.5))
    pins_lo = cross_pins(ut["od"] + 16, (0, D.UPPER_Y, D.Z2 + 38), Z)
    blk = blk.cut(pins_lo)
    P.append(("upper_hub_block", blk, "alu", "alu"))
    P.append(("upper_block_screws_M6", cb_screws("M6", 10, 10, UPPER_BLOCK_PTS, (0, yb0 + 10, D.Z2), Y), "anod_black", "steel"))
    P.append(("upper_hub_cross_pins_M4", cross_pins(ut["od"] + 15, (0, D.UPPER_Y, D.Z2 + 38), Z), "anod_black", "steel"))
    # tube
    z_top = ZA - 60
    tb = carbon_tube(ut["od"], ut["wall"], (0, D.UPPER_Y, D.Z2 + 1), (0, D.UPPER_Y, z_top))
    pins_hi = cross_pins(ut["od"] + 16, (0, D.UPPER_Y, z_top - 24), Z)
    tb = tb.cut(pins_lo).cut(pins_hi)
    P.append(("upper_arm_tube_carbon", tb, "carbon", "carbon"))
    # elbow housing: cradle around the J3 body, back plate, boss with the tube socket
    y_front = D.J3_FLANGE_Y + 3.0
    y_rear = D.J3_FLANGE_Y + a3["L"]
    pt = 10.0
    cradle = tube(a3["od"] / 2 + 7, a3["od"] / 2 + 0.3, (0, y_front, ZA), (0, y_rear, ZA))
    back = cyl(a3["od"] / 2 + 7, (0, y_rear, ZA), (0, y_rear + pt, ZA))
    boss = cyl(ut["od"] / 2 + 7, (0, D.UPPER_Y, z_top - 50), (0, D.UPPER_Y, ZA - 52))
    web = rbox((-30, 30), (D.UPPER_Y - 25, D.UPPER_Y + 25), (ZA - 60, ZA - 30), 4, edges="|Z")
    eh = fuse(cradle, back, boss, web)
    eh = eh.cut(cyl(a3["od"] / 2 + 0.3, (0, y_front - 1, ZA), (0, y_rear, ZA)))
    eh = body_plate_holes(eh, a3, J3_P, J3_D, pt, J3_S)
    eh = bore(eh, ut["od"] + 0.3, (0, D.UPPER_Y, z_top - 51), (0, D.UPPER_Y, z_top))
    eh = eh.cut(pins_hi)
    eh = eh.cut(box((-20, 20), (y_rear - 40, y_rear + pt + 1), (ZA + a3["od"] / 2 - 7, ZA + a3["od"] / 2 + 15)))   # connector window
    P.append(("elbow_housing", eh, "alu", "alu"))
    P.append(("elbow_cross_pins_M4", cross_pins(ut["od"] + 15, (0, D.UPPER_Y, z_top - 24), Z), "anod_black", "steel"))
    P.append(("J3_body_screws_M5", body_screws(a3, J3_P, J3_D, pt, J3_S), "anod_black", "steel"))
    P += act_parts("J3", J3_P, J3_D, J3_S)
    return P


# ------------------------------------------------------------------------------------------------- link 3: forearm
FORE_BOSS_PTS = [(4.0, -18.0), (4.0, 18.0), (22.0, 0.0)]      # (x, z-ZA) boss-to-disc screws along y, inside the flange PCD


def forearm_parts():
    a3, a4 = A["J3"], A["J4"]
    ft = D.FORE_TUBE
    P = []
    ht = D.FORE_HUB_T
    y0 = D.J3_FLANGE_Y
    disc = cyl(45.0, (0, y0, ZA), (0, y0 - ht, ZA))
    disc = hub_plate_holes(disc, a3, J3_P, J3_D, ht, J3_S)
    disc = holes(disc, TAP_DRILL["M6"], FORE_BOSS_PTS, (0, y0 - ht, ZA), -Y, depth=ht - 1)
    P.append(("forearm_hub_disc", disc, "alu", "alu"))
    P.append(("J3_flange_screws_M5", flange_screws(a3, J3_P, J3_D, ht, J3_S), "anod_black", "steel"))
    # boss along x, screwed to the disc from its -y side with 3 M6 (spot-faced)
    rb = ft["od"] / 2 + 9
    boss = cyl(rb, (-10, 0, ZA), (92, 0, ZA)).cut(box((-11, 93), (y0 - ht, y0 + 1), (ZA - rb - 1, ZA + rb + 1)))
    boss = bore(boss, ft["od"] + 0.3, (30, 0, ZA), (93, 0, ZA))
    for x, dz in FORE_BOSS_PTS:
        boss = boss.cut(box((x - 5.5, x + 5.5), (-rb - 1, -rb + 8), (ZA + dz - 5.5, ZA + dz + 5.5)))       # spot faces
    boss = holes(boss, CLEARANCE["M6"], FORE_BOSS_PTS, (0, -rb + 8, ZA), -Y, depth=2 * rb)
    pins_f = cross_pins(ft["od"] + 16, (62, 0, ZA), X)
    boss = boss.cut(pins_f)
    P.append(("forearm_boss", boss, "alu", "alu"))
    P.append(("forearm_boss_screws_M6", screws("M6", (y0 - ht) + rb - 8 + 10, FORE_BOSS_PTS, (0, -rb + 8, ZA), -Y), "anod_black", "steel"))
    P.append(("forearm_boss_cross_pins_M4", cross_pins(ft["od"] + 15, (62, 0, ZA), X), "anod_black", "steel"))
    # J4 cradle at the forearm end
    x_rear = D.J4_FLANGE_X - a4["L"]
    pt = 12.0
    x_sock0 = x_rear - pt - 10 - 55
    cradle = cyl(a4["od"] / 2 + 1, (x_sock0, 0, ZA), (x_rear, 0, ZA))
    cradle = bore(cradle, ft["od"] + 0.3, (x_sock0 - 1, 0, ZA), (x_rear - pt - 8, 0, ZA))
    cradle = body_plate_holes(cradle, a4, J4_P, J4_D, pt, J4_S)
    pins_c = cross_pins(ft["od"] + 16, (x_sock0 + 28, 0, ZA), X)
    cradle = cradle.cut(pins_c)
    P.append(("J4_cradle", cradle, "alu", "alu"))
    P.append(("J4_cradle_cross_pins_M4", cross_pins(ft["od"] + 15, (x_sock0 + 28, 0, ZA), X), "anod_black", "steel"))
    P.append(("J4_body_screws_M4", body_screws(a4, J4_P, J4_D, pt, J4_S), "anod_black", "steel"))
    tb = carbon_tube(ft["od"], ft["wall"], (31, 0, ZA), (x_rear - pt - 10, 0, ZA))
    tb = tb.cut(pins_f).cut(pins_c)
    P.append(("forearm_tube_carbon", tb, "carbon", "carbon"))
    P += act_parts("J4", J4_P, J4_D, J4_S)
    return P


# ------------------------------------------------------------------------------------------------- link 4: wrist fork
FORK_DISC_PTS = [(32 * math.cos(math.radians(a)), 32 * math.sin(math.radians(a))) for a in (45, 135, 225, 315)]   # (y, z-ZA)


def fork_parts():
    a4, a5 = A["J4"], A["J5"]
    P = []
    ht = 12.0
    x0 = D.J4_FLANGE_X
    disc = cyl(38.0, (x0, 0, ZA), (x0 + ht, 0, ZA))
    disc = hub_plate_holes(disc, a4, J4_P, J4_D, ht, J4_S)
    disc = holes(disc, TAP_DRILL["M5"], FORK_DISC_PTS, (x0 + ht, 0, ZA), X, depth=ht - 1)
    P.append(("fork_hub_disc", disc, "alu", "alu"))
    P.append(("J4_flange_screws_M4", flange_screws(a4, J4_P, J4_D, ht, J4_S), "anod_black", "steel"))
    y_rear5 = D.J5_FLANGE_Y + a5["L"]
    pt = 12.0
    ib = D.IDLER_BEARING
    y_idler_out = -D.FORK_HALF - ib["w"] - 4
    xr0, xr1 = x0 + ht, x0 + ht + 10
    root = rbox((xr0, xr1), (y_idler_out - 10, y_rear5 + pt), (ZA - 30, ZA + 30), 4, edges="|Y")
    arm_m = rbox((xr1 - 1, D.X5 + 40), (y_idler_out - 10, y_idler_out), (ZA - 45, ZA + 45), 8, edges="|Y")
    boss_m = cyl(ib["od"] / 2 + 7, (D.X5, y_idler_out - 1, ZA), (D.X5, -D.FORK_HALF, ZA))
    arm_p = rbox((xr1 - 1, D.X5 + 40), (y_rear5, y_rear5 + pt), (ZA - 45, ZA + 45), 8, edges="|Y")
    fork = fuse(root, arm_m, boss_m, arm_p)
    fork = holes(fork, CLEARANCE["M5"], FORK_DISC_PTS, (xr1, 0, ZA), X, depth=11, counterbore=(SCREW["M5"][1] + 0.6, SCREW["M5"][2] + 0.5))
    fork = bore(fork, a4["bore"] / 2 * 2 + 6, (xr0 - 1, 0, ZA), (xr1 + 1, 0, ZA))                    # cable hole
    fork = body_plate_holes(fork, a5, J5_P, J5_D, pt, J5_S)
    fork = bore(fork, ib["od"] + 0.05, (D.X5, y_idler_out - 2, ZA), (D.X5, -D.FORK_HALF + 0.0, ZA))
    fork = bore(fork, ib["bore"] + 6, (D.X5, y_idler_out - 11, ZA), (D.X5, -D.FORK_HALF + 1, ZA))
    fork = fork.cut(box((xr1 + 12, D.X5 - 24), (y_rear5 - 1, y_rear5 + pt + 1), (ZA - 14, ZA + 14)))   # cable window
    P.append(("wrist_fork", fork, "alu", "alu"))
    P.append(("fork_to_disc_screws_M5", cb_screws("M5", xr1 - xr0, 10, FORK_DISC_PTS, (xr1, 0, ZA), X), "anod_black", "steel"))
    P.append(("J5_body_screws_M4", body_screws(a5, J5_P, J5_D, pt, J5_S), "anod_black", "steel"))
    P += brg_parts(ib, (D.X5, -D.FORK_HALF - ib["w"], ZA), Y, "idler_bearing_6204")
    P.append(("idler_snap_ring", tube(ib["od"] / 2, ib["od"] / 2 - 3.5, (D.X5, -D.FORK_HALF - ib["w"] - 1.5, ZA), (D.X5, -D.FORK_HALF - ib["w"], ZA)), "steel", "steel"))
    P += act_parts("J5", J5_P, J5_D, J5_S)
    return P


# ------------------------------------------------------------------------------------------------- link 5: head
CLAMP_PTS = [(-24.0, -24.0), (-24.0, 12.0)]          # (x-X5, y) clamp screws along z, outside the hub shaft


def head_parts():
    a5 = A["J5"]
    P = []
    ib = D.IDLER_BEARING
    fd = 10.0
    y1 = D.J5_FLANGE_Y
    disc = cyl(33.0, (D.X5, y1, ZA), (D.X5, y1 - fd, ZA))
    shaft = cyl(15.0, (D.X5, y1 - fd + 1, ZA), (D.X5, -D.FORK_HALF + 2, ZA))
    stub = cyl(ib["bore"] / 2, (D.X5, -D.FORK_HALF + 3, ZA), (D.X5, -D.FORK_HALF - ib["w"] - 1, ZA))
    hub = fuse(disc, shaft, stub)
    hub = hub_plate_holes(hub, a5, J5_P, J5_D, fd, J5_S)
    hub = hub.cut(box((D.X5 + 12, D.X5 + 20), (-34, 22), (ZA - 20, ZA + 20)))        # flat (anti-rotation) for the clamp
    P.append(("head_hub_shaft", hub, "alu", "alu"))
    P.append(("J5_flange_screws_M4", flange_screws(a5, J5_P, J5_D, fd, J5_S), "anod_black", "steel"))
    # split clamp block gripping the hub shaft, carrying the boom shell
    cb = rbox((D.X5 - 32, D.X5 + 40), (-36, 24), (ZA - 28, ZA + 28), 6, edges="|Y")
    cb = bore(cb, 30.0, (D.X5, -37, ZA), (D.X5, 25, ZA))
    cb = cb.cut(box((D.X5 - 33, D.X5), (-37, 25), (ZA - 0.5, ZA + 0.5)))            # split
    cb = holes(cb, CLEARANCE["M5"], CLAMP_PTS, (D.X5, 0, ZA + 28), Z, depth=28.5, counterbore=(SCREW["M5"][1] + 0.6, SCREW["M5"][2] + 0.5))
    cb = holes(cb, TAP_DRILL["M5"], CLAMP_PTS, (D.X5, 0, ZA), Z, depth=24)
    cb = holes(cb, TAP_DRILL["M5"], pcd_points(4, 44.0, 45), (D.X5 + 40, 0, ZA), X, depth=14)
    P.append(("head_clamp_block", cb, "alu", "alu"))
    P.append(("clamp_screws_M5", cb_screws("M5", 28.0, 20, CLAMP_PTS, (D.X5, 0, ZA + 28), Z), "anod_black", "steel"))
    # boom shell (printed PA12-CF): motor bore, 4 mm wall with the motor screws, coupling cavity, spigot seat at the end
    sh = D.BOOM_SHELL_OD
    xa = D.X5 + 40
    xb = D.X5 + D.X_REAR_BLOCK
    mot = D.SPINDLE_MOTOR
    xm0 = D.X5 + D.X_MOTOR
    xw = xm0 + mot["L"]                     # motor front face = wall
    shell = cyl(sh / 2, (xa, 0, ZA), (xb, 0, ZA))
    shell = bore(shell, mot["od"] + 1.0, (xa + 4, 0, ZA), (xw, 0, ZA))
    shell = bore(shell, mot["shaft"] + 3, (xw - 1, 0, ZA), (xw + 5, 0, ZA))
    shell = bore(shell, 40.0, (xw + 4, 0, ZA), (xb + 1, 0, ZA))                     # coupling cavity + spigot seat
    shell = shell.cut(box((xm0 + 8, xm0 + mot["L"] - 8), (-sh / 2 - 1, -sh / 2 + 11), (ZA - 14, ZA + 14)))   # service window
    shell = holes(shell, CLEARANCE["M5"], pcd_points(4, 44.0, 45), (xa + 4, 0, ZA), X, depth=6)             # clamp screws (heads inside)
    shell = holes(shell, CLEARANCE["M3"], pcd_points(4, 30.0, 45), (xw + 4, 0, ZA), X, depth=6)             # motor screws (heads inside)
    for ang in (90, 210, 330):
        a = math.radians(ang)
        shell = shell.cut(cyl(TAP_DRILL["M4"] / 2, (xb - 5, 0, ZA), (xb - 5, 32 * math.cos(a), ZA + 32 * math.sin(a))))
    shell = fuse(shell, box((D.X5 + 88, D.X5 + 102), (-7, 7), (ZA + sh / 2 - 2, ZA + sh / 2 + 4)))      # marker post
    P.append(("boom_shell_printed", shell, "pa_cf", "pa_cf"))
    P.append(("shell_to_clamp_screws_M5", screws("M5", 16, pcd_points(4, 44.0, 45), (xa + 4, 0, ZA), X), "anod_black", "steel"))
    # motor (maxon EC-i 40): body, shaft; mounted by its front face to the shell wall
    mbody = cyl(mot["od"] / 2, (xm0, 0, ZA), (xw, 0, ZA))
    mbody = holes(mbody, TAP_DRILL["M3"], pcd_points(4, 30.0, 45), (xw, 0, ZA), X, depth=6)
    P.append(("spindle_motor_maxon_EC-i40", mbody, "motor", "steel"))
    P.append(("spindle_motor_shaft", cyl(mot["shaft"] / 2, (xw, 0, ZA), (xw + 16, 0, ZA)), "steel", "steel"))
    P.append(("motor_screws_M3", screws("M3", 10, pcd_points(4, 30.0, 45), (xw + 4, 0, ZA), X), "anod_black", "steel"))
    # coupling
    cp = D.COUPLING
    xc = D.X5 + D.X_COUPLING
    coup = cyl(cp["od"] / 2, (xc, 0, ZA), (xc + cp["L"], 0, ZA))
    coup = coup.cut(tube(cp["od"] / 2 + 1, cp["od"] / 2 - 2.5, (xc + 9, 0, ZA), (xc + cp["L"] - 9, 0, ZA)))
    coup = bore(coup, mot["shaft"], (xc - 1, 0, ZA), (xc + 13, 0, ZA))
    coup = bore(coup, D.SPINDLE_SHAFT["d"], (xc + 14, 0, ZA), (xc + cp["L"] + 1, 0, ZA))
    P.append(("bellows_coupling", coup, "alu_dark", "alu"))
    # rear bearing block (printed): spigot into the shell, two ceramic bearings, guard seat
    rb = D.REAR_BLOCK
    xr = xb
    rbk = cyl(rb["od"] / 2, (xr, 0, ZA), (xr + rb["L"], 0, ZA))
    rbk = fuse(rbk, cyl(19.9, (xr - 10, 0, ZA), (xr, 0, ZA)))
    brg = D.REAR_BEARING
    xb1, xb2 = xr + 6, xr + rb["L"] - 6 - brg["w"]
    rbk = bore(rbk, 30.0, (xr - 11, 0, ZA), (xb1, 0, ZA))
    rbk = bore(rbk, brg["od"] + 0.05, (xb1, 0, ZA), (xb1 + brg["w"], 0, ZA))
    rbk = bore(rbk, brg["od"] + 0.05, (xb2, 0, ZA), (xb2 + brg["w"], 0, ZA))
    rbk = bore(rbk, brg["od"] - 3, (xb1 + brg["w"], 0, ZA), (xb2, 0, ZA))
    rbk = bore(rbk, D.SPINDLE_SHAFT["d"] + 2, (xb2, 0, ZA), (xr + rb["L"] + 1, 0, ZA))
    rbk = bore(rbk, D.GUARD["od"] + 0.2, (xr + rb["L"] - 4, 0, ZA), (xr + rb["L"] + 1, 0, ZA))
    rbk = rbk.cut(box((xr + 14, xr + rb["L"] - 14), (-rb["od"] / 2 - 1, -rb["od"] / 2 + 8), (ZA - 8, ZA + 8)))   # balance window
    for ang in (90, 210, 330):
        a = math.radians(ang)
        rbk = rbk.cut(cyl(TAP_DRILL["M4"] / 2, (xr - 5, 0, ZA), (xr - 5, 21 * math.cos(a), ZA + 21 * math.sin(a))))
    P.append(("rear_bearing_block_printed", rbk, "pa_cf", "pa_cf"))
    rad = []
    for ang in (90, 210, 330):
        a = math.radians(ang)
        rad.append(along(cq.Solid.makeCylinder(2.0, 14.0, V(0, 0, 0), V(0, 0, -1)).fuse(cq.Solid.makeCylinder(3.5, 4.0, V(0, 0, 0), V(0, 0, 1))),
                         (xr - 5, (sh / 2) * math.cos(a), ZA + (sh / 2) * math.sin(a)), (0, math.cos(a), math.sin(a))))
    P.append(("spigot_radial_screws_M4", fuse(*rad), "anod_black", "steel"))
    for i, xbb in enumerate((xb1, xb2)):
        P += brg_parts(brg, (xbb, 0, ZA), X, f"rear_bearing_{brg['name'].split()[0]}_{i}")
    P.append(("bearing_spacer_sleeve", tube(brg["od"] / 2 - 2, brg["bore"] / 2 + 0.2, (xb1 + brg["w"], 0, ZA), (xb2, 0, ZA)), "alu", "alu"))
    # guard tube (polycarbonate) from the rear block to the nose block
    xn = D.X5 + D.X_NOSE_BLOCK
    g = D.GUARD
    P.append(("guard_tube_polycarbonate", tube(g["od"] / 2, g["id"] / 2, (xr + rb["L"] - 4, 0, ZA), (xn + 4, 0, ZA)), "guard", "pc"))
    # nose block + nose bearing
    nb = D.NOSE_BLOCK
    nbk = cyl(nb["od"] / 2, (xn, 0, ZA), (xn + nb["L"], 0, ZA))
    nbk = bore(nbk, g["od"] + 0.2, (xn - 1, 0, ZA), (xn + 4, 0, ZA))
    nbrg = D.NOSE_BEARING
    nbk = bore(nbk, nbrg["od"] + 0.05, (xn + 5, 0, ZA), (xn + 5 + nbrg["w"], 0, ZA))
    nbk = bore(nbk, nbrg["bore"] + 2, (xn + 4, 0, ZA), (xn + nb["L"] - 2, 0, ZA))
    P.append(("nose_block_printed", nbk, "pa_cf", "pa_cf"))
    P += brg_parts(nbrg, (xn + 5, 0, ZA), X, f"nose_bearing_{nbrg['name'].split()[0]}")
    for xs, od, tag in ((xr + rb["L"] - 2, rb["od"], "rear"), (xn + 2, nb["od"], "nose")):
        pts = []
        for ang in (90, 210, 330):
            a = math.radians(ang)
            pts.append(cyl(1.5, (xs, (g["od"] / 2 - 1) * math.cos(a), ZA + (g["od"] / 2 - 1) * math.sin(a)),
                           (xs, (od / 2) * math.cos(a), ZA + (od / 2) * math.sin(a))))
        P.append((f"guard_set_screws_M3_{tag}", fuse(*pts), "anod_black", "steel"))
    # tool marker block on top of the shell
    P += [(n, s, c, "printed") for n, s, c in marker_block((D.X5 + 95, 0, ZA + sh / 2 + 24), 40.0, 30.0, (20, 21, 22))]
    return P


# ------------------------------------------------------------------------------------------------- link 6: rotor
def rotor_parts():
    """Block magnet potted in a carbon tube, aluminum end caps with the titanium shaft stubs."""
    P = []
    mg = D.MAGNET
    r = D.ROTOR
    x0 = D.X5 + D.X_ROTOR0
    xm = D.X5 + D.X_MAGNET0
    blk = box((xm, xm + mg["a"]), (-mg["b"] / 2, mg["b"] / 2), (ZA - mg["t"] / 2, ZA + mg["t"] / 2))
    blk_n = blk.intersect(box((xm - 1, xm + mg["a"] + 1), (-mg["b"], mg["b"]), (ZA, ZA + mg["t"])))
    P.append(("magnet_block_N_half", blk_n, "magnet_n", "magnet"))
    P.append(("magnet_block_S_half", blk.cut(blk_n), "magnet_s", "magnet"))
    tb = tube(r["tube_od"] / 2, r["tube_id"] / 2, (x0, 0, ZA), (x0 + r["L"], 0, ZA))
    P.append(("rotor_carbon_tube", tb, "carbon", "carbon"))
    # potting (epoxy) between the block and the tube, as one solid
    pot = cyl(r["tube_id"] / 2 - 0.05, (xm, 0, ZA), (xm + mg["a"], 0, ZA)).cut(blk)
    P.append(("rotor_potting_epoxy", pot, "hdpe", "pc"))
    sd = D.SPINDLE_SHAFT
    cap_r = cyl(r["tube_id"] / 2 - 0.05, (x0, 0, ZA), (x0 + r["cap_T"], 0, ZA))
    cap_r = fuse(cap_r, cyl(sd["d"] / 2, (D.X5 + D.X_COUPLING + 14, 0, ZA), (x0 + r["cap_T"] - 1, 0, ZA)))
    cap_r = cap_r.cut(cyl(1.5, (x0 + r["cap_T"] / 2, 0, ZA + 10), (x0 + r["cap_T"] / 2, 0, ZA + r["tube_id"] / 2 + 1)))   # balance screw hole
    P.append(("rotor_rear_cap_and_shaft", cap_r, "alu_dark", "alu"))
    cap_n = cyl(r["tube_id"] / 2 - 0.05, (x0 + r["L"] - r["cap_T"], 0, ZA), (x0 + r["L"], 0, ZA))
    cap_n = fuse(cap_n, cyl(sd["nose_d"] / 2, (x0 + r["L"] - 1, 0, ZA), (D.X5 + D.X_NOSE_BLOCK + 5 + D.NOSE_BEARING["w"] + 1, 0, ZA)))
    cap_n = cap_n.cut(cyl(1.5, (x0 + r["L"] - r["cap_T"] / 2, 0, ZA + 10), (x0 + r["L"] - r["cap_T"] / 2, 0, ZA + r["tube_id"] / 2 + 1)))
    P.append(("rotor_nose_cap_and_stub", cap_n, "alu_dark", "alu"))
    return P


LINKS = [("ARM_BASE", base_parts), ("ARM_L1_TURRET", turret_parts), ("ARM_L2_UPPER", upper_parts),
         ("ARM_L3_FOREARM", forearm_parts), ("ARM_L4_FORK", fork_parts), ("ARM_L5_HEAD", head_parts), ("ARM_L6_ROTOR", rotor_parts)]
LINK_INDEX = {"ARM_BASE": 0, "ARM_L1_TURRET": 1, "ARM_L2_UPPER": 2, "ARM_L3_FOREARM": 3, "ARM_L4_FORK": 4, "ARM_L5_HEAD": 5, "ARM_L6_ROTOR": 6}
