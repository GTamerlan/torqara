"""Detumbler arm v2: every dimension of the buildable prototype, in one place.

Units: mm, degrees, kg. Robot base frame: origin on the top face of the arm's base plate, on the J1 axis.
+Z up, +X toward the target, +Y left when looking from the arm toward the target.

Home pose (all CAD is built here, all joints read zero): upper arm vertical, forearm horizontal toward +X,
magnet boom along +X, magnet spin axis along +X.

Joint chain (five revolute joints + the magnet spindle):
  J1 base yaw      axis +Z  through (0, 0, *)
  J2 shoulder      axis +Y  through (0, *, Z2)
  J3 elbow         axis +Y  through (0, *, Z2 + A2)
  J4 forearm roll  axis +X  through (*, 0, Z2 + A2)
  J5 wrist pitch   axis +Y  through (X5, *, Z2 + A2)
  spindle          axis +X  through (*, 0, Z2 + A2), magnet center at X5 + BOOM

Every joint is a Leadshine HJ2 harmonic integrated actuator (brushless motor + 101:1 harmonic gear + 24-bit
encoder + EtherCAT drive in one sealed unit, with a holding brake on the gravity joints). The links are
roll-wrapped carbon tubes with machined 6061 aluminum hubs. The magnet is a 2 x 2 x 1 in N52 block spun at up to
3000 rpm inside a carbon rotor sleeve; the housing around it is non-conductive so it does not brake itself.
"""
import math

# ------------------------------------------------------------------------------------------------- actuators
# Leadshine HJ2-xx F/H 101 D24 (store.leadshine.com, catalog Oct 2026). NK = no brake, BK = brake.
# torque: rated / peak at the output [N m]. speed: rated at half rated torque / peak [rpm]. mass [kg].
# bolt patterns: (count, thread, pitch-circle diameter). The catalog gives OD, bore and length; the bolt patterns
# below follow the usual harmonic-actuator layout and MUST be checked against the vendor 2D drawing before any
# metal is cut (design2.check_before_machining lists everything of that kind).
HJ2 = {
    "HJ2-52-NK":  dict(od=52.0,  L=56.6, bore=10.0, rated=5.0,  peak=11.0,  v_rated=37, v_peak=50, m=0.326, price=589,
                       out_bolts=(8, "M3", 36.0), body_bolts=(8, "M3", 44.0), brake=False),
    "HJ2-52-BK":  dict(od=52.0,  L=74.1, bore=10.0, rated=6.5,  peak=11.0,  v_rated=40, v_peak=59, m=0.380, price=659,
                       out_bolts=(8, "M3", 36.0), body_bolts=(8, "M3", 44.0), brake=True),
    "HJ2-70-NK":  dict(od=70.0,  L=61.3, bore=12.0, rated=9.6,  peak=34.0,  v_rated=52, v_peak=64, m=0.598, price=659,
                       out_bolts=(8, "M4", 50.0), body_bolts=(8, "M4", 60.0), brake=False),
    "HJ2-70-BK":  dict(od=70.0,  L=82.3, bore=12.0, rated=9.6,  peak=34.0,  v_rated=37, v_peak=49, m=0.800, price=729,
                       out_bolts=(8, "M4", 50.0), body_bolts=(8, "M4", 60.0), brake=True),
    "HJ2-80-NK":  dict(od=80.0,  L=68.2, bore=17.0, rated=30.0, peak=66.0,  v_rated=36, v_peak=48, m=0.958, price=729,
                       out_bolts=(8, "M4", 58.0), body_bolts=(8, "M4", 70.0), brake=False),
    "HJ2-80-BK":  dict(od=80.0,  L=84.2, bore=17.0, rated=30.0, peak=66.0,  v_rated=34, v_peak=41, m=1.170, price=799,
                       out_bolts=(8, "M4", 58.0), body_bolts=(8, "M4", 70.0), brake=True),
    "HJ2-90-NK":  dict(od=90.0,  L=71.2, bore=18.0, rated=50.0, peak=102.0, v_rated=36, v_peak=50, m=1.229, price=799,
                       out_bolts=(8, "M5", 66.0), body_bolts=(8, "M5", 80.0), brake=False),
    "HJ2-90-BK":  dict(od=90.0,  L=88.3, bore=18.0, rated=50.0, peak=102.0, v_rated=30, v_peak=40, m=1.600, price=859,
                       out_bolts=(8, "M5", 66.0), body_bolts=(8, "M5", 80.0), brake=True),
    "HJ2-110-NK": dict(od=110.0, L=80.2, bore=25.0, rated=84.0, peak=194.0, v_rated=31, v_peak=40, m=1.981, price=859,
                       out_bolts=(12, "M5", 84.0), body_bolts=(12, "M5", 98.0), brake=False),
    "HJ2-110-BK": dict(od=110.0, L=97.6, bore=25.0, rated=84.0, peak=194.0, v_rated=13, v_peak=36, m=2.600, price=929,
                       out_bolts=(12, "M5", 84.0), body_bolts=(12, "M5", 98.0), brake=True),
}
RATIO = 101.0
# Harmonic-gear torsional stiffness at the output, by size (Harmonic Drive CSF/CSG catalog values for the same
# frame sizes; used for the deflection and natural-frequency estimates) [N m / rad]
K_TORSION = {52: 4.7e3, 70: 1.6e4, 80: 2.5e4, 90: 3.4e4, 110: 6.1e4}

# Which actuator drives which joint. Brakes on the joints that gravity can pull down.
JOINT_ACTUATOR = {"J1": "HJ2-90-NK", "J2": "HJ2-110-BK", "J3": "HJ2-90-BK", "J4": "HJ2-70-NK", "J5": "HJ2-70-BK"}
JOINT_LIMITS = {"J1": (-170, 170), "J2": (-80, 80), "J3": (-150, 150), "J4": (-180, 180), "J5": (-120, 120)}
JOINT_AXIS = {"J1": (0, 0, 1), "J2": (0, 1, 0), "J3": (0, 1, 0), "J4": (1, 0, 0), "J5": (0, 1, 0)}
# Controller limits (the trajectory shaper never asks for more; the actuators can do ~2x)
JOINT_VMAX_DPS = {"J1": 60, "J2": 45, "J3": 60, "J4": 90, "J5": 90}
JOINT_AMAX_DPS2 = {"J1": 90, "J2": 60, "J3": 90, "J4": 180, "J5": 180}

# ------------------------------------------------------------------------------------------------- geometry
Z1F = 110.0            # J1 output flange face height above the base plate (base housing holds the actuator body)
Z2 = 200.0             # shoulder (J2) axis height
A2 = 500.0             # upper arm: J2 axis -> J3 axis
A3 = 400.0             # forearm: J3 axis -> J5 axis (J4 is the roll about the forearm itself)
X5 = A3                # J5 axis x at home
Z3 = Z2 + A2           # elbow axis height = forearm height

# lateral layout (the cobot "offset" layout: J2 drives the upper arm from one side, J3 brings the forearm back
# onto the y = 0 plane so the wrist and magnet are centered)
J2_FLANGE_Y = 20.0                  # J2 output flange face (actuator body toward -y)
UPPER_HUB_T = 12.0                  # upper-arm hub plate thickness
UPPER_TUBE = dict(od=60.0, wall=2.0)
UPPER_Y = J2_FLANGE_Y + UPPER_HUB_T + UPPER_TUBE["od"] / 2 + 4.0    # upper-arm tube centerline y  (= 66)
FORE_TUBE = dict(od=50.0, wall=2.0)
FORE_Y = 0.0                        # forearm centerline
FORE_HUB_T = 12.0
J3_FLANGE_Y = FORE_Y + FORE_TUBE["od"] / 2 + FORE_HUB_T          # J3 output flange face y (= 37), body toward +y
# wrist: J4 roll actuator sits in the end of the forearm tube, output toward +x; the wrist fork carries J5 on
# the +y side and an idler bearing on the -y side; the head hub sits between the fork arms.
J4_FLANGE_X = X5 - 60.0             # J4 output flange face
FORK_HALF = 40.0                    # fork arm inner faces at y = +-FORK_HALF
FORK_ARM_T = 10.0
J5_FLANGE_Y = FORK_HALF             # J5 output flange face (actuator body toward +y, outside the fork)
IDLER_BEARING = dict(od=47.0, bore=20.0, w=14.0)       # 6204-size thin section on the -y fork arm (ceramic hybrid)
HEAD_HUB_W = 2 * FORK_HALF - 4.0    # head hub width between the fork arms (2 mm clearance each side)

# ------------------------------------------------------------------------------------------------- magnet head
# The braking force falls as (a/(a+g))^6 with the gap g, where a grows with the magnet's size, and the planner keeps a
# working gap of 12-20 mm. At such gaps a large magnet wins by a wide margin (a 2 x 2 x 1 in block gives ~30x the
# force of a 1 in rod), so the rotor is the biggest standard N52 block the wrist can carry, spun about one of its
# 2 in edges so its dipole (through the 1 in thickness) sweeps the hull. The block is potted inside a thin carbon
# tube whose bore matches the block's 57 mm corner envelope; aluminum end caps carry the shafts. A thin
# polycarbonate guard tube (stationary) surrounds the rotor; the housing around it is non-conductive so the field
# only brakes the hull.
MAGNET = dict(name="K&J BY0Y0X0-N52 block 2 x 2 x 1 in", a=50.8, b=50.8, t=25.4, m=0.574, Br=1.48, surface_T=0.49, price=159.54,
              r_eq=25.4)                        # equivalent radius for the force model (half the face width)
SPIN_RPM_MAX = 3000.0
ROTOR = dict(tube_od=61.0, tube_id=58.0, L=68.0, cap_T=8.0)     # carbon tube around the block (corner radius 28.4), aluminum end caps
ROTOR_OD = ROTOR["tube_od"]
SPINDLE_SHAFT = dict(d=10.0, nose_d=8.0, material="titanium grade 5 (non-magnetic)")
REAR_BEARING = dict(od=26.0, bore=10.0, w=8.0, name="6000 full ceramic ZrO2")
NOSE_BEARING = dict(od=22.0, bore=8.0, w=7.0, name="608 full ceramic ZrO2")
GUARD = dict(id=63.0, od=66.0, material="polycarbonate tube")
HEAD_RADIUS = GUARD["od"] / 2                   # collision radius around the rotor axis [mm] (33)
REAR_BLOCK = dict(od=78.0, L=46.0)              # printed PA12-CF block: two rear bearings, coupling cavity
NOSE_BLOCK = dict(od=70.0, L=18.0)              # printed PA12-CF nose block: one nose bearing
BOOM_SHELL_OD = 60.0                            # printed boom shell from the head hub to the rear block (holds the motor)
SPINDLE_MOTOR = dict(name="maxon EC-i 40 (449470), 36 V, 70 W, hall sensors", od=40.0, L=56.0, m=0.240, shaft=6.0,
                     n0_rpm=10700, torque_nom_mNm=84.8, price=290.0)
COUPLING = dict(od=25.0, L=28.0, name="zero-backlash bellows coupling 6 x 10 mm")
# layout along the boom (x from the J5 axis): hub face, motor, coupling, rear block, rotor, nose block
HEAD_HUB_LEN = 35.0                             # J5 axis -> hub +x face
X_MOTOR = HEAD_HUB_LEN + 16.0                   # motor rear face (from J5 axis)
X_COUPLING = X_MOTOR + SPINDLE_MOTOR["L"] + 4.0
X_REAR_BLOCK = X_COUPLING + COUPLING["L"] + 3.0
X_ROTOR0 = X_REAR_BLOCK + REAR_BLOCK["L"] + 5.0           # rotor rear cap starts
X_MAGNET0 = X_ROTOR0 + (ROTOR["L"] - MAGNET["a"]) / 2     # block starts (centered between the end caps)
BOOM = X_ROTOR0 + ROTOR["L"] / 2                          # J5 axis -> magnet center (~ 257)
X_NOSE_BLOCK = X_ROTOR0 + ROTOR["L"] + 5.0
HEAD_LEN = X_NOSE_BLOCK + NOSE_BLOCK["L"]                 # J5 axis -> nose tip
MOTOR_STANDOFF = BOOM - (X_MOTOR + SPINDLE_MOTOR["L"])    # magnet center -> motor front face
SPINDLE_DRIVER = dict(name="ODrive S1 (48 V, FOC, hall + encoder)", price=149.0)
SWEEP_MAX_MPS = 4.0                             # field sweep speed at the magnet surface used by the brain (~1500 rpm)
MAGNET_CENTER = (X5 + BOOM, 0.0, Z3)
REACH_MAX = A2 + A3 + BOOM   # fully stretched, from the J1 axis [mm]

# ------------------------------------------------------------------------------------------------- target + gimbal
# 200 x 160 x 140 mm box of 1.5 mm 1100-H14 aluminum: the hull that gets braked. It hangs in a three-axis gimbal
# that turns freely and without limits about all three axes:
#   roll  - the box turns on two pins (on its +-x faces) in bearings on the pitch ring
#   pitch - the ring turns on two pins in the arms of the yoke
#   yaw   - the yoke turns on a vertical shaft in the stand
# Everything that moves with the target is non-conductive (G10 ring, printed yoke, ceramic bearings), so the
# magnet only brakes the aluminum hull.
TARGET = dict(x=200.0, y=160.0, z=140.0, wall=1.5, material="1100-H14 aluminum", sigma=3.4e7, rho=2710.0)
TARGET_CENTER = (X5 + HEAD_LEN + 260.0, 0.0, Z3 - 150.0)      # nose at home stays 50 mm outside the ring sweep sphere                # where the target hangs, robot frame
ROLL_PIN = dict(d=8.0, hub_od=40.0, hub_t=10.0)                  # 316 pins on the +-x faces
GIMBAL_BEARING = dict(od=22.0, bore=8.0, w=7.0, name="608 full ceramic ZrO2")
PITCH_RING = dict(id=320.0, od=380.0, t=12.0, material="G10/FR4")  # horizontal ring (at home) holding the roll pins; ID clears the hull diagonal (146 mm)
YOKE = dict(arm_t=14.0, arm_w=40.0, drop=230.0, material="printed PA12-CF (or PA6-GF)")   # U-yoke below the ring (ring sweeps r = 190)
YAW_SHAFT = dict(d=17.0, bearing=dict(od=30.0, bore=17.0, w=7.0, name="6903 full ceramic ZrO2"))
STAND = dict(post_od=60.0, post_wall=3.0, base=(500.0, 500.0, 15.0), material="6061 aluminum (stationary, far from the magnet)")
STAND_TOP_BELOW_CENTER = PITCH_RING["od"] / 2 + YOKE["arm_t"] + 60.0    # yaw bearing housing top below the target center

# ------------------------------------------------------------------------------------------------- base + controller
BASE_PLATE = dict(x=320.0, y=320.0, t=20.0, material="6061-T6, 6 x M10 to the pedestal")
PEDESTAL = dict(od=180.0, wall=5.0, h=700.0, foot=(600.0, 600.0, 15.0))   # floor pedestal, steel or aluminum
CONTROLLER = dict(
    master="Linux PC, EtherCAT master (IgH / SOEM), 1 kHz cycle",
    psu="Mean Well RSP-1500-48 (48 V, 1500 W)", psu_price=370.0,
    estop="Pilz PNOZ s3 safety relay + 48 V contactor (STO chain to every actuator)", estop_price=260.0,
)

# ------------------------------------------------------------------------------------------------- materials
DENSITY = {"alu": 2700.0, "steel": 7850.0, "ti": 4430.0, "carbon": 1600.0, "g10": 1850.0, "printed": 1150.0,
           "magnet": 7500.0, "pc": 1200.0, "ceramic": 6000.0, "copper": 8900.0, "pa_cf": 1200.0, "rubber": 1100.0}
E_MOD = {"carbon_tube": 70e9, "alu": 69e9, "g10": 24e9}     # [Pa] roll-wrapped 3K carbon tube, axial


def tube_props(od, wall):
    """Area [m^2] and second moment [m^4] of a round tube given in mm."""
    ro, ri = od / 2e3, (od / 2 - wall) / 1e3
    return math.pi * (ro ** 2 - ri ** 2), math.pi / 4 * (ro ** 4 - ri ** 4)


CHECK_BEFORE_MACHINING = [
    "HJ2 bolt patterns (count, thread, PCD) on the output flange and body: taken from the usual layout, not from "
    "the vendor drawing. Download the 2D drawing / STEP for each size from store.leadshine.com and update HJ2[...] "
    "before cutting the hubs.",
    "HJ2 connector position and cable exit (the hubs leave a 30 mm cable window; move it if the connector is elsewhere).",
    "Magnet block: confirm 50.8 x 50.8 x 25.4 mm nominal, measure the actual block and pot it with 0.3 mm epoxy clearance.",
    "Carbon tube actual OD/ID: roll-wrapped tubes are +-0.2 mm; ream the hub bores to the delivered tube.",
    "Rotor balance: balance the finished rotor to ISO 1940 G2.5 at 3000 rpm before fitting the guard.",
]
