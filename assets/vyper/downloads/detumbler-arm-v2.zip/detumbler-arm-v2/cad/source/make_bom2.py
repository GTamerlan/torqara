"""Parts list for arm v2 (xlsx + csv): purchased parts with October 2026 list prices where found, machined and
printed parts taken from the CAD with their mass, fasteners counted from the CAD part names."""
import json
import os
import re
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import design2 as D  # noqa: E402

OUT = os.path.join(HERE, "out")
A = {j: D.HJ2[D.JOINT_ACTUATOR[j]] for j in D.JOINT_ACTUATOR}

# (category, item, spec, qty, unit price USD, source / note, price status)  status: listed | quote | estimate
P = []
for j in ("J1", "J2", "J3", "J4", "J5"):
    a = A[j]
    P.append(("Actuators", f"{j} actuator Leadshine {D.JOINT_ACTUATOR[j].replace('-', '')}F101D24-{'BK' if a['brake'] else 'NK'}-EC",
              f"{a['od']:.0f} mm harmonic integrated actuator, {a['rated']}/{a['peak']} N m, 101:1, 24-bit encoder, EtherCAT{', brake' if a['brake'] else ''}, {a['m']} kg",
              1, a["price"], "store.leadshine.com", "listed"))
P += [
    ("Spindle", "maxon EC-i 40 brushless motor, 70 W, 36 V, hall sensors (449470)", "40 mm, 240 g, 10700 rpm no load, 85 mN m nominal", 1, 290.0, "maxongroup.com (EUR 268 ex VAT)", "listed"),
    ("Spindle", "ODrive S1 motor controller", "48 V FOC drive for the spindle, hall + encoder input", 1, 149.0, "odriverobotics.com", "listed"),
    ("Spindle", "Bellows coupling 6 x 10 mm, zero backlash", "aluminum, 25 mm OD, 28 mm long", 1, 45.0, "Ruland / Misumi", "estimate"),
    ("Spindle", "Titanium grade 5 rod Ø10 x 150 mm and Ø8 x 60 mm", "rotor shaft stubs (non-magnetic)", 1, 38.0, "McMaster-Carr", "estimate"),
    ("Spindle", "Full-ceramic bearing 6000 ZrO2 (10 x 26 x 8)", "rear spindle bearings", 2, 24.0, "Boca Bearings", "estimate"),
    ("Spindle", "Full-ceramic bearing 608 ZrO2 (8 x 22 x 7)", "nose spindle bearing", 1, 16.0, "Boca Bearings", "estimate"),
    ("Spindle", "Carbon tube 61 x 58 x 100 mm (rotor), cut to 68", "roll-wrapped 3K", 1, 22.0, "Rock West Composites", "estimate"),
    ("Spindle", "Polycarbonate tube 66 x 63 x 300 mm (guard), cut to length", "clear", 1, 18.0, "McMaster-Carr", "estimate"),
    ("Magnet", D.MAGNET["name"], f"{D.MAGNET['a']} x {D.MAGNET['b']} x {D.MAGNET['t']} mm, {D.MAGNET['m']} kg, Br 1.48 T, surface 0.49 T", 1, D.MAGNET["price"], "kjmagnetics.com BY0Y0X0-N52", "listed"),
    ("Magnet", "Epoxy potting (3M DP420 or West System), 200 g", "rotor potting + tube bonding", 1, 35.0, "", "estimate"),
    ("Arm structure", "Carbon tube 60 x 56 x 1000 mm (upper arm), cut to 445", "roll-wrapped 3K twill", 1, 95.0, "Rock West Composites", "estimate"),
    ("Arm structure", "Carbon tube 50 x 46 x 500 mm (forearm), cut to 227", "roll-wrapped 3K twill", 1, 55.0, "Rock West Composites", "estimate"),
    ("Arm structure", "Ceramic-hybrid bearing 6204 (20 x 47 x 14), wrist idler", "steel races, Si3N4 balls", 1, 42.0, "Boca Bearings", "estimate"),
    ("Arm structure", "6061-T6 aluminum stock for machined parts", "plate 20/15/12/10 mm, round bar 110/100/70 mm (see Machined sheet)", 1, 420.0, "Midwest Steel & Aluminum", "estimate"),
    ("Arm structure", "CNC machining of the aluminum parts (11 parts)", "3-axis, turning for hubs; see Machined sheet", 1, 2600.0, "quote: Xometry / local shop", "quote"),
    ("Arm structure", "Base pedestal: steel tube 180 x 5 x 700 mm, 600 x 600 x 15 mm foot plate, top ring, 4 leveling feet", "welded, powder coated", 1, 480.0, "local fabrication", "estimate"),
    ("Target + gimbal", "1100-H14 aluminum sheet 1.5 mm, 500 x 1000 mm", "hull, bent + riveted/epoxied box 200 x 160 x 140", 1, 60.0, "", "estimate"),
    ("Target + gimbal", "G10/FR4 sheet 12 mm, 400 x 400 mm (pitch ring, waterjet)", "ID 320 / OD 380 ring with 4 notches", 1, 140.0, "waterjet quote", "quote"),
    ("Target + gimbal", "Full-ceramic bearing 608 ZrO2 (8 x 22 x 7), gimbal", "roll + pitch bearings", 4, 16.0, "Boca Bearings", "estimate"),
    ("Target + gimbal", "Full-ceramic bearing 6903 ZrO2 (17 x 30 x 7), yaw", "yaw shaft bearings", 2, 32.0, "Boca Bearings", "estimate"),
    ("Target + gimbal", "316 stainless rod Ø8 x 300 mm and Ø17 x 200 mm", "gimbal pins and yaw shaft", 1, 30.0, "McMaster-Carr", "estimate"),
    ("Target + gimbal", "Brass plate 4 mm, 120 x 80 mm (ballast), + trim weights", "hull inertia ballast and balancing", 2, 18.0, "", "estimate"),
    ("Target + gimbal", "Stand: 6061 tube 60 x 3 x 1000 mm, 500 x 500 x 15 mm base, bearing housing stock", "", 1, 190.0, "", "estimate"),
    ("Vision", "Arducam OV9281 1 MP global-shutter USB camera + 6 mm M12 lens", "mono, 120 fps", 2, 69.0, "arducam.com", "listed"),
    ("Vision", "LED panel light 60 x 40 mm, 5600 K, dimmable", "flicker-free", 2, 45.0, "", "estimate"),
    ("Vision", "4040 aluminum extrusion 1.5 m + 0.8 m, brackets, base plate", "camera mast", 1, 110.0, "8020 / Misumi", "estimate"),
    ("Vision", "ChArUco calibration board (printed on 3 mm dibond), ArUco marker prints", "", 1, 40.0, "", "estimate"),
    ("Controller", "Fanless industrial PC (Intel N100 class) with Linux + EtherCAT master (IgH/SOEM)", "", 1, 420.0, "", "estimate"),
    ("Controller", D.CONTROLLER["psu"], "48 V, 1500 W", 1, D.CONTROLLER["psu_price"], "Mean Well distributor", "listed"),
    ("Controller", "Pilz PNOZ s3 safety relay + 48 V DC contactor + 2 E-stop buttons", "STO chain", 1, D.CONTROLLER["estop_price"], "", "estimate"),
    ("Controller", "Steel enclosure 500 x 400 x 210 mm, DIN rails, breaker, terminals, glands", "", 1, 260.0, "", "estimate"),
    ("Controller", "Cabling: EtherCAT M8 cables (6), power cables, through-bore harness, drag chain", "", 1, 240.0, "", "estimate"),
    ("Printed parts", "PA12-CF filament / SLS print service for the printed parts", "see Printed sheet", 1, 320.0, "Craftcloud / JLC3DP quote", "quote"),
    ("Fasteners", "ISO 4762 socket head cap screws, set screws, nyloc nuts, heat-set inserts (A2 stainless)", "see Fasteners sheet", 1, 90.0, "McMaster-Carr", "estimate"),
    ("Tools / test", "Rotor balancing service (ISO G2.5 at 3000 rpm)", "", 1, 150.0, "", "estimate"),
    ("Tools / test", "Hall-effect gaussmeter (for field verification)", "", 1, 180.0, "", "estimate"),
]


def machined_and_printed():
    import cad2_rig
    from cad2_lib import mass_props
    comps = cad2_rig.components()
    mach, printed = [], []
    for cname, parts in comps.items():
        for pname, shape, _c, mat in parts:
            if mat == "alu" and not any(w in pname for w in ("screw", "pin", "bearing", "spacer", "cap_and", "coupling", "snap", "hull", "4040",
                                                              "led_panel", "cam_", "actuator", "motor", "foot")) and shape.Volume() > 3000:
                m, _, _ = mass_props(shape, D.DENSITY["alu"])
                bb = shape.BoundingBox()
                mach.append((cname, pname, round(m, 3), f"{bb.xlen:.0f} x {bb.ylen:.0f} x {bb.zlen:.0f}"))
            if mat in ("pa_cf", "printed") and shape.Volume() > 500 and "marker" not in pname:
                m, _, _ = mass_props(shape, D.DENSITY[mat])
                bb = shape.BoundingBox()
                printed.append((cname, pname, round(m, 3), f"{bb.xlen:.0f} x {bb.ylen:.0f} x {bb.zlen:.0f}"))
    fast = Counter()
    for cname, parts in comps.items():
        for pname, shape, _c, mat in parts:
            m = re.search(r"(M\d+)", pname)
            if m and ("screw" in pname or "pin" in pname or "nut" in pname):
                # count solids in the fused set
                n = len(shape.Solids()) if hasattr(shape, "Solids") else 1
                fast[(m.group(1), "nut" if "nut" in pname else ("set screw" if "set_screw" in pname else ("cross pin" if "pin" in pname else "cap screw")))] += n
    return mach, printed, fast


def main():
    from openpyxl import Workbook
    from openpyxl.styles import Font
    mach, printed, fast = machined_and_printed()
    wb = Workbook()
    ws = wb.active
    ws.title = "Purchased"
    ws.append(["Category", "Item", "Specification", "Qty", "Unit price USD", "Line total USD", "Source / note", "Price status"])
    total = 0.0
    listed = 0.0
    for cat, item, spec, qty, price, src, st in P:
        line = qty * price
        total += line
        if st == "listed":
            listed += line
        ws.append([cat, item, spec, qty, price, round(line, 2), src, st])
    ws.append([])
    ws.append(["", "Parts subtotal", "", "", "", round(total, 2)])
    ws.append(["", "Contingency 15%", "", "", "", round(0.15 * total, 2)])
    ws.append(["", "Budget", "", "", "", round(1.15 * total, 2)])
    for c in ws[1]:
        c.font = Font(bold=True)
    ws2 = wb.create_sheet("Machined (6061-T6)")
    ws2.append(["Component", "Part", "Mass kg", "Envelope mm", "Notes"])
    for r in mach:
        ws2.append(list(r) + ["holes and counterbores per the STEP; bolt patterns to be confirmed against the actuator drawings"])
    ws3 = wb.create_sheet("Printed (PA12-CF)")
    ws3.append(["Component", "Part", "Mass kg", "Envelope mm", "Notes"])
    for r in printed:
        ws3.append(list(r) + ["SLS PA12-CF or FDM PA6-CF at 100% infill; non-conductive by design"])
    ws4 = wb.create_sheet("Fasteners")
    ws4.append(["Thread", "Type", "Count in CAD", "Notes"])
    for (thr, typ), n in sorted(fast.items()):
        ws4.append([thr, typ, n, "A2 stainless (non-magnetic); lengths per the STEP"])
    ws5 = wb.create_sheet("Summary")
    ws5.append(["Purchased parts subtotal (USD)", round(total, 2)])
    ws5.append(["of which list-priced today", round(listed, 2)])
    ws5.append(["Budget with 15% contingency (USD)", round(1.15 * total, 2)])
    ws5.append(["Drive train (5 actuators + spindle + magnet)", round(sum(A[j]["price"] for j in A) + 290 + 149 + D.MAGNET["price"], 2)])
    ws5.append(["Machined parts", len(mach)])
    ws5.append(["Printed parts", len(printed)])
    ws5.append(["Fasteners", sum(fast.values())])
    wb.save(f"{OUT}/Detumbler_Arm_v2_Parts_List.xlsx")
    import csv
    with open(f"{OUT}/Detumbler_Arm_v2_Parts_List.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Category", "Item", "Specification", "Qty", "Unit price USD", "Line total USD", "Source / note", "Price status"])
        for cat, item, spec, qty, price, src, st in P:
            w.writerow([cat, item, spec, qty, price, round(qty * price, 2), src, st])
    summary = {"parts_subtotal_usd": round(total), "budget_usd": round(1.15 * total), "listed_usd": round(listed), "n_lines": len(P),
               "n_machined": len(mach), "n_printed": len(printed), "n_fasteners": int(sum(fast.values())),
               "drive_train_usd": round(sum(A[j]["price"] for j in A) + 290 + 149 + D.MAGNET["price"])}
    json.dump(summary, open(f"{OUT}/bom_summary.json", "w"), indent=1)
    print(summary)
    print("machined:", [(r[1], r[2]) for r in mach])
    print("printed:", [(r[1], r[2]) for r in printed])


if __name__ == "__main__":
    main()
