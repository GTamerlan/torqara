"""Loads, actuator margins, stiffness and spindle checks for arm v2.

Works from a mass model: a list of bodies, each with the link it belongs to (0 = base, 1..5 = after J1..J5,
6 = spinning rotor), mass [kg], center [mm, robot frame, home pose]. `estimate_mass_model()` builds it from
design2.py; cad2_rig.py writes the real one from the CAD solids (out/mass_model.json) and this script prefers
that file when it exists.

    python sizing.py            -> out/loads_report.md, out/loads.json
"""
import json
import math
import os
import sys
import itertools
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import design2 as D

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
G = 9.81
JOINTS = ["J1", "J2", "J3", "J4", "J5"]


# ------------------------------------------------------------------------------------------------ kinematics
def joint_frames_home():
    """Axis direction and a point on the axis for each joint, at home [mm]."""
    return {
        "J1": (np.array([0, 0, 1.0]), np.array([0, 0, 0.0])),
        "J2": (np.array([0, 1, 0.0]), np.array([0, 0, D.Z2])),
        "J3": (np.array([0, 1, 0.0]), np.array([0, 0, D.Z3])),
        "J4": (np.array([1, 0, 0.0]), np.array([0, 0, D.Z3])),
        "J5": (np.array([0, 1, 0.0]), np.array([D.X5, 0, D.Z3])),
    }


def rot(axis, ang):
    axis = np.asarray(axis, float) / np.linalg.norm(axis)
    a = math.radians(ang)
    K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
    return np.eye(3) + math.sin(a) * K + (1 - math.cos(a)) * K @ K


def pose_bodies(bodies, q):
    """Move each body's center and the joint axes to configuration q (deg). Returns centers [mm] and the
    (axis, point) of every joint in that configuration."""
    frames = joint_frames_home()
    # transform of link k = product of joint rotations 1..k applied in order from the base
    T = [(np.eye(3), np.zeros(3))]        # link 0
    for k, j in enumerate(JOINTS, start=1):
        R_prev, t_prev = T[-1]
        ax_h, p_h = frames[j]
        ax = R_prev @ ax_h
        p = R_prev @ p_h + t_prev
        Rj = rot(ax, q[k - 1])
        R = Rj @ R_prev
        t = Rj @ (t_prev - p) + p
        T.append((R, t))
    centers = []
    for b in bodies:
        R, t = T[min(b["link"], 5)]
        centers.append(R @ np.asarray(b["com"], float) + t)
    axes = {}
    for k, j in enumerate(JOINTS, start=1):
        R_prev, t_prev = T[k - 1]
        ax_h, p_h = frames[j]
        axes[j] = (R_prev @ ax_h, R_prev @ p_h + t_prev)
    return np.array(centers), axes


def gravity_torques(bodies, q):
    centers, axes = pose_bodies(bodies, q)
    tau = {}
    for k, j in enumerate(JOINTS, start=1):
        ax, p = axes[j]
        t = 0.0
        for b, c in zip(bodies, centers):
            if b["link"] >= k:
                r = (c - p) / 1e3
                f = np.array([0, 0, -b["m"] * G])
                t += float(np.dot(np.cross(r, f), ax))
        tau[j] = t
    return tau


def inertia_about(bodies, q, j):
    """Point-mass inertia of everything after joint j about its axis [kg m^2]."""
    centers, axes = pose_bodies(bodies, q)
    ax, p = axes[j]
    k = JOINTS.index(j) + 1
    I = 0.0
    for b, c in zip(bodies, centers):
        if b["link"] >= k:
            r = (c - p) / 1e3
            d = r - np.dot(r, ax) * ax
            I += b["m"] * float(np.dot(d, d)) + b.get("I_self", 0.0)
    return I


# ------------------------------------------------------------------------------------------------ mass model
def estimate_mass_model():
    """Analytic estimate from design2 (replaced by the CAD mass properties once cad2_rig.py has run)."""
    B = []
    rho = D.DENSITY

    def add(name, link, m, com, I_self=0.0):
        B.append(dict(name=name, link=link, m=float(m), com=[float(c) for c in com], I_self=float(I_self)))

    def act(j):
        return D.HJ2[D.JOINT_ACTUATOR[j]]

    # link 1: turret on J1 (carries J2 actuator)
    add("J1 actuator (fixed body)", 0, act("J1")["m"], (0, 0, D.Z1F - act("J1")["L"] / 2))
    add("turret hub (alu)", 1, 1.1, (0, -20, (D.Z1F + D.Z2) / 2))
    add("J2 actuator", 1, act("J2")["m"], (0, D.J2_FLANGE_Y - act("J2")["L"] / 2, D.Z2))
    # link 2: upper arm
    A_up, _ = D.tube_props(D.UPPER_TUBE["od"], D.UPPER_TUBE["wall"])
    Lu = D.A2 - 140
    add("upper hub (alu)", 2, 0.55, (0, D.UPPER_Y - 10, D.Z2 + 20))
    add("upper arm tube (carbon)", 2, A_up * Lu / 1e3 * rho["carbon"], (0, D.UPPER_Y, D.Z2 + 70 + Lu / 2))
    add("elbow housing (alu)", 2, 0.65, (0, D.UPPER_Y + 10, D.Z3 - 10))
    add("J3 actuator", 2, act("J3")["m"], (0, D.J3_FLANGE_Y + act("J3")["L"] / 2, D.Z3))
    # link 3: forearm (to J4)
    A_f, _ = D.tube_props(D.FORE_TUBE["od"], D.FORE_TUBE["wall"])
    Lf = D.J4_FLANGE_X - act("J4")["L"] - 70
    add("forearm hub (alu)", 3, 0.40, (35, 0, D.Z3))
    add("forearm tube (carbon)", 3, A_f * Lf / 1e3 * rho["carbon"], (70 + Lf / 2, 0, D.Z3))
    add("J4 actuator", 3, act("J4")["m"], (D.J4_FLANGE_X - act("J4")["L"] / 2, 0, D.Z3))
    add("J4 cradle (alu)", 3, 0.25, (D.J4_FLANGE_X - 30, 0, D.Z3))
    # link 4: wrist fork (to J5)
    add("wrist fork (alu)", 4, 0.70, (D.X5 - 15, 0, D.Z3))
    add("J5 actuator", 4, act("J5")["m"], (D.X5, D.J5_FLANGE_Y + act("J5")["L"] / 2, D.Z3))
    add("idler bearing + cap", 4, 0.12, (D.X5, -D.FORK_HALF - 8, D.Z3))
    # link 5: head
    xm = D.MAGNET_CENTER[0]
    add("head hub (alu)", 5, 0.40, (D.X5 + 18, 0, D.Z3))
    add("boom shell + blocks (printed PA12-CF)", 5, 0.30, (D.X5 + D.X_REAR_BLOCK, 0, D.Z3))
    add("spindle motor", 5, D.SPINDLE_MOTOR["m"], (D.X5 + D.X_MOTOR + D.SPINDLE_MOTOR["L"] / 2, 0, D.Z3))
    add("coupling + shaft (Ti) + bearings", 5, 0.09, (D.X5 + D.X_REAR_BLOCK, 0, D.Z3))
    add("guard (PC)", 5, 0.03, (xm, 0, D.Z3))
    add("tool marker block", 5, 0.05, (D.X5 + 90, 0, D.Z3 + 45))
    # link 6: rotor (spins): block magnet potted in a carbon tube, two aluminum end caps
    mag = D.MAGNET
    r = D.ROTOR
    I_mag = mag["m"] * ((mag["b"] / 1e3) ** 2 + (mag["t"] / 1e3) ** 2) / 12       # about the spin axis (along a)
    m_tube = math.pi * ((r["tube_od"] / 2) ** 2 - (r["tube_id"] / 2) ** 2) * r["L"] * 1e-9 * rho["carbon"]
    m_caps = 2 * math.pi * (r["tube_id"] / 2) ** 2 * r["cap_T"] * 1e-9 * rho["alu"]
    m_pot = (math.pi * (r["tube_id"] / 2) ** 2 - mag["b"] * mag["t"]) * mag["a"] * 1e-9 * rho["pc"]
    add("magnet block", 6, mag["m"], (xm, 0, D.Z3), I_mag)
    add("rotor tube (carbon)", 6, m_tube, (xm, 0, D.Z3), m_tube * (r["tube_od"] / 2e3) ** 2)
    add("rotor end caps (alu)", 6, m_caps, (xm, 0, D.Z3), 0.5 * m_caps * (r["tube_id"] / 2e3) ** 2)
    add("rotor potting", 6, m_pot, (xm, 0, D.Z3), 0.5 * m_pot * (r["tube_id"] / 2e3) ** 2)
    return B


def load_mass_model():
    f = os.path.join(OUT, "mass_model.json")
    if os.path.exists(f):
        return [b for b in json.load(open(f)) if b["link"] <= 6], "CAD mass properties (out/mass_model.json)"
    return estimate_mass_model(), "analytic estimate from design2.py"


# ------------------------------------------------------------------------------------------------ analysis
def worst_static(bodies):
    """Sweep the joint space on a grid; return the largest |gravity torque| per joint and where it happens."""
    grid = {"J1": [0], "J2": np.linspace(D.JOINT_LIMITS["J2"][0], D.JOINT_LIMITS["J2"][1], 20), "J3": np.linspace(-150, 150, 31),
            "J4": [0, 90, 180], "J5": np.linspace(-120, 120, 13)}
    worst = {j: (0.0, None) for j in JOINTS}
    for q in itertools.product(*[grid[j] for j in JOINTS]):
        tau = gravity_torques(bodies, q)
        for j in JOINTS:
            if abs(tau[j]) > worst[j][0]:
                worst[j] = (abs(tau[j]), [float(v) for v in q])
    return worst


def analyse():
    bodies, source = load_mass_model()
    res = {"mass_model_source": source}
    m_links = {}
    for b in bodies:
        m_links[b["link"]] = m_links.get(b["link"], 0.0) + b["m"]
    res["mass_per_link_kg"] = {str(k): round(v, 3) for k, v in sorted(m_links.items())}
    res["moving_mass_kg"] = round(sum(v for k, v in m_links.items() if k >= 1), 3)
    res["head_mass_kg"] = round(m_links.get(5, 0) + m_links.get(6, 0), 3)
    res["reach_mm"] = D.REACH_MAX

    worst = worst_static(bodies)
    # stretched pose for inertia: upper arm horizontal (J2 = 90), forearm straight (J3 = 0)
    q_str = [0, 90, 0, 0, 0]
    joints = {}
    for j in JOINTS:
        a = D.HJ2[D.JOINT_ACTUATOR[j]]
        tg, q_w = worst[j]
        I = inertia_about(bodies, q_str, j)
        alpha = math.radians(D.JOINT_AMAX_DPS2[j])
        td = I * alpha
        # the rotor's angular momentum couples into the wrist joints when the arm slews
        tau_peak = tg + td
        joints[j] = dict(actuator=D.JOINT_ACTUATOR[j], gravity_worst_Nm=round(tg, 2), worst_pose_deg=q_w,
                         inertia_stretched_kgm2=round(I, 4), dynamic_Nm=round(td, 2), peak_demand_Nm=round(tau_peak, 2),
                         rated_Nm=a["rated"], peak_Nm=a["peak"],
                         margin_rated=round(a["rated"] / max(tau_peak, 1e-9), 2), margin_peak=round(a["peak"] / max(tau_peak, 1e-9), 2),
                         vmax_dps=D.JOINT_VMAX_DPS[j], actuator_vrated_dps=a["v_rated"] * 6, brake=a["brake"], price_usd=a["price"])
    res["joints"] = joints
    # torques in the two poses that matter day to day: home (CAD pose) and the arm reaching down onto the target
    res["pose_torques_Nm"] = {"home": {j: round(v, 1) for j, v in gravity_torques(bodies, [0, 0, 0, 0, 0]).items()},
                              "reach_forward_60deg": {j: round(v, 1) for j, v in gravity_torques(bodies, [0, 60, -60, 0, 0]).items()},
                              "stretched_horizontal": {j: round(v, 1) for j, v in gravity_torques(bodies, [0, 90, 0, 0, 0]).items()}}

    # spindle: inertia, spin-up, gyroscopic coupling, rim speed, magnet field at the motor and the J5 actuator
    I_rot = sum(b.get("I_self", 0.0) for b in bodies if b["link"] == 6)
    m_rot = sum(b["m"] for b in bodies if b["link"] == 6)
    w = D.SPIN_RPM_MAX * 2 * math.pi / 60
    H = I_rot * w
    slew = math.radians(max(D.JOINT_VMAX_DPS.values()))
    mag = D.MAGNET
    V = mag["a"] * mag["b"] * mag["t"] * 1e-9
    mdip = mag["Br"] * V / (4e-7 * math.pi)
    B_at = lambda r: 1e-7 * 2 * mdip / r ** 3
    spin_up_s = 8.0
    res["spindle"] = dict(
        rotor_mass_kg=round(m_rot, 3), rotor_inertia_kgm2=round(I_rot, 6), rpm_max=D.SPIN_RPM_MAX,
        angular_momentum_Nms=round(H, 4), gyro_torque_at_max_slew_Nm=round(H * slew, 4),
        gyro_vs_J5_gravity=round(H * slew / max(joints["J5"]["gravity_worst_Nm"], 1e-9), 4),
        spin_up_torque_mNm=round(I_rot * w / spin_up_s * 1e3, 1), spin_up_s=spin_up_s,
        motor_torque_nom_mNm=D.SPINDLE_MOTOR["torque_nom_mNm"],
        rim_speed_mps=round(D.ROTOR_OD / 2e3 * w, 1), rotor_od_mm=D.ROTOR_OD, guard_od_mm=D.GUARD["od"],
        unbalance_force_N_per_g_mm=round(1e-6 * w ** 2, 3),
        dipole_Am2=round(mdip, 1), B_at_motor_mT=round(B_at(D.MOTOR_STANDOFF / 1e3) * 1e3, 2),
        B_at_J5_mT=round(B_at(D.BOOM / 1e3) * 1e3, 2), B_at_target_hull_mT=round(B_at(0.05) * 1e3, 1),
    )
    # magnetic pull on the J5 actuator's iron and the motor: upper bound with a saturating steel plate model
    # F ~ B^2 A / (2 mu0) over the exposed iron area
    mu0 = 4e-7 * math.pi
    res["spindle"]["pull_on_motor_N_upper"] = round((B_at(D.MOTOR_STANDOFF / 1e3)) ** 2 * (math.pi * 0.02 ** 2) / (2 * mu0), 3)

    # stiffness: tube bending + harmonic gear wind-up, head load at full stretch
    F_head = (m_links.get(5, 0) + m_links.get(6, 0)) * G
    _, I_up = D.tube_props(D.UPPER_TUBE["od"], D.UPPER_TUBE["wall"])
    _, I_fo = D.tube_props(D.FORE_TUBE["od"], D.FORE_TUBE["wall"])
    E = D.E_MOD["carbon_tube"]
    L_up, L_fo = D.A2 / 1e3, D.A3 / 1e3
    L_tot = D.REACH_MAX / 1e3
    # cantilever: head force at the tip; tubes in series (upper arm sees the force at L_tot, forearm at L_fo + boom)
    d_up = F_head * L_up ** 3 / (3 * E * I_up) + F_head * L_up ** 2 / (2 * E * I_up) * (L_tot - L_up)
    d_fo = F_head * L_fo ** 3 / (3 * E * I_fo) + F_head * L_fo ** 2 / (2 * E * I_fo) * (D.BOOM / 1e3)
    wind = {}
    for j, arm in (("J2", L_tot), ("J3", L_fo + D.BOOM / 1e3), ("J5", D.BOOM / 1e3)):
        k = D.K_TORSION[int(D.HJ2[D.JOINT_ACTUATOR[j]]["od"])]
        wind[j] = joints[j]["gravity_worst_Nm"] / k * arm * 1e3
    d_total = (d_up + d_fo) * 1e3 + sum(wind.values())
    k_tip = F_head / (d_total / 1e3)
    m_eff = (m_links.get(5, 0) + m_links.get(6, 0)) + 0.25 * (m_links.get(3, 0) + m_links.get(4, 0)) + 0.1 * m_links.get(2, 0)
    f1 = math.sqrt(k_tip / m_eff) / (2 * math.pi)
    res["stiffness"] = dict(head_weight_N=round(F_head, 1), tube_sag_mm=round((d_up + d_fo) * 1e3, 2),
                            gear_windup_mm={j: round(v, 2) for j, v in wind.items()}, total_tip_sag_mm=round(d_total, 2),
                            tip_stiffness_N_per_mm=round(k_tip / 1e3, 1), first_mode_hz=round(f1, 2),
                            note="static sag is measured and removed by the camera each frame; what matters is the first mode "
                                 "staying well above the 0.3 Hz content of the commanded motion")
    # power
    P_joint = sum(D.HJ2[D.JOINT_ACTUATOR[j]]["rated"] * D.HJ2[D.JOINT_ACTUATOR[j]]["v_rated"] * 2 * math.pi / 60 for j in JOINTS)
    res["power"] = dict(joints_all_rated_W=round(P_joint), spindle_W=D.SPINDLE_MOTOR["torque_nom_mNm"] / 1e3 * w,
                        psu=D.CONTROLLER["psu"])
    # cost of the drive train
    res["drive_train_cost_usd"] = round(sum(D.HJ2[D.JOINT_ACTUATOR[j]]["price"] for j in JOINTS)
                                        + D.SPINDLE_MOTOR["price"] + D.SPINDLE_DRIVER["price"] + D.MAGNET["price"])
    return res, bodies


def report(res):
    L = ["# Arm v2 loads report", "", f"Mass model: {res['mass_model_source']}.", "",
         f"Moving mass {res['moving_mass_kg']} kg, head (everything after J5, with the rotor) {res['head_mass_kg']} kg, "
         f"reach {res['reach_mm']:.0f} mm fully stretched.", "", "## Joint torques and actuator margins", "",
         "| Joint | Actuator | Worst gravity torque | Dynamic (max accel, stretched) | Peak demand | Rated / peak | Margin on rated | Margin on peak | Brake |",
         "|---|---|---|---|---|---|---|---|---|"]
    for j, r in res["joints"].items():
        L.append(f"| {j} | {r['actuator']} | {r['gravity_worst_Nm']} N m | {r['dynamic_Nm']} N m | {r['peak_demand_Nm']} N m | "
                 f"{r['rated_Nm']} / {r['peak_Nm']} N m | {r['margin_rated']}x | {r['margin_peak']}x | {'yes' if r['brake'] else 'no'} |")
    L += ["", "Worst gravity pose per joint (J1..J5 deg): " + "; ".join(f"{j}: {r['worst_pose_deg']}" for j, r in res["joints"].items()), "",
          "Gravity torque in everyday poses [N m]: " + "; ".join(f"{k}: " + ", ".join(f"{j} {v}" for j, v in d.items()) for k, d in res["pose_torques_Nm"].items()), ""]
    s = res["spindle"]
    L += ["## Spindle (magnet spinner)", "",
          f"- Rotor {s['rotor_mass_kg']} kg, inertia {s['rotor_inertia_kgm2']:.2e} kg m2, {s['rpm_max']:.0f} rpm max, rim speed {s['rim_speed_mps']} m/s.",
          f"- Angular momentum {s['angular_momentum_Nms']} N m s. Gyroscopic torque while the arm slews at its fastest: "
          f"{s['gyro_torque_at_max_slew_Nm']} N m, i.e. {100 * s['gyro_vs_J5_gravity']:.1f}% of the wrist's gravity load. Negligible.",
          f"- Spin-up to full speed in {s['spin_up_s']:.0f} s needs {s['spin_up_torque_mNm']} mN m; the motor's continuous torque is {s['motor_torque_nom_mNm']} mN m.",
          f"- Rotor OD {s['rotor_od_mm']} mm (block in its carbon tube), guard OD {s['guard_od_mm']} mm.",
          f"- Unbalance: every g mm of residual unbalance gives {s['unbalance_force_N_per_g_mm']} N of shaking force at full speed. "
          f"ISO G2.5 on this rotor is about 5 g mm -> {5 * s['unbalance_force_N_per_g_mm']:.2f} N.",
          f"- Magnet dipole {s['dipole_Am2']} A m2. Field at the spindle motor {s['B_at_motor_mT']} mT (pull on its iron < {s['pull_on_motor_N_upper']} N), "
          f"at the J5 actuator {s['B_at_J5_mT']} mT, at the hull 5 cm away {s['B_at_target_hull_mT']} mT.", ""]
    st = res["stiffness"]
    L += ["## Stiffness", "",
          f"- Head weight {st['head_weight_N']} N at full stretch: carbon tubes sag {st['tube_sag_mm']} mm, harmonic-gear wind-up "
          + ", ".join(f"{j} {v} mm" for j, v in st["gear_windup_mm"].items()) + f"; total {st['total_tip_sag_mm']} mm.",
          f"- Tip stiffness {st['tip_stiffness_N_per_mm']} N/mm, first bending mode about {st['first_mode_hz']} Hz.",
          f"- {st['note']}.", ""]
    L += ["## Power and cost", "",
          f"- All five joints at rated torque and speed together: {res['power']['joints_all_rated_W']} W; spindle {res['power']['spindle_W']:.0f} W. PSU: {res['power']['psu']}.",
          f"- Drive train (5 actuators, spindle motor and driver, magnet): ${res['drive_train_cost_usd']}.", ""]
    L += ["## Check before machining", ""] + [f"- {c}" for c in D.CHECK_BEFORE_MACHINING]
    return "\n".join(L) + "\n"


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    res, bodies = analyse()
    json.dump(res, open(os.path.join(OUT, "loads.json"), "w"), indent=1)
    open(os.path.join(OUT, "loads_report.md"), "w").write(report(res))
    print(report(res))
