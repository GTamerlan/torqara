import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, "..", ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Write the robot software configs for arm v2 from design2.py and the CAD mass properties.

    python gen_configs2.py   ->  software/config/arm_v2_5dof.toml, software/config/rig_v2.toml
"""
import os
import sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, HERE)
sys.path.insert(0, SW)
import design2 as D  # noqa: E402
from detumbler.kinematics import Arm  # noqa: E402
from detumbler.frames import rpy_R  # noqa: E402

OUT = os.path.join(SW, "config")
ZA = D.Z3
HOME_DEG = [0.0, 90.0, 0.0, 0.0, 0.0]        # DH home = CAD pose (upper arm vertical, forearm along +x)


def m(v):
    return [round(float(x) / 1000.0, 5) for x in v]


def rpy_from_R(R):
    pitch = np.arcsin(-np.clip(R[2, 0], -1, 1))
    roll = np.arctan2(R[2, 1], R[2, 2])
    yaw = np.arctan2(R[1, 0], R[0, 0])
    return [round(float(np.degrees(a)), 4) for a in (roll, pitch, yaw)]


# DH table (standard DH, same topology as the first prototype: J1 z, J2/J3 y, J4 x along the forearm, J5 y)
JOINTS = [
    dict(name="J1 base yaw", a=0.0, alpha=90.0, d=D.Z2, j="J1"),
    dict(name="J2 shoulder", a=D.A2, alpha=0.0, d=0.0, j="J2"),
    dict(name="J3 elbow", a=0.0, alpha=90.0, d=0.0, j="J3"),
    dict(name="J4 forearm roll", a=0.0, alpha=-90.0, d=D.A3, j="J4"),
    dict(name="J5 wrist pitch", a=0.0, alpha=90.0, d=0.0, j="J5"),
]

# collision capsules in the home pose (mm): link index, name, p1, p2, radius
X5 = D.X5
A = {j: D.HJ2[D.JOINT_ACTUATOR[j]] for j in D.JOINT_ACTUATOR}
CAPSULES = [
    (1, "turret + J2 actuator", (0.0, -92.0, 120.0), (0.0, 20.0, 265.0), 80.0),
    (2, "upper hub", (0.0, 20.0, D.Z2), (0.0, 110.0, D.Z2), 60.0),
    (2, "upper arm tube", (0.0, D.UPPER_Y, D.Z2 + 60), (0.0, D.UPPER_Y, ZA - 110), 31.0),
    (2, "elbow housing + J3 actuator", (0.0, 36.0, ZA), (0.0, D.J3_FLANGE_Y + A["J3"]["L"] + 10, ZA), 54.0),
    (2, "elbow boss", (0.0, D.UPPER_Y, ZA - 110), (0.0, D.UPPER_Y, ZA - 50), 38.0),
    (3, "forearm hub", (-10.0, 0.0, ZA), (92.0, 0.0, ZA), 46.0),
    (3, "forearm tube", (92.0, 0.0, ZA), (D.J4_FLANGE_X - A["J4"]["L"] - 80, 0.0, ZA), 26.0),
    (3, "J4 cradle + actuator", (D.J4_FLANGE_X - A["J4"]["L"] - 80, 0.0, ZA), (D.J4_FLANGE_X, 0.0, ZA), 37.0),
    (4, "fork root + disc", (D.J4_FLANGE_X, -68.0, ZA), (D.J4_FLANGE_X, 134.0, ZA), 40.0),
    (4, "fork arm -y + idler", (D.J4_FLANGE_X + 22, -54.0, ZA), (X5 + 40, -54.0, ZA), 47.0),
    (4, "fork arm +y", (D.J4_FLANGE_X + 22, 128.0, ZA), (X5 + 40, 128.0, ZA), 46.0),
    (4, "J5 actuator", (X5, 40.0, ZA), (X5, D.J5_FLANGE_Y + A["J5"]["L"], ZA), 36.0),
    (5, "head hub + clamp", (X5, -56.0, ZA), (X5, 40.0, ZA), 46.0),
    (5, "boom shell", (X5 + 40, 0.0, ZA), (X5 + D.X_REAR_BLOCK, 0.0, ZA), 31.0),
    (5, "marker block", (X5 + 85, 0.0, ZA + 54), (X5 + 105, 0.0, ZA + 54), 21.0),
    (5, "rear bearing block", (X5 + D.X_REAR_BLOCK, 0.0, ZA), (X5 + D.X_REAR_BLOCK + D.REAR_BLOCK["L"], 0.0, ZA), D.REAR_BLOCK["od"] / 2),
    (5, "rotor + guard", (X5 + D.X_REAR_BLOCK + D.REAR_BLOCK["L"], 0.0, ZA), (X5 + D.X_NOSE_BLOCK, 0.0, ZA), D.GUARD["od"] / 2),
    (5, "nose block", (X5 + D.X_NOSE_BLOCK, 0.0, ZA), (X5 + D.HEAD_LEN, 0.0, ZA), D.NOSE_BLOCK["od"] / 2),
]


def arm_toml():
    L = ["# Detumbler arm v2: five Leadshine HJ2 harmonic actuators, carbon links. Generated from the CAD design",
         "# (cad/source/design2.py); do not edit by hand, edit design2.py and regenerate so CAD and software agree.",
         "#   J1 base yaw, J2 shoulder, J3 elbow, J4 forearm roll, J5 wrist pitch. The magnet spindle is not a joint.",
         "# Standard DH (see config/arm_example_6dof.toml). Actuator zero = DH zero.",
         "", "[arm]", 'name = "detumbler-v2-5dof"', "base_xyz = [0.0, 0.0, 0.0]", "base_rpy_deg = [0.0, 0.0, 0.0]",
         f"home_deg = {HOME_DEG}      # CAD pose: upper arm vertical, forearm and boom along +x", ""]
    for j in JOINTS:
        a = A[j["j"]]
        lim = D.JOINT_LIMITS[j["j"]]
        if j["j"] == "J2":
            lim = (HOME_DEG[1] + lim[0], HOME_DEG[1] + lim[1])      # design limits are about the vertical; DH zero is horizontal
        L += [f"[[joint]]   # {j['name']}: {D.JOINT_ACTUATOR[j['j']]} ({a['rated']}/{a['peak']} N m, 101:1 harmonic, 24-bit encoder, EtherCAT{', brake' if a['brake'] else ''})",
              f"a = {j['a'] / 1000:.4f}", f"alpha_deg = {j['alpha']:.1f}", f"d = {j['d'] / 1000:.4f}", "theta_offset_deg = 0.0",
              f"min_deg = {float(lim[0]):.1f}", f"max_deg = {float(lim[1]):.1f}", f"max_speed_dps = {float(D.JOINT_VMAX_DPS[j['j']]):.1f}",
              f"max_accel_dps2 = {float(D.JOINT_AMAX_DPS2[j['j']]):.1f}", f"gear_ratio = {D.RATIO:.2f}",
              f"rated_torque_Nm = {a['rated']}", f"peak_torque_Nm = {a['peak']}", ""]
    L += ["[tool]", "# wrist axis -> magnet center; tool z = magnet spin axis (along the boom)",
          f"xyz = [0.0, 0.0, {D.BOOM / 1000:.4f}]", "rpy_deg = [0.0, 0.0, 0.0]", "",
          "# Collision capsules for the safety checks, in the home pose (meters, robot base frame).",
          "# link = index of the frame the part moves with (1..5 = after joint 1..5).", ""]
    for li, name, p1, p2, r in CAPSULES:
        L += ["[[collision]]", f'name = "{name}"', f"link = {li}", f"p1 = {m(p1)}", f"p2 = {m(p2)}", f"radius = {r / 1000:.4f}", ""]
    return "\n".join(L)


def rig_toml(inertia, hull_mass, arm):
    import cad2_target as CT
    import cad2_scene as CS
    T_home = arm.fk(np.radians(HOME_DEG))
    R_tool = T_home[:3, :3]
    # tool marker block: 40 mm cube, markers 30 mm on +y, -y, +z faces (ids 20, 21, 22)
    bc_world = np.array([X5 + 95, 0.0, ZA + 30 + 24]) / 1000.0
    bc_tool = R_tool.T @ (bc_world - T_home[:3, 3])
    half = 40.0 / 2000.0 + 0.002
    faces = []
    for mid, n in zip((20, 21, 22), ([0, 1, 0], [0, -1, 0], [0, 0, 1])):
        n = np.array(n, float)
        y = np.array([1.0, 0, 0])
        x = np.cross(y, n)
        Rw = np.c_[x, y, n]
        Rt = R_tool.T @ Rw
        rpy = rpy_from_R(Rt)
        assert np.allclose(rpy_R(*np.radians(rpy)), Rt, atol=1e-6)
        faces.append((mid, R_tool.T @ (n * half), rpy))
    hx, hy, hz = D.TARGET["x"] / 2000, D.TARGET["y"] / 2000, D.TARGET["z"] / 2000
    tc = np.array(D.TARGET_CENTER) / 1000.0
    cam = CS.CAMERAS[0]
    mg = D.MAGNET
    hub_r = D.ROLL_PIN["hub_od"] / 2000
    L = ["# Detumbler rig v2: arm v2 + 200 x 160 x 140 mm aluminum hull in a free three-axis external gimbal.",
         "# Generated from cad/source/design2.py and the CAD mass properties. Lengths in meters, angles in degrees.", "",
         "[target]",
         f"# {D.TARGET['x']:.0f} x {D.TARGET['y']:.0f} x {D.TARGET['z']:.0f} mm box of {D.TARGET['wall']} mm {D.TARGET['material']}, "
         f"{hull_mass:.2f} kg with hubs, pins, markers and brass ballast.",
         f"half_extents = [{hx}, {hy}, {hz}]",
         f"center_in_robot_base_guess = {m(D.TARGET_CENTER)}",
         "center_of_mass_in_body = [0.0, 0.0, 0.0]   # balance onto the gimbal center (brass trims)",
         f"inertia_est = [{inertia[0]:.4e}, {inertia[1]:.4e}, {inertia[2]:.4e}]   # hull assembly from CAD; the ring adds inertia to pitch/yaw",
         f"conductivity = {D.TARGET['sigma']:.1e}      # 1100 aluminum ~58% IACS [S/m]",
         f"wall_thickness = {D.TARGET['wall'] / 1000:.4f}",
         "start_upright = true", "# no tilt_limit_deg: the external gimbal turns freely about all three axes", "",
         "[gimbal]", "# external three-axis gimbal: roll pins in the hull's +-x faces, horizontal pitch ring, yaw yoke below",
         'type = "external_3axis"',
         f"ring_radius = {(D.PITCH_RING['id'] + D.PITCH_RING['od']) / 4000:.4f}",
         f"ring_tube = {(D.PITCH_RING['od'] - D.PITCH_RING['id']) / 4000 + 0.006:.4f}     # ring half-width + bearing block flanges",
         f"pin_r0 = {hx:.4f}", f"pin_r1 = {(CT.BODY_R0 + D.GIMBAL_BEARING['w'] + 2) / 1000:.4f}",
         f"pin_radius = {hub_r + 0.001:.4f}        # covers the roll hubs as well as the pins",
         f"arm_offset = {(CT.R_OUT + 6 + D.YOKE['arm_t'] / 2) / 1000:.4f}", f"arm_radius = {np.hypot(D.YOKE['arm_w'] / 2, D.YOKE['arm_t'] / 2) / 1000 + 0.002:.4f}",
         f"arm_z = [{-D.YOKE['drop'] / 1000:.3f}, 0.028]", f"bar_z = {(-D.YOKE['drop'] + 14) / 1000:.3f}", f"bar_radius = {np.hypot(D.YOKE['arm_w'] / 2, 14) / 1000 + 0.002:.4f}",
         "ring_segments = 24", "plan_margin = 0.025       # head and boom keep this much from the gimbal when a spot is chosen",
         "ring_side_dot = 0.5         # brake only from within 60 deg of the ring normal: over the ring, never through it",
         "yoke_lock_deg = 50.0        # roll axis within this of vertical: plan around a yoke that could be at any yaw", "",
         "[magnet]",
         f"# {mg['name']}: {mg['a']} x {mg['b']} x {mg['t']} mm, {mg['m']:.3f} kg, spun about a 2 in edge, up to {D.SPIN_RPM_MAX:.0f} rpm",
         f"radius = {mg['r_eq'] / 1000:.4f}              # equivalent radius: half the 2 in face",
         f"head_radius = {D.HEAD_RADIUS / 1000:.4f}       # carbon rotor tube + polycarbonate guard",
         f"length = {mg['a'] / 1000:.4f}", f"head_half_length = {(D.HEAD_LEN - D.X_REAR_BLOCK) / 2000:.4f}   # rear block to nose tip, half",
         f"boom_length = {(D.BOOM + 0.0) / 1000:.4f}", f"boom_radius = {max(D.BOOM_SHELL_OD, D.REAR_BLOCK['od']) / 2000 + 0.016:.4f}   # shell + clamp block",
         f"surface_field_T = {mg['surface_T']}", f"field_length = {1.5 * mg['r_eq'] / 1000:.4f}", "shape_factor = 0.3", "k_override = 0.0",
         f"sweep_max = {D.SWEEP_MAX_MPS:.1f}            # field sweep speed at the pole face [m/s] (~{D.SWEEP_MAX_MPS / (2 * np.pi * mg['r_eq'] / 1000) * 60:.0f} rpm)", "sweep_gain = 15.0           # field sweeps at up to 15x the hull speed (the spindle has the speed; dissipation holds for any gain)",
         f"rpm_max = {D.SPIN_RPM_MAX:.0f}", "",
         "[brain]", "cam_sigma_deg = 0.5", "alpha = 0.2", "beta = 0.02", "horizon = 1.5", "n_dirs = 260",
         "keepout_margin = 0.006", "standoff = 0.004", "stable_dps = 1.0", "restart_dps = 2.0",
         "approach_speed = 0.10", "approach_rate_dps = 40.0", "switch_ratio = 1.6", "travel_scale = 0.6",
         "plan_horizon_max = 12.0", "min_dwell_s = 20.0",
         "pole_dot = 0.75           # skip spots near the momentum axis, where the magnet axis is ill-defined",
         "js_far = 0.045", "spin_axis_tol_deg = 45.0", "",
         "[camera]", "# Arducam OV9281 global shutter (mono), 6 mm M12 lens, on the camera mast; a second camera (cam_B) is mounted for later",
         "index = 0", f"nominal_xyz = {m(cam[1])}", f"look_at = {m(cam[2])}", "width = 1280", "height = 800", "fps = 30",
         'intrinsics_file = "calibration/camera_intrinsics.json"', 'camera_to_base_file = "calibration/camera_to_base.json"',
         'aruco_dictionary = "DICT_4X4_50"', "",
         "# Markers on the hull faces. +-x carry a smaller marker above the roll hub. Marker frame: z out of the face.", ""]
    face_xyz = {"+x": ([hx + 0.0015, 0, 0.044], [0, 90, 0]), "-x": ([-hx - 0.0015, 0, 0.044], [0, -90, 0]),
                "+y": ([0, hy + 0.0015, 0], [-90, 0, 0]), "-y": ([0, -hy - 0.0015, 0], [90, 0, 0]),
                "+z": ([0, 0, hz + 0.0015], [0, 0, 0]), "-z": ([0, 0, -hz - 0.0015], [180, 0, 0])}
    for mid, face in CT.TARGET_MARKERS:
        xyz, rpy = face_xyz[face]
        size = 0.040 if face[1] == "x" else CT.MARKER["size"] / 1000
        L += ["[[target_marker]]", f"id = {mid}", f"size = {size:.3f}", f"xyz = [{xyz[0]:.5f}, {xyz[1]:.5f}, {xyz[2]:.5f}]", f"rpy_deg = {rpy}", ""]
    L += ["# Marker block on the boom: three 30 mm markers on a 40 mm cube. Its exact offset on the tool is solved by",
          "# the camera-to-robot calibration.", "[tool_marker]", "id = 20", "size = 0.030",
          f"xyz_in_tool_guess = [{bc_tool[0]:.4f}, {bc_tool[1]:.4f}, {bc_tool[2]:.4f}]", ""]
    for mid, xyz, rpy in faces:
        L += ["[[tool_marker_face]]", f"id = {mid}", "size = 0.030", f"xyz_in_block = [{xyz[0]:.5f}, {xyz[1]:.5f}, {xyz[2]:.5f}]", f"rpy_deg = {rpy}", ""]
    st = D.STAND
    z_top = (D.TARGET_CENTER[2] - D.STAND_TOP_BELOW_CENTER) / 1000
    L += ["[stand]", "# aluminum post and base under the target gimbal: the arm must never touch them",
          f"center_xy = {m(D.TARGET_CENTER[:2])}", f"post_radius = {st['post_od'] / 2000:.3f}",
          f"post_top_z = {z_top + 0.0:.3f}   # top of the yaw bearing housing", f"base_radius = {np.hypot(st['base'][0], st['base'][1]) / 2000:.3f}",
          f"base_top_z = {(-D.BASE_PLATE['t'] - D.PEDESTAL['h'] + st['base'][2]) / 1000:.3f}",
          "planner_cone_deg = 35.0     # never plan magnet spots within 35 deg of straight down", "",
          "[safety]", f"table_z = {(-D.BASE_PLATE['t'] - D.PEDESTAL['h']) / 1000:.3f}     # the floor", "min_tool_z = 0.05",
          "link_table_clearance = 0.02", "static_margin = 0.01",
          f"workspace_min = [-0.30, -0.80, 0.05]", f"workspace_max = [{(D.TARGET_CENTER[0] + 300) / 1000:.2f}, 0.80, {(ZA + 500) / 1000:.2f}]",
          "min_gap = 0.003", "max_joint_step_deg = 3.0", "lost_lock_timeout = 0.5", ""]
    return "\n".join(L)


if __name__ == "__main__":
    import cad2_target
    M, cm, J = cad2_target.box_mass_properties()
    inertia = np.diag(J)
    open(f"{OUT}/arm_v2_5dof.toml", "w").write(arm_toml())
    arm = Arm.from_toml(f"{OUT}/arm_v2_5dof.toml")
    open(f"{OUT}/rig_v2.toml", "w").write(rig_toml(inertia, M, arm))
    T = arm.fk(np.radians(HOME_DEG))
    print("hull", round(M, 3), "kg, inertia", np.round(inertia, 5))
    print("tool home", np.round(T[:3, 3] * 1000, 2), "mm (expected", D.MAGNET_CENTER, "), tool z", np.round(T[:3, 2], 3))
    F = arm.frames(np.radians(HOME_DEG))
    for i, j in enumerate(JOINTS, start=1):
        print(f"  frame {i} origin", np.round(F[i][:3, 3] * 1000, 1), "z axis", np.round(F[i - 1][:3, 2], 2))
    print("capsules", len(arm.capsules), "reach", round(arm.reach(), 3))
