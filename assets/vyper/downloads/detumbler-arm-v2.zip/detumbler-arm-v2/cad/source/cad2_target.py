"""Target hull and its free three-axis gimbal (roll pins in the box, horizontal pitch ring, yaw yoke on a stand).

Components (each moves as one body):
  TARGET_STAND  fixed: floor base, post, yaw bearing housing with two ceramic bearings
  TARGET_YOKE   yaw: U-yoke with its yaw shaft, pitch pins (pressed in the arms)
  TARGET_RING   pitch: G10 ring with four bearing blocks (two on the pitch pins, two holding the roll pins)
  TARGET_BOX    roll: aluminum hull + hubs + roll pins + marker plates
Frame: robot base frame, box centered at D.TARGET_CENTER, body axes = robot axes at home.
"""
import math
import os
import sys
import numpy as np
import cadquery as cq

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import design2 as D  # noqa: E402
from cad2_lib import (V, cyl, tube, box, rbox, fuse, along, place, rot_to, holes, bore, screws, cb_screws, bearing, pcd_points,  # noqa: E402
                      SCREW, CLEARANCE, TAP_DRILL)
from cad_lib import marker_plate_local  # noqa: E402

TC = np.array(D.TARGET_CENTER)
X, Y, Z = np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])
T = D.TARGET
HX, HY, HZ = T["x"] / 2, T["y"] / 2, T["z"] / 2
RING = D.PITCH_RING
R_IN, R_OUT = RING["id"] / 2, RING["od"] / 2
GB = D.GIMBAL_BEARING
PIN_D = D.ROLL_PIN["d"]
TARGET_MARKERS = [(0, "+x"), (1, "-x"), (2, "+y"), (3, "-y"), (4, "+z"), (5, "-z")]
MARKER = dict(size=60.0, plate=70.0, t=1.5)


def brg(cfg, p0, d, prefix):
    return [(n, s, c, "ceramic" if "seal" not in n else "rubber") for n, s, c in bearing(cfg, p0, d, prefix=prefix)]


# ------------------------------------------------------------------------------------------------- box (roll)
def box_parts():
    P = []
    w = T["wall"]
    c = TC
    outer = box((c[0] - HX, c[0] + HX), (c[1] - HY, c[1] + HY), (c[2] - HZ, c[2] + HZ))
    inner = box((c[0] - HX + w, c[0] + HX - w), (c[1] - HY + w, c[1] + HY - w), (c[2] - HZ + w, c[2] + HZ - w))
    hull = outer.cut(inner)
    # hub bolt holes on the +-x faces: 4 x M4 on a 28 mm PCD around the roll axis, plus the pin hole
    for sx in (-1, 1):
        face = c + X * sx * HX
        hull = holes(hull, CLEARANCE["M4"], pcd_points(4, 28.0, 45), face, X * sx, depth=w + 1)
        hull = hull.cut(cyl(PIN_D / 2 + 0.5, face - X * sx * 2, face + X * sx * 2))
    P.append(("hull_1100_aluminum_1.5mm", hull, "bus", "alu"))
    # roll hubs (printed PA12-CF) on both x faces: a disc with a boss, the pin pressed into it
    hub_od, hub_t = D.ROLL_PIN["hub_od"], D.ROLL_PIN["hub_t"]
    for sx, tag in ((1, "px"), (-1, "nx")):
        face = c + X * sx * HX
        hub = cyl(hub_od / 2, face, face + X * sx * hub_t)
        hub = fuse(hub, cyl(9.0, face + X * sx * hub_t, face + X * sx * (hub_t + 10)))
        hub = holes(hub, TAP_DRILL["M4"], pcd_points(4, 28.0, 45), face, -X * sx, depth=hub_t - 2)
        hub = bore(hub, PIN_D, face - X * sx * 1, face + X * sx * (hub_t + 11))        # press fit
        P.append((f"roll_hub_{tag}_printed", hub, "pa_cf", "pa_cf"))
        P.append((f"roll_hub_{tag}_screws_M4", screws("M4", 8, pcd_points(4, 28.0, 45), face - X * sx * w, -X * sx), "anod_black", "steel"))
        # pin: from inside the hub to the ring's bearing block
        pin = cyl(PIN_D / 2, face + X * sx * 1, c + X * sx * (BODY_R0 + GB["w"] + 2))
        P.append((f"roll_pin_{tag}_316", pin, "steel", "steel"))
    # markers on all six faces (the roll hubs sit at the +-x face centers, so those markers are offset in z)
    for mid, face in TARGET_MARKERS:
        n = {"+x": X, "-x": -X, "+y": Y, "-y": -Y, "+z": Z, "-z": -Z}[face]
        off = {"+x": HX, "-x": HX, "+y": HY, "-y": HY, "+z": HZ, "-z": HZ}[face]
        shift = Z * 0 if face[1] != "x" else Z * 0
        center = c + n * off
        size, plate = MARKER["size"], MARKER["plate"]
        if face[1] == "x":
            center = center + Z * 44.0          # above the roll hub
            size, plate = 40.0, 46.0
        up = Z if face[1] != "z" else X
        R = rot_to(n)
        up_l = R @ np.array([0, 1.0, 0])
        ang = math.atan2(np.dot(np.cross(up_l, up), n), np.dot(up_l, up))
        Rn = R @ np.array([[math.cos(ang), -math.sin(ang), 0], [math.sin(ang), math.cos(ang), 0], [0, 0, 1]])
        for (s, col), nm in zip(marker_plate_local(mid, size, plate, MARKER["t"]), ("_plate", "_ink")):
            P.append((f"target_marker_{mid}{nm}", place(s, Rn, center), col, "printed"))
    # inertia ballast: two brass plates on the inside of the +-y walls (keeps the hull's inertia satellite-like)
    for sy in (-1, 1):
        y0 = c[1] + sy * (HY - w - 4)
        P.append((f"ballast_brass_{'py' if sy > 0 else 'ny'}", box((c[0] - 60, c[0] + 60), (min(y0, y0 + sy * 4), max(y0, y0 + sy * 4)), (c[2] - 40, c[2] + 40)), "brass", "copper"))
    return P


# ------------------------------------------------------------------------------------------------- ring (pitch)
BODY_R0, BODY_R1 = R_IN - 6, R_IN + 24          # bearing block body, radial extent
BODY_W = 24.0                                   # tangential width (sits in a notch of the ring)
NOTCH_R1 = R_IN + 25
FLANGE_W = 48.0


def ring_parts():
    """G10 ring with four notches; printed bearing blocks sit in the notches (bearing axis through the target
    center), each held by a top flange with two M4 through the ring and nyloc nuts below."""
    P = []
    c = TC
    t = RING["t"]
    ring = tube(R_OUT, R_IN, c - Z * t / 2, c + Z * t / 2)
    for ax, tag in ((X, "x"), (Y, "y")):
        tang = Y if tag == "x" else X
        for s in (-1, 1):
            u = ax * s
            # notch
            n0, n1 = c + u * (R_IN - 1), c + u * NOTCH_R1
            lo = np.minimum(n0, n1) - tang * (BODY_W / 2 + 0.2) - Z * (t / 2 + 1)
            hi = np.maximum(n0, n1) + tang * (BODY_W / 2 + 0.2) + Z * (t / 2 + 1)
            ring = ring.cut(box((lo[0], hi[0]), (lo[1], hi[1]), (lo[2], hi[2])))
            # block body + flange
            b0, b1 = c + u * BODY_R0, c + u * BODY_R1
            lo = np.minimum(b0, b1) - tang * BODY_W / 2 - Z * 15
            hi = np.maximum(b0, b1) + tang * BODY_W / 2 + Z * 15
            body = box((lo[0], hi[0]), (lo[1], hi[1]), (lo[2], hi[2]))
            f0, f1 = c + u * (R_IN + 2), c + u * BODY_R1
            lo = np.minimum(f0, f1) - tang * FLANGE_W / 2 + Z * (t / 2)
            hi = np.maximum(f0, f1) + tang * FLANGE_W / 2 + Z * (t / 2 + 6)
            flange = box((lo[0], hi[0]), (lo[1], hi[1]), (lo[2], hi[2]))
            blk = fuse(body, flange)
            # bearing bore: roll blocks (x) carry the bearing at the inner face, pitch blocks (y) at the outer face
            if tag == "x":
                blk = bore(blk, GB["od"] + 0.05, c + u * (BODY_R0 - 1), c + u * (BODY_R0 + GB["w"]))
                blk = bore(blk, GB["bore"] + 2, c + u * (BODY_R0 + GB["w"] - 1), c + u * (BODY_R1 + 1))
                brg_p0 = c + u * BODY_R0
            else:
                blk = bore(blk, GB["od"] + 0.05, c + u * (BODY_R1 - GB["w"]), c + u * (BODY_R1 + 1))
                blk = bore(blk, GB["bore"] + 2, c + u * (BODY_R0 - 1), c + u * (BODY_R1 - GB["w"] + 1))
                brg_p0 = c + u * (BODY_R1 - GB["w"])
            rmid = (R_IN + 2 + BODY_R1) / 2
            pts = [(cp[0], cp[1]) for cp in (c + u * rmid + tang * 18, c + u * rmid - tang * 18)]
            blk = holes(blk, CLEARANCE["M4"], pts, (0, 0, c[2] + t / 2 + 6), Z, depth=t + 7, counterbore=(SCREW["M4"][1] + 0.6, SCREW["M4"][2] + 0.5))
            ring = holes(ring, CLEARANCE["M4"], pts, (0, 0, c[2] + t / 2), Z, depth=t + 1)
            nm = f"{tag}{'p' if s > 0 else 'n'}"
            P.append((f"bearing_block_{nm}_printed", blk, "pa_cf", "pa_cf"))
            P.append((f"block_screws_{nm}_M4", cb_screws("M4", t + 6, 4, pts, (0, 0, c[2] + t / 2 + 6), Z), "anod_black", "steel"))
            nuts = fuse(*[cq.Workplane("XY").workplane(offset=c[2] - t / 2 - 3.2).center(px, py).polygon(6, 7.0 / math.cos(math.pi / 6)).extrude(3.2).val()
                          .cut(cyl(2.0, (px, py, c[2] - t / 2 - 4), (px, py, c[2] - t / 2 + 1))) for px, py in pts])
            P.append((f"block_nuts_{nm}_M4_nyloc", nuts, "steel", "steel"))
            P += brg(GB, brg_p0, u, f"gimbal_bearing_{nm}_608")
    P.insert(0, ("pitch_ring_G10", ring, "g10", "g10"))
    return P


# ------------------------------------------------------------------------------------------------- yoke (yaw)
def yoke_parts():
    P = []
    c = TC
    yk = D.YOKE
    arm_y = R_OUT + 6                 # inner face of the yoke arms, clear of the ring
    drop = yk["drop"]
    arms = []
    for s in (-1, 1):
        y0, y1 = sorted((c[1] + s * arm_y, c[1] + s * (arm_y + yk["arm_t"])))
        arm = rbox((c[0] - yk["arm_w"] / 2, c[0] + yk["arm_w"] / 2), (y0, y1), (c[2] - drop, c[2] + 28), 12, edges="|Y")
        arms.append(arm)
    bar = rbox((c[0] - yk["arm_w"] / 2, c[0] + yk["arm_w"] / 2), (c[1] - arm_y - yk["arm_t"], c[1] + arm_y + yk["arm_t"]),
               (c[2] - drop, c[2] - drop + 28), 6, edges="|Y")
    boss = cyl(24.0, c - Z * drop, c - Z * (drop + 20))
    yoke = fuse(*arms, bar, boss)
    ys = D.YAW_SHAFT
    yoke = bore(yoke, ys["d"], c - Z * (drop + 21), c - Z * (drop - 20))          # press fit (line to line in CAD)
    for s in (-1, 1):
        yoke = bore(yoke, PIN_D, c + Y * s * (arm_y - 1), c + Y * s * (arm_y + yk["arm_t"] + 1))     # press fit
    P.append(("yaw_yoke_printed", yoke, "pa_cf", "pa_cf"))
    for s, tag in ((1, "py"), (-1, "ny")):
        pin = cyl(PIN_D / 2, c + Y * s * (BODY_R1 - GB["w"] - 2), c + Y * s * (arm_y + yk["arm_t"] - 1))
        P.append((f"pitch_pin_{tag}_316", pin, "steel", "steel"))
    hs = D.STAND_TOP_BELOW_CENTER
    shaft = cyl(ys["d"] / 2, c - Z * (drop - 19), c - Z * (hs + 60))
    P.append(("yaw_shaft_316", shaft, "steel", "steel"))
    return P


# ------------------------------------------------------------------------------------------------- stand (fixed)
def stand_parts():
    P = []
    c = TC
    st = D.STAND
    ys = D.YAW_SHAFT
    b = ys["bearing"]
    hs = D.STAND_TOP_BELOW_CENTER
    z_top = c[2] - hs
    # bearing housing (aluminum): two bearings 40 mm apart
    hous = cyl(st["post_od"] / 2, (c[0], c[1], z_top - 70), (c[0], c[1], z_top))
    hous = bore(hous, b["od"] + 0.05, (c[0], c[1], z_top - b["w"]), (c[0], c[1], z_top + 1))
    hous = bore(hous, b["od"] + 0.05, (c[0], c[1], z_top - 50 - b["w"]), (c[0], c[1], z_top - 50))
    hous = bore(hous, b["bore"] + 4, (c[0], c[1], z_top - 71), (c[0], c[1], z_top))
    hous = fuse(hous, cyl(st["post_od"] / 2 - st["post_wall"] - 0.05, (c[0], c[1], z_top - 100), (c[0], c[1], z_top - 70)))   # spigot into the post
    hous = holes(hous, 3.3, [(c[0] + st["post_od"] / 2 - st["post_wall"] / 2, c[1]), (c[0] - st["post_od"] / 2 + st["post_wall"] / 2, c[1])], (0, 0, z_top - 85), (1, 0, 0), depth=0)
    P.append(("yaw_bearing_housing", hous, "alu", "alu"))
    P += brg(b, (c[0], c[1], z_top - b["w"]), Z, "yaw_bearing_top_6903")
    P += brg(b, (c[0], c[1], z_top - 50 - b["w"]), Z, "yaw_bearing_bottom_6903")
    zf = -D.BASE_PLATE["t"] - D.PEDESTAL["h"]       # floor
    post = tube(st["post_od"] / 2, st["post_od"] / 2 - st["post_wall"], (c[0], c[1], zf + st["base"][2]), (c[0], c[1], z_top - 70))
    P.append(("stand_post_6061", post, "alu", "alu"))
    base = rbox((c[0] - st["base"][0] / 2, c[0] + st["base"][0] / 2), (c[1] - st["base"][1] / 2, c[1] + st["base"][1] / 2), (zf, zf + st["base"][2]), 20)
    base = holes(base, 12.0, [(c[0] + sx * 210, c[1] + sy * 210) for sx in (-1, 1) for sy in (-1, 1)], (0, 0, zf), Z)
    P.append(("stand_base_plate", base, "alu", "alu"))
    for i, (sx, sy) in enumerate([(-1, -1), (-1, 1), (1, -1), (1, 1)]):
        P.append((f"stand_foot_{i}", cyl(22, (c[0] + sx * 210, c[1] + sy * 210, zf - 30), (c[0] + sx * 210, c[1] + sy * 210, zf)), "rubber", "steel"))
    flange = tube(st["post_od"] / 2 + 25, st["post_od"] / 2 + 0.05, (c[0], c[1], zf + st["base"][2]), (c[0], c[1], zf + st["base"][2] + 10))
    flange = holes(flange, CLEARANCE["M8"], pcd_points(4, st["post_od"] + 30, 45), (c[0], c[1], zf + st["base"][2] + 10), Z, depth=11,
                   counterbore=(SCREW["M8"][1] + 0.6, SCREW["M8"][2] + 0.5))
    P.append(("stand_post_flange", flange, "alu", "alu"))
    P.append(("stand_flange_screws_M8", cb_screws("M8", 10, 12, pcd_points(4, st["post_od"] + 30, 45), (c[0], c[1], zf + st["base"][2] + 10), Z), "anod_black", "steel"))
    return P


COMPONENTS = [("TARGET_STAND", stand_parts), ("TARGET_YOKE", yoke_parts), ("TARGET_RING", ring_parts), ("TARGET_BOX", box_parts)]


def box_mass_properties():
    """Mass [kg], center [mm], inertia tensor about the center [kg m^2] of everything that rolls with the hull."""
    from cad2_lib import mass_props
    tot_m, tot_c = 0.0, np.zeros(3)
    rows = []
    for _n, s, _c, mat in box_parts():
        m, c, I = mass_props(s, D.DENSITY[mat])
        rows.append((m, c, I))
        tot_m += m
        tot_c += m * c
    tot_c /= tot_m
    J = np.zeros((3, 3))
    for m, c, I in rows:
        d = (c - tot_c) / 1e3
        J += I + m * (np.dot(d, d) * np.eye(3) - np.outer(d, d))
    return tot_m, tot_c, J


if __name__ == "__main__":
    m, c, J = box_mass_properties()
    print("hull assembly", round(m, 3), "kg, CoM offset", np.round(c - TC, 2), "mm, inertia diag", np.round(np.diag(J), 5))
    for n, fn in COMPONENTS:
        p = fn()
        print(n, len(p), "parts, invalid:", [q[0] for q in p if not q[1].isValid()])
