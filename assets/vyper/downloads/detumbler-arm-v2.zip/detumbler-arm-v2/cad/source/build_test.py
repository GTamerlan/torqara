import sys, time, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import cad2_arm as C
which = sys.argv[1:] or [n for n, _ in C.LINKS]
for name, fn in C.LINKS:
    if name not in which: continue
    t = time.time()
    parts = fn()
    bad = [n for n, s, c, m in parts if s.Volume() <= 0 or not s.isValid()]
    print(f"{name}: {len(parts)} parts, {time.time()-t:.1f}s", "INVALID:" if bad else "", bad)
