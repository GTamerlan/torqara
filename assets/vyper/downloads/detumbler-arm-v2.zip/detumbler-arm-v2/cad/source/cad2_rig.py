"""Assemble arm v2 + target rig, export STEP / STL / GLB, write the mass model and the parts manifest.

    python cad2_rig.py            # everything
    python cad2_rig.py --glb      # only GLBs (for renders)
"""
import os
import sys
import json
import time
import numpy as np
import cadquery as cq
from cadquery.occ_impl.exporters.assembly import exportAssembly, exportGLTF

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import design2 as D  # noqa: E402
from cad2_lib import color, mass_props  # noqa: E402
import cad2_arm  # noqa: E402

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out")
PRINTED_MATERIALS = {"pa_cf", "printed"}


def components(with_target=True, with_scene=True):
    comps = {}
    for name, fn in cad2_arm.LINKS:
        comps[name] = fn()
    if with_target:
        import cad2_target
        for name, fn in cad2_target.COMPONENTS:
            comps[name] = fn()
    if with_scene:
        import cad2_scene
        for name, fn in cad2_scene.COMPONENTS:
            comps[name] = fn()
    return comps


def sub_assembly(cname, parts):
    a = cq.Assembly(name=cname)
    seen = {}
    for pname, shape, col, _m in parts:
        k = seen.get(pname, 0)
        seen[pname] = k + 1
        a.add(shape, name=pname if k == 0 else f"{pname}_{k}", color=color(col))
    return a


def mass_model(comps):
    """Bodies for sizing.py: one per part, with the kinematic link index (0 base .. 6 rotor), from CAD volumes."""
    bodies = []
    link_of = dict(cad2_arm.LINK_INDEX)
    for cname, parts in comps.items():
        if cname not in link_of:
            continue
        for pname, shape, _c, mat in parts:
            rho = D.DENSITY["steel"] if mat == "actuator" else D.DENSITY[mat]
            m, c, I = mass_props(shape, rho)
            if mat == "actuator":
                continue           # actuators are added once per joint with the catalog mass (below)
            if pname.startswith("spindle_motor_maxon"):
                m = D.SPINDLE_MOTOR["m"]       # catalog mass, not a solid steel cylinder
            # rotor parts: inertia about the spin axis (x) for the gyroscopic terms; full tensor for the physics model
            I_self = float(I[0, 0]) if link_of[cname] == 6 else 0.0
            if pname.startswith("spindle_motor_maxon"):
                I = I * (D.SPINDLE_MOTOR["m"] / max(float(mass_props(shape, D.DENSITY["steel"])[0]), 1e-9))
            bodies.append(dict(name=f"{cname}/{pname}", link=link_of[cname], m=round(float(m), 5), com=[round(float(v), 2) for v in c], I_self=I_self,
                               I=[float(I[0, 0]), float(I[1, 1]), float(I[2, 2]), float(I[0, 1]), float(I[0, 2]), float(I[1, 2])]))
    # actuators: catalog mass at the body center
    for j, (p, d) in {"J1": (cad2_arm.J1_P, cad2_arm.J1_D), "J2": (cad2_arm.J2_P, cad2_arm.J2_D), "J3": (cad2_arm.J3_P, cad2_arm.J3_D),
                      "J4": (cad2_arm.J4_P, cad2_arm.J4_D), "J5": (cad2_arm.J5_P, cad2_arm.J5_D)}.items():
        a = D.HJ2[D.JOINT_ACTUATOR[j]]
        c = np.asarray(p, float) - np.asarray(d, float) * a["L"] / 2
        link = {"J1": 0, "J2": 1, "J3": 2, "J4": 3, "J5": 4}[j]
        # solid-cylinder inertia of the actuator about its own center, axis along d
        r, L = a["od"] / 2e3, a["L"] / 1e3
        I_ax, I_tr = 0.5 * a["m"] * r ** 2, a["m"] * (3 * r ** 2 + L ** 2) / 12
        dv = np.abs(np.asarray(d, float))
        Id = dv * I_ax + (1 - dv) * I_tr
        bodies.append(dict(name=f"{j} actuator {D.JOINT_ACTUATOR[j]}", link=link, m=a["m"], com=[round(float(v), 2) for v in c], I_self=0.0,
                           I=[float(Id[0]), float(Id[1]), float(Id[2]), 0.0, 0.0, 0.0]))
    # gimbal and hull bodies for the physics model (not part of the arm chain): link codes 10 yoke, 11 ring, 12 hull
    import cad2_target
    for cname, fn, code in (("TARGET_YOKE", cad2_target.yoke_parts, 10), ("TARGET_RING", cad2_target.ring_parts, 11), ("TARGET_BOX", cad2_target.box_parts, 12)):
        for pname, shape, _c, mat in comps.get(cname, fn()):
            m, c, I = mass_props(shape, D.DENSITY[mat])
            bodies.append(dict(name=f"{cname}/{pname}", link=code, m=round(float(m), 5), com=[round(float(v), 2) for v in c], I_self=0.0,
                               I=[float(I[0, 0]), float(I[1, 1]), float(I[2, 2]), float(I[0, 1]), float(I[0, 2]), float(I[1, 2])]))
    return bodies


if __name__ == "__main__":
    only_glb = "--glb" in sys.argv
    t0 = time.time()
    for d in ("cad/components", "glb", "stl_printed"):
        os.makedirs(f"{OUT}/{d}", exist_ok=True)
    comps = components(with_target="--arm-only" not in sys.argv, with_scene="--arm-only" not in sys.argv)
    n = sum(len(v) for v in comps.values())
    print(f"built {n} parts in {len(comps)} components, {time.time() - t0:.0f}s")
    manifest = {}
    for cname, parts in comps.items():
        a = sub_assembly(cname, parts)
        exportGLTF(a, f"{OUT}/glb/{cname}.glb", True, 0.12, 0.2)
        manifest[cname] = [(p, m) for p, _, _, m in parts]
        if not only_glb:
            exportAssembly(a, f"{OUT}/cad/components/{cname}.step")
            for pname, shape, _c, m in parts:
                if m in PRINTED_MATERIALS:
                    cq.exporters.export(cq.Workplane(obj=shape), f"{OUT}/stl_printed/{cname}__{pname}.stl", tolerance=0.03, angularTolerance=0.1)
    json.dump(manifest, open(f"{OUT}/parts_manifest.json", "w"), indent=1)
    bodies = mass_model(comps)
    json.dump(bodies, open(f"{OUT}/mass_model.json", "w"), indent=1)
    print("mass model:", len(bodies), "bodies,", round(sum(b["m"] for b in bodies if 1 <= b["link"] <= 6), 3), "kg moving arm")
    if not only_glb:
        root = cq.Assembly(name="DETUMBLER_ARM_V2")
        for cname, parts in comps.items():
            root.add(sub_assembly(cname, parts), name=cname)
        exportAssembly(root, f"{OUT}/cad/Detumbler_Arm_v2_Assembly.step")
        print("STEP", round(os.path.getsize(f"{OUT}/cad/Detumbler_Arm_v2_Assembly.step") / 1e6, 1), "MB")
    print("done", round(time.time() - t0), "s")
