"""Small CadQuery helper library: solids in absolute coordinates (mm), standard parts."""
import math
import numpy as np
import cadquery as cq
from OCP.gp import gp_Trsf, gp_Vec
from OCP.GProp import GProp_GProps
from OCP.BRepGProp import BRepGProp

V = cq.Vector

# ------------------------------------------------------------------ colors (r, g, b, a)
COL = {
    "alu": (0.80, 0.81, 0.84, 1), "alu_dark": (0.62, 0.64, 0.68, 1), "anod_black": (0.11, 0.11, 0.13, 1),
    "printed": (0.20, 0.21, 0.24, 1), "accent": (0.94, 0.58, 0.23, 1), "motor": (0.07, 0.07, 0.08, 1),
    "motor_cap": (0.66, 0.67, 0.70, 1), "steel": (0.55, 0.56, 0.59, 1), "magnet": (0.86, 0.86, 0.89, 1),
    "guard": (0.82, 0.90, 1.00, 0.30), "carbon": (0.09, 0.09, 0.10, 1), "bus": (0.83, 0.84, 0.87, 1),
    "white": (0.97, 0.97, 0.96, 1), "black": (0.02, 0.02, 0.02, 1), "g10": (0.78, 0.80, 0.58, 1),
    "brass": (0.82, 0.66, 0.30, 1), "hdpe": (0.16, 0.16, 0.17, 1), "extrusion": (0.74, 0.75, 0.78, 1),
    "red": (0.80, 0.08, 0.08, 1), "yellow": (0.96, 0.78, 0.10, 1), "pcb": (0.05, 0.36, 0.20, 1),
    "pcb_blue": (0.08, 0.20, 0.55, 1), "rubber": (0.05, 0.05, 0.05, 1), "led": (0.95, 0.95, 0.85, 1),
    "copper": (0.80, 0.45, 0.25, 1), "gold_mli": (0.85, 0.66, 0.22, 1), "silver_mli": (0.76, 0.78, 0.80, 1),
    "solar": (0.07, 0.10, 0.28, 1), "glass": (0.6, 0.75, 0.9, 0.35), "belt": (0.08, 0.08, 0.08, 1),
}


def color(name):
    return cq.Color(*COL[name])


# ------------------------------------------------------------------ primitives (absolute coordinates)
def cyl(r, p0, p1):
    p0, p1 = V(*p0), V(*p1)
    d = p1 - p0
    return cq.Solid.makeCylinder(r, d.Length, p0, d.normalized())


def tube(ro, ri, p0, p1):
    return cyl(ro, p0, p1).cut(cyl(ri, p0, p1))


def box(xr, yr, zr):
    return cq.Solid.makeBox(xr[1] - xr[0], yr[1] - yr[0], zr[1] - zr[0], V(xr[0], yr[0], zr[0]))


def rbox(xr, yr, zr, r, edges="|Z"):
    w = cq.Workplane("XY").box(xr[1] - xr[0], yr[1] - yr[0], zr[1] - zr[0])
    if r > 0:
        w = w.edges(edges).fillet(r)
    return w.val().translate(V((xr[0] + xr[1]) / 2, (yr[0] + yr[1]) / 2, (zr[0] + zr[1]) / 2))


def sphere(r, c):
    return cq.Solid.makeSphere(r, V(*c), angleDegrees1=-90, angleDegrees2=90)


def fuse(*shapes):
    out = shapes[0]
    for s in shapes[1:]:
        out = out.fuse(s)
    return out.clean()


def rot_to(d):
    """Rotation matrix taking +z to unit direction d."""
    d = np.asarray(d, float) / np.linalg.norm(d)
    z = np.array([0, 0, 1.0])
    v = np.cross(z, d)
    c = float(np.dot(z, d))
    if np.linalg.norm(v) < 1e-12:
        return np.eye(3) if c > 0 else np.diag([1, -1, -1.0])
    vx = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + vx + vx @ vx * (1 / (1 + c))


def place(shape, R=np.eye(3), t=(0, 0, 0)):
    tr = gp_Trsf()
    R = np.asarray(R, float)
    tr.SetValues(R[0, 0], R[0, 1], R[0, 2], t[0], R[1, 0], R[1, 1], R[1, 2], t[1], R[2, 0], R[2, 1], R[2, 2], t[2])
    return shape.moved(cq.Location(tr))


def along(shape_local_z, p, d, spin_deg=0.0):
    """Shape built along +z from the origin -> origin at p, +z along d (optional spin about d)."""
    R = rot_to(d)
    if spin_deg:
        a = math.radians(spin_deg)
        Rz = np.array([[math.cos(a), -math.sin(a), 0], [math.sin(a), math.cos(a), 0], [0, 0, 1]])
        R = R @ Rz
    return place(shape_local_z, R, p)


def mass_props(shape, density):
    """Return mass [kg], center [mm], inertia about center [kg m^2] for a shape in mm and density kg/m^3."""
    p = GProp_GProps()
    BRepGProp.VolumeProperties_s(shape.wrapped, p)
    vol_mm3 = p.Mass()
    c = p.CentreOfMass()
    m = p.MatrixOfInertia()
    I = np.array([[m.Value(i, j) for j in (1, 2, 3)] for i in (1, 2, 3)])   # mm^5, about the center
    rho = density * 1e-9                                                     # kg/mm^3
    return vol_mm3 * rho, np.array([c.X(), c.Y(), c.Z()]), I * rho * 1e-6   # kg m^2


# ------------------------------------------------------------------ standard parts (built along +z, front face at z=0)
def nema_local(cfg, with_encoder=True):
    """Stepper motor: front face at z=0, body toward -z, shaft toward +z."""
    s, L = cfg["side"], cfg["length"]
    body = cq.Workplane("XY").rect(s, s).extrude(-L + 9).edges("|Z").chamfer(s * 0.09).val()
    front = cq.Workplane("XY").rect(s, s).extrude(-4.5).edges("|Z").chamfer(s * 0.11).val()
    rear = cq.Workplane("XY").workplane(offset=-L).rect(s, s).extrude(4.5).edges("|Z").chamfer(s * 0.11).val()
    pilot = cyl(cfg["pilot"] / 2, (0, 0, 0), (0, 0, 2.0))
    shaft = cyl(cfg["shaft"] / 2, (0, 0, 0), (0, 0, cfg["shaft_len"]))
    conn = box((-8, 8), (s / 2 - 1, s / 2 + 5), (-L + 6, -L + 18))
    parts = [(fuse(body), "motor"), (fuse(front, rear, pilot), "motor_cap"), (shaft, "steel"), (conn, "printed")]
    if with_encoder:
        parts.append((cyl(ENC_OD / 2, (0, 0, -L - 10), (0, 0, -L)), "printed"))
        parts.append((cyl(4, (0, 0, -L - 12), (0, 0, -L - 10)), "accent"))
    bolts = [cyl(1.7, (x * cfg["bolt"] / 2, y * cfg["bolt"] / 2, -0.5), (x * cfg["bolt"] / 2, y * cfg["bolt"] / 2, 1.0))
             for x in (-1, 1) for y in (-1, 1)]
    parts.append((fuse(*bolts), "anod_black"))
    return parts


ENC_OD = 37.0


def strain_wave_local(cfg):
    """Strain-wave gear unit with crossed-roller output bearing: output flange face at z=0, body toward -z."""
    od, L, fl = cfg["od"], cfg["length"], cfg["flange"]
    body = tube(od / 2, fl / 2 - 6, (0, 0, -L), (0, 0, -3)).fuse(cyl(od / 2 - 4, (0, 0, -L), (0, 0, -L + 6)))
    ring = tube(od / 2 - 1, fl / 2 + 1, (0, 0, -3), (0, 0, 0))
    out = tube(fl / 2, 7, (0, 0, -6), (0, 0, 0.5))
    heads = fuse(*[cyl(2.6, (0.4 * od * math.cos(a), 0.4 * od * math.sin(a), -L - 3), (0.4 * od * math.cos(a), 0.4 * od * math.sin(a), -L))
                   for a in np.linspace(0, 2 * math.pi, 12, endpoint=False)])
    oheads = fuse(*[cyl(1.9, (0.36 * fl * math.cos(a), 0.36 * fl * math.sin(a), 0.5), (0.36 * fl * math.cos(a), 0.36 * fl * math.sin(a), 2.3))
                    for a in np.linspace(0, 2 * math.pi, 8, endpoint=False)])
    return [(body, "steel"), (ring, "anod_black"), (out, "alu_dark"), (heads, "anod_black"), (oheads, "anod_black")]


def bearing_local(od, bore, w):
    outer = tube(od / 2, od / 2 - (od - bore) * 0.18, (0, 0, 0), (0, 0, w))
    inner = tube(bore / 2 + (od - bore) * 0.18, bore / 2, (0, 0, 0), (0, 0, w))
    seal = tube(od / 2 - (od - bore) * 0.18, bore / 2 + (od - bore) * 0.18, (0, 0, 0.3), (0, 0, w - 0.3))
    return [(outer, "steel"), (inner, "steel"), (seal, "rubber")]


def bolt_ring_local(n, rc, head_d, head_h, z0=0.0, phase=0.0):
    return fuse(*[cyl(head_d / 2, (rc * math.cos(a), rc * math.sin(a), z0), (rc * math.cos(a), rc * math.sin(a), z0 + head_h))
                  for a in np.linspace(phase, phase + 2 * math.pi, n, endpoint=False)])


def extrusion(size, p0, p1):
    """Aluminum T-slot extrusion (20 or 40 series) between two points along an axis."""
    s = size
    slot, depth = (6.2, 6.0) if s <= 20 else (8.2, 12.0)
    prof = cq.Workplane("XY").rect(s, s)
    w = prof.extrude(1.0)
    d = np.asarray(p1, float) - np.asarray(p0, float)
    L = float(np.linalg.norm(d))
    sol = cq.Workplane("XY").rect(s, s).extrude(L).val()
    cuts = []
    n = 1 if s <= 20 else 2
    offs = [0.0] if n == 1 else [-10.0, 10.0]
    for o in offs:
        cuts += [box((s / 2 - depth / 2, s / 2 + 1), (o - slot / 2, o + slot / 2), (-1, L + 1)),
                 box((-s / 2 - 1, -s / 2 + depth / 2), (o - slot / 2, o + slot / 2), (-1, L + 1)),
                 box((o - slot / 2, o + slot / 2), (s / 2 - depth / 2, s / 2 + 1), (-1, L + 1)),
                 box((o - slot / 2, o + slot / 2), (-s / 2 - 1, -s / 2 + depth / 2), (-1, L + 1))]
    core = cyl(2.5 if s <= 20 else 4.2, (0, 0, -1), (0, 0, L + 1))
    for c in cuts + [core]:
        sol = sol.cut(c)
    return along(sol, p0, d)


def aruco_bits(marker_id, dictionary="DICT_4X4_50"):
    import cv2
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, dictionary))
    n = d.markerSize + 2
    img = cv2.aruco.generateImageMarker(d, marker_id, n, borderBits=1)
    return (img < 128).astype(int)      # 1 = black cell, row 0 = top


def marker_plate_local(marker_id, size, plate, t, ink=0.25):
    """Printed ArUco marker on a white plate: plate back at z=0, printed face at z=t, image 'up' = +y."""
    bits = aruco_bits(marker_id)
    n = bits.shape[0]
    cell = size / n
    white = box((-plate / 2, plate / 2), (-plate / 2, plate / 2), (0, t))
    blacks = []
    for r in range(n):
        c = 0
        while c < n:
            if bits[r, c]:
                c2 = c
                while c2 + 1 < n and bits[r, c2 + 1]:
                    c2 += 1
                x0 = -size / 2 + c * cell
                x1 = -size / 2 + (c2 + 1) * cell
                y1 = size / 2 - r * cell
                y0 = y1 - cell
                blacks.append(box((x0, x1), (y0, y1), (t, t + ink)))
                c = c2 + 1
            else:
                c += 1
    return [(white, "white"), (fuse(*blacks), "black")]


def text_plate_local(w, h, t):
    return box((-w / 2, w / 2), (-h / 2, h / 2), (0, t))
