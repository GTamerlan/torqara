import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, "..", "..", ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Render the simulated mission (true joint angles, target attitude, magnet spin) on the CAD model to MP4."""
import json
import math
import os
import subprocess
import sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
from render2 import Renderer, poses2 as poses, COMPS_ARM, COMPS_TARGET, COMPS_SCENE  # noqa: E402
import design2 as D  # noqa: E402

TRAJ = sys.argv[1]
OUT = sys.argv[2]
T_END = float(sys.argv[3]) if len(sys.argv) > 3 else 24.0
W, H = 1280, 720
FR = _os.path.join(_PKG, "cad", "source", "out", "frames")
START = int(os.environ.get("START_FRAME", "0"))       # resume an interrupted render from this frame
os.makedirs(FR, exist_ok=True)
if START == 0:
    for f in os.listdir(FR):
        os.remove(os.path.join(FR, f))

data = json.load(open(TRAJ))
traj = [f for f in data["trajectory"] if f["t"] <= T_END]
r = Renderer(COMPS_ARM + COMPS_TARGET + COMPS_SCENE, w=W, h=H)
try:
    font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 22)
    font_s = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 18)
except Exception:
    font = font_s = ImageFont.load_default()
look = np.array([D.TARGET_CENTER[0] - 250.0, -20.0, D.TARGET_CENTER[2] + 120.0])
for k, f in enumerate(traj):
    if k < START:
        continue
    t = f["t"]
    a = math.radians(-35 + 55 * t / T_END)                # slow orbit around the rig
    rad, h = 1900.0, D.TARGET_CENTER[2] + 900.0 - 250 * t / T_END
    cam = {"pos": [look[0] + rad * math.cos(a), look[1] + rad * math.sin(a), h], "look": look.tolist(), "fov": 30}
    P = poses(f["q_deg"], f["target_quat"], f["magnet_spin_deg"])
    path = os.path.join(FR, f"f{k:05d}.png")
    r.shot(path, P, cam)
    im = Image.open(path).convert("RGB")
    d = ImageDraw.Draw(im, "RGBA")
    d.rectangle([20, 20, 500, 188], fill=(5, 6, 10, 170))
    phase = {"standby": "standby", "approach": "approach", "detumble": "braking", "stable": "stopped"}.get(f["phase"], f["phase"])
    col = {"braking": (240, 149, 58), "stopped": (95, 211, 160)}.get(phase, (200, 205, 215))
    d.text((36, 30), f"t = {t:5.1f} s", font=font, fill=(232, 234, 240))
    d.text((36, 60), f"target spin {f['spin_dps']:6.2f} deg/s", font=font, fill=(92, 200, 255))
    d.text((36, 90), f"phase: {phase}", font=font, fill=col)
    g = f.get("gap_mm")
    d.text((36, 120), f"magnet {abs(f['rpm']):5.0f} rpm", font=font, fill=(200, 205, 215))
    d.text((36, 150), "gap to hull   --" if g is None or g > 900 else f"gap to hull {g:5.1f} mm", font=font, fill=(200, 205, 215))
    d.text((W - 520, H - 44), "Physics simulation (MuJoCo) of the mission software on the CAD model, real time", font=font_s, fill=(200, 205, 215))
    im.save(path)
    if k % 50 == 0:
        print(k, len(traj), flush=True)
r.close()
fps = round(1.0 / (traj[1]["t"] - traj[0]["t"]))
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(fps), "-i", os.path.join(FR, "f%05d.png"),
                "-vf", "fps=30,format=yuv420p", "-c:v", "libx264", "-crf", "22", "-preset", "medium", OUT], check=True)
print("wrote", OUT, os.path.getsize(OUT) // 1000, "kB")
