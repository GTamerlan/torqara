import os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE); sys.path.insert(0, os.path.dirname(HERE))
from render2 import Renderer, identity_pose, COMPS_ARM, COMPS_TARGET, COMPS_SCENE
import design2 as D
comps = COMPS_ARM + COMPS_TARGET + COMPS_SCENE
r = Renderer(comps); P = identity_pose(comps)
R = os.path.join(os.path.dirname(HERE), "out", "renders"); os.makedirs(R, exist_ok=True)
tc = D.TARGET_CENTER
r.shot(R + "/chk_rig_iso.png", P, {"pos": [-1100, -2300, 900], "look": [450, 0, 300], "fov": 34})
r.shot(R + "/chk_target.png", P, {"pos": [tc[0] + 500, -650, tc[2] + 350], "look": [tc[0], 0, tc[2]], "fov": 32})
r.shot(R + "/chk_target_top.png", P, {"pos": [tc[0] + 50, -300, tc[2] + 800], "look": [tc[0], 0, tc[2]], "fov": 32})
r.shot(R + "/chk_rig_front.png", P, {"pos": [2600, 0, 400], "look": [500, 0, 400], "fov": 34})
r.close(); print("ok")
