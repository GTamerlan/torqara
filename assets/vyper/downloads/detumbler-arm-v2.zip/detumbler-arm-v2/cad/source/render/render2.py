import os as _os
_HERE = _os.path.dirname(_os.path.abspath(__file__))
_PKG = _os.path.normpath(_os.path.join(_HERE, "..", "..", ".."))
_os.environ.setdefault("DETUMBLER_SW", _os.path.join(_PKG, "software"))
"""Headless three.js renders of arm v2 (reuses proto/render/render.html)."""
import os, sys, subprocess, time, math
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import design2 as D

COMPS_ARM = ["ARM_BASE", "ARM_L1_TURRET", "ARM_L2_UPPER", "ARM_L3_FOREARM", "ARM_L4_FORK", "ARM_L5_HEAD", "ARM_L6_ROTOR"]
COMPS_TARGET = ["TARGET_STAND", "TARGET_YOKE", "TARGET_RING", "TARGET_BOX"]
COMPS_SCENE = ["CAMERA_MAST", "CONTROLLER"]


class Renderer:
    def __init__(self, comps, w=1600, h=900, bg="#0b0e15"):
        from playwright.sync_api import sync_playwright
        self.srv = subprocess.Popen([sys.executable, "-m", "http.server", "8766", "--bind", "127.0.0.1"], cwd=os.path.dirname(HERE),
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(0.8)
        self.pw = sync_playwright().start()
        self.browser = self.pw.chromium.launch(args=["--use-gl=angle", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"])
        self.page = self.browser.new_page(viewport={"width": w, "height": h})
        url = f"http://127.0.0.1:8766/render/render.html?w={w}&h={h}&bg={bg.replace('#', '%23')}&dir=../out/glb/&c={','.join(comps)}"
        self.page.goto(url)
        self.page.wait_for_function("window.ready === true", timeout=180000)

    def shot(self, path, pose, cam):
        self.page.evaluate("([p, c]) => window.setPose(p, c)", [pose, cam])
        self.page.screenshot(path=path)

    def visible(self, name, v):
        self.page.evaluate("([n, v]) => window.setVisible(n, v)", [name, v])

    def close(self):
        self.browser.close(); self.pw.stop(); self.srv.terminate()


def identity_pose(comps):
    return {c: np.eye(4).T.flatten().tolist() for c in comps}


if __name__ == "__main__":
    comps = COMPS_ARM
    r = Renderer(comps)
    P = identity_pose(comps)
    R = os.path.join(os.path.dirname(HERE), "out", "renders")
    os.makedirs(R, exist_ok=True)
    r.shot(R + "/chk_arm_iso.png", P, {"pos": [-900, -1400, 1100], "look": [350, 0, 450], "fov": 32})
    r.shot(R + "/chk_arm_side.png", P, {"pos": [350, -1600, 500], "look": [350, 0, 450], "fov": 32})
    r.shot(R + "/chk_shoulder.png", P, {"pos": [-350, -420, 380], "look": [0, 0, 200], "fov": 32})
    r.shot(R + "/chk_elbow.png", P, {"pos": [200, -320, 900], "look": [40, 40, 690], "fov": 32})
    r.shot(R + "/chk_wrist_head.png", P, {"pos": [520, -340, 820], "look": [520, 0, 700], "fov": 32})
    r.shot(R + "/chk_head_top.png", P, {"pos": [600, 260, 950], "look": [600, 0, 700], "fov": 32})
    r.close()
    print("ok")


# ------------------------------------------------------------------------------------ poses from a simulation frame
import math as _math
SW = os.environ.get("DETUMBLER_SW", _os.environ["DETUMBLER_SW"])
sys.path.insert(0, SW)
from detumbler.kinematics import Arm as _Arm  # noqa: E402
from detumbler.frames import R_from_quat as _Rq  # noqa: E402

_ARM = None
HOME_DEG = [0.0, 90.0, 0.0, 0.0, 0.0]
LINK_FRAME = {"ARM_L1_TURRET": 1, "ARM_L2_UPPER": 2, "ARM_L3_FOREARM": 3, "ARM_L4_FORK": 4, "ARM_L5_HEAD": 5}
TC = np.array(D.TARGET_CENTER, float)


def _arm():
    global _ARM
    if _ARM is None:
        _ARM = _Arm.from_toml(f"{SW}/config/arm_v2_5dof.toml")
    return _ARM


def _mm(T):
    T = T.copy()
    T[:3, 3] *= 1000.0
    return T


def _about(p, R):
    T = np.eye(4)
    T[:3, :3] = R
    T[:3, 3] = np.asarray(p) - R @ np.asarray(p)
    return T


def _rx(a):
    c, s = _math.cos(a), _math.sin(a)
    return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])


def _ry(a):
    c, s = _math.cos(a), _math.sin(a)
    return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])


def _rz(a):
    c, s = _math.cos(a), _math.sin(a)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


def gimbal_angles(R):
    """R = Rz(yaw) Ry(pitch) Rx(roll): yoke yaw about z, ring pitch about y, hull roll about x."""
    pitch = -_math.asin(max(-1.0, min(1.0, R[2, 0])))
    roll = _math.atan2(R[2, 1], R[2, 2])
    yaw = _math.atan2(R[1, 0], R[0, 0])
    return yaw, pitch, roll


def poses2(q_deg=None, quat=(1, 0, 0, 0), spin_deg=0.0):
    """Component transforms (column-major flat 4x4, mm) for the arm joints q (DH, deg), hull attitude quaternion
    (world <- body) and rotor spin angle."""
    arm = _arm()
    q = np.radians(HOME_DEG if q_deg is None else q_deg)
    F = arm.frames(q)
    F0 = arm.frames(np.radians(HOME_DEG))
    out = {c: np.eye(4) for c in COMPS_ARM + COMPS_TARGET + COMPS_SCENE}
    for name, i in LINK_FRAME.items():
        out[name] = _mm(F[i] @ np.linalg.inv(F0[i]))
    out["ARM_L6_ROTOR"] = out["ARM_L5_HEAD"] @ _about(np.array(D.MAGNET_CENTER), _rx(_math.radians(spin_deg)))
    R = _Rq(np.asarray(quat, float))
    yaw, pitch, roll = gimbal_angles(R)
    out["TARGET_YOKE"] = _about(TC, _rz(yaw))
    out["TARGET_RING"] = _about(TC, _rz(yaw) @ _ry(pitch))
    out["TARGET_BOX"] = _about(TC, R)
    return {k: v.T.flatten().tolist() for k, v in out.items()}
