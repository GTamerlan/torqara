"""Hero renders of arm v2 (home pose and a braking pose from the physics run)."""
import json
import os
import sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))
from render2 import Renderer, identity_pose, poses2, COMPS_ARM, COMPS_TARGET, COMPS_SCENE  # noqa: E402
import design2 as D  # noqa: E402

comps = COMPS_ARM + COMPS_TARGET + COMPS_SCENE
R = os.path.join(os.path.dirname(HERE), "out", "renders")
os.makedirs(R, exist_ok=True)
tc = D.TARGET_CENTER
r = Renderer(comps, w=1920, h=1080)
P = identity_pose(comps)
r.shot(R + "/v2_01_hero.png", P, {"pos": [-1500, -2200, 1100], "look": [450, -50, 350], "fov": 30})
r.shot(R + "/v2_02_arm_side.png", P, {"pos": [420, -2300, 500], "look": [420, 0, 450], "fov": 30})
r.shot(R + "/v2_03_shoulder.png", P, {"pos": [-420, -520, 420], "look": [0, 0, 210], "fov": 30})
r.shot(R + "/v2_04_elbow.png", P, {"pos": [260, -380, 930], "look": [40, 50, 690], "fov": 30})
r.shot(R + "/v2_05_wrist_head.png", P, {"pos": [560, -420, 860], "look": [560, 0, 700], "fov": 30})
r.shot(R + "/v2_06_head_closeup.png", P, {"pos": [700, 170, 850], "look": [620, 0, 700], "fov": 26})
r.shot(R + "/v2_07_target_gimbal.png", P, {"pos": [tc[0] + 520, -620, tc[2] + 330], "look": [tc[0], 0, tc[2] - 40], "fov": 30})
r.shot(R + "/v2_08_top.png", P, {"pos": [450, -200, 3000], "look": [450, -200, 0], "up": [0, 1, 0], "fov": 36})
r.shot(R + "/v2_09_controller.png", P, {"pos": [-900, -1300, 100], "look": [-170, -800, -520], "fov": 30})
# a braking pose from the physics run (the frame with the smallest head-to-hull gap while braking)
run = os.path.join(os.path.dirname(HERE), "out", "physics", "smoke.json")
if os.path.exists(run):
    d = json.load(open(run))
    fr = [f for f in d["trajectory"] if f["phase"] == "detumble" and f.get("gap_mm") is not None]
    if fr:
        f = min(fr, key=lambda x: x["gap_mm"])
        Pb = poses2(f["q_deg"], f["target_quat"], f["magnet_spin_deg"])
        r.shot(R + "/v2_10_braking.png", Pb, {"pos": [tc[0] - 300, -900, tc[2] + 700], "look": [tc[0] - 50, 0, tc[2] + 60], "fov": 30})
        r.shot(R + "/v2_11_braking_close.png", Pb, {"pos": [tc[0] + 350, -420, tc[2] + 420], "look": [tc[0] - 20, 0, tc[2] + 80], "fov": 26})
r.close()
print("ok")
