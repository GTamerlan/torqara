"""Detumbler arm v2 for Autodesk Fusion: builds the assembly with real joints, then replays a simulated mission.

How to run (Fusion, Design workspace):
  Utilities > Add-Ins > Scripts and Add-Ins (Shift+S) > Scripts tab > "+" (add) > pick this folder > Run

First run (in any document): opens a new design, imports every component STEP from ./step (pedestal and arm links,
target hull and its free three-axis gimbal, camera mast, controller), grounds the fixed parts, creates nine revolute joints with the real limits
(five arm joints, the magnet's spin and the target's three gimbal axes), then offers to play trajectory.json.

Run it again while that design is open: it skips the import and just replays the mission.

Afterwards you can move any joint by hand (right-click the joint in the browser > Drive Joints) or build a
Motion Study from the joints. Everything is in the robot base frame: origin on the arm's base plate under the J1 axis,
Z up, +X toward the target, millimetres. docs/FUSION_GUIDE.md has the manual steps if anything fails.
"""
import adsk.core
import adsk.fusion
import traceback
import json
import math
import os
import time

HERE = os.path.dirname(os.path.realpath(__file__))
STEP_DIR = os.path.join(HERE, "step")
TRAJ = os.path.join(HERE, "trajectory.json")

FIXED = ['CAMERA_MAST', 'CONTROLLER', 'TARGET_STAND', 'ARM_BASE']
MOVING = ['TARGET_YOKE', 'TARGET_RING', 'TARGET_BOX', 'ARM_L1_TURRET', 'ARM_L2_UPPER', 'ARM_L3_FOREARM', 'ARM_L4_FORK', 'ARM_L5_HEAD', 'ARM_L6_ROTOR']

# joint name, moving component, parent component, point on the axis [mm], axis, limits [deg] or None.
# Angles are measured from the as-built (home) pose, right-hand rule about the +axis.
JOINTS = [
    ('J1 base yaw', 'ARM_L1_TURRET', 'ARM_BASE', (0.0, 0.0, 0.0), 'z', (-170, 170)),
    ('J2 shoulder', 'ARM_L2_UPPER', 'ARM_L1_TURRET', (0.0, 0.0, 200.0), 'y', (-80, 80)),
    ('J3 elbow', 'ARM_L3_FOREARM', 'ARM_L2_UPPER', (0.0, 0.0, 700.0), 'y', (-150, 150)),
    ('J4 forearm roll', 'ARM_L4_FORK', 'ARM_L3_FOREARM', (0.0, 0.0, 700.0), 'x', (-180, 180)),
    ('J5 wrist pitch', 'ARM_L5_HEAD', 'ARM_L4_FORK', (400.0, 0.0, 700.0), 'y', (-120, 120)),
    ('Magnet spin', 'ARM_L6_ROTOR', 'ARM_L5_HEAD', (627.0, 0.0, 700.0), 'x', None),
    ('Gimbal yaw', 'TARGET_YOKE', 'TARGET_STAND', (944.0, 0.0, 550.0), 'z', None),
    ('Gimbal pitch', 'TARGET_RING', 'TARGET_YOKE', (944.0, 0.0, 550.0), 'y', None),
    ('Gimbal roll', 'TARGET_BOX', 'TARGET_RING', (944.0, 0.0, 550.0), 'x', None),
]

PLAY_EVERY = 2          # play every n-th recorded frame (recorded at 15 frames/s). Raise to 3-4 if replay is slow.
SPEED = 1.0             # 1.0 = real time when Fusion keeps up (it recomputes the joints every frame)
MIN_CHANGE_DEG = 0.02   # skip joints that moved less than this since the last frame (faster replay)


def cm(v):
    return adsk.core.Point3D.create(v[0] / 10.0, v[1] / 10.0, v[2] / 10.0)


AXES = {"x": (1, 0, 0), "y": (0, 1, 0), "z": (0, 0, 1)}


def tf(occ):
    try:
        return occ.transform2
    except Exception:
        return occ.transform


def import_components(app, root, ui):
    """Import each component STEP into its own top-level occurrence; returns {name: occurrence}."""
    im = app.importManager
    occs, missing = {}, []
    for name in FIXED + MOVING:
        path = os.path.join(STEP_DIR, name + ".step")
        if not os.path.exists(path):
            missing.append(name)
            continue
        before = root.occurrences.count
        im.importToTarget(im.createSTEPImportOptions(path), root)
        if root.occurrences.count > before:
            occ = root.occurrences.item(root.occurrences.count - 1)
            try:
                occ.component.name = name
            except Exception:
                pass
            occs[name] = occ
        adsk.doEvents()
    if missing:
        ui.messageBox("Missing STEP files in the step folder:\n" + "\n".join(missing))
    return occs


def find_occ(root, name):
    for occ in root.occurrences:                       # top level first
        if occ.component.name == name or occ.name.split(":")[0] == name:
            return occ
    for occ in root.allOccurrences:
        n = occ.component.name
        if n == name or n.startswith(name + " ") or n.startswith(name + "("):
            return occ
    return None


def parent_point_geometry(parent_occ, pt):
    """A joint origin point that belongs to the PARENT part, so the axis travels with it."""
    comp = parent_occ.component
    sk = comp.sketches.add(comp.xYConstructionPlane)
    sk.name = "joint origin"
    p = cm(pt)
    inv = tf(parent_occ).copy()
    inv.invert()
    p.transformBy(inv)                                 # world -> parent component coordinates
    skp = sk.sketchPoints.add(sk.modelToSketchSpace(p))
    sk.isVisible = False
    return adsk.fusion.JointGeometry.createByPoint(skp.createForAssemblyContext(parent_occ))


def root_point_geometry(root, pt):
    sk = root.sketches.add(root.xYConstructionPlane)
    sk.name = "joint origin"
    skp = sk.sketchPoints.add(cm(pt))
    sk.isVisible = False
    return adsk.fusion.JointGeometry.createByPoint(skp)


def add_joint(root, child_occ, parent_occ, pt, direction):
    """As-built revolute joint; tries a joint origin on the parent part first, then one in the root."""
    errors = []
    for make in (lambda: parent_point_geometry(parent_occ, pt), lambda: root_point_geometry(root, pt)):
        try:
            inp = root.asBuiltJoints.createInput(child_occ, parent_occ, make())
            inp.setAsRevoluteJointMotion(direction)
            return root.asBuiltJoints.add(inp)
        except Exception as e:
            errors.append(str(e))
    raise RuntimeError("could not create joint: " + " | ".join(errors))


def rotate(v, a, ang):
    """Rodrigues rotation of vector v about unit axis a by ang radians."""
    c, s = math.cos(ang), math.sin(ang)
    d = sum(v[i] * a[i] for i in range(3))
    x = (a[1] * v[2] - a[2] * v[1], a[2] * v[0] - a[0] * v[2], a[0] * v[1] - a[1] * v[0])
    return tuple(v[i] * c + x[i] * s + a[i] * d * (1 - c) for i in range(3))


def check_joint(joint, occ, point, axis):
    """Drive the joint +10 deg and measure how the part actually turned. Returns (sign, ok): sign makes
    positive values turn the part by the right-hand rule about +axis, as the robot software does;
    ok is False if the part turned about some other axis (then the guide's manual steps apply)."""
    c0 = cm(point)
    try:
        m0 = tf(occ)
        inv = m0.copy()
        inv.invert()
        joint.jointMotion.rotationValue = math.radians(10)
        adsk.doEvents()
        m1 = tf(occ)
        joint.jointMotion.rotationValue = 0
        adsk.doEvents()
        c = c0.copy(); c.transformBy(inv); c.transformBy(m1)
        moved = []                                     # three 1 cm offsets from the joint point, after the move
        for v in AXES.values():
            q = adsk.core.Point3D.create(c0.x + v[0], c0.y + v[1], c0.z + v[2])
            q.transformBy(inv); q.transformBy(m1)
            moved.append((v, (q.x - c.x, q.y - c.y, q.z - c.z)))
        best, best_key = -9.0, None
        for ax_name, a in AXES.items():
            for sgn in (1.0, -1.0):
                score = 0.0
                for v, got in moved:
                    e = rotate(v, a, sgn * math.radians(10))
                    score += sum((got[i] - v[i]) * (e[i] - v[i]) for i in range(3))
                if score > best:
                    best, best_key = score, (ax_name, sgn)
        return best_key[1], best_key[0] == axis
    except Exception:
        return 1.0, True


def build(app, ui):
    app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
    design = adsk.fusion.Design.cast(app.activeProduct)
    design.designType = adsk.fusion.DesignTypes.ParametricDesignType
    root = design.rootComponent
    try:
        design.fusionUnitsManager.distanceDisplayUnits = adsk.fusion.DistanceUnits.MillimeterDistanceUnits
    except Exception:
        pass
    occs = import_components(app, root, ui)
    for name in FIXED + MOVING:
        if name not in occs:
            occ = find_occ(root, name)
            if occ is None:
                ui.messageBox(f"Could not find component {name} after import.\nSee docs/FUSION_GUIDE.md for the manual steps.")
                return None, None
            occs[name] = occ
    for name in FIXED:
        try:
            occs[name].isGrounded = True
        except Exception:
            pass
    dirs = {"x": adsk.fusion.JointDirections.XAxisJointDirection, "y": adsk.fusion.JointDirections.YAxisJointDirection,
            "z": adsk.fusion.JointDirections.ZAxisJointDirection}
    joints, signs, bad = {}, {}, []
    for jname, child, parent, pt, ax, lim in JOINTS:
        j = add_joint(root, occs[child], occs[parent], pt, dirs[ax])
        j.name = jname
        joints[jname] = j
        sign, ok = check_joint(j, occs[child], pt, ax)
        signs[jname] = sign
        if not ok:
            bad.append(jname)
        if lim is not None:
            try:
                # 1 deg beyond the robot's own limits (the controller enforces the real ones), so a replay frame
                # that sits exactly on a limit is never rejected by Fusion
                lo, hi = sorted((math.radians(lim[0] - 1.0) * sign, math.radians(lim[1] + 1.0) * sign))
                lims = j.jointMotion.rotationLimits
                lims.isMinimumValueEnabled = True
                lims.minimumValue = lo
                lims.isMaximumValueEnabled = True
                lims.maximumValue = hi
            except Exception:
                pass
        adsk.doEvents()
    app.activeViewport.fit()
    if bad:
        ui.messageBox("These joints turn about an unexpected axis (Fusion version difference?):\n" + "\n".join(bad) +
                      "\n\nThe model is built; fix them by editing the joint's axis (docs/FUSION_GUIDE.md, step 4).")
    return joints, signs


def existing_rig(app):
    """If the active design already has the rig's joints, return them (and re-measure their signs)."""
    design = adsk.fusion.Design.cast(app.activeProduct)
    if design is None:
        return None, None
    root = design.rootComponent
    joints = {}
    for j in root.asBuiltJoints:
        joints[j.name] = j
    if not all(n in joints for n, *_ in JOINTS):
        return None, None
    for n, *_ in JOINTS:                                # home pose first
        try:
            joints[n].jointMotion.rotationValue = 0
        except Exception:
            pass
    adsk.doEvents()
    signs = {}
    for jname, child, parent, pt, ax, lim in JOINTS:
        occ = find_occ(root, child)
        signs[jname] = check_joint(joints[jname], occ, pt, ax)[0] if occ is not None else 1.0
    return joints, signs


def replay(app, ui, joints, signs):
    if not os.path.exists(TRAJ):
        ui.messageBox("Rig built with joints. trajectory.json not found next to the script, so no replay.")
        return
    data = json.load(open(TRAJ))
    frames = data["frames"]
    n = len(range(0, len(frames), PLAY_EVERY))
    res = ui.messageBox(f"Rig ready: {len(joints)} joints.\n\nPlay the simulated detumble mission now?\n"
                        f"({frames[-1]['t']:.0f} s of mission, {n} frames)", "Detumbler arm v2",
                        adsk.core.MessageBoxButtonTypes.YesNoButtonType)
    if res != adsk.core.DialogResults.DialogYes:
        return
    dt = data.get("dt", 1 / 15.0) * PLAY_EVERY / SPEED
    vp = app.activeViewport
    pd = ui.createProgressDialog()
    pd.isCancelButtonShown = True
    pd.show("Detumbler mission replay", "Frame %v of %m", 0, n, 0)
    last = {}
    try:
        for i, k in enumerate(range(0, len(frames), PLAY_EVERY)):
            if pd.wasCancelled:
                break
            t0 = time.time()
            f = frames[k]
            for jname, val in f["joints_deg"].items():
                if jname in joints and abs(val - last.get(jname, 1e9)) >= MIN_CHANGE_DEG:
                    try:
                        joints[jname].jointMotion.rotationValue = math.radians(val) * signs[jname]
                        last[jname] = val
                    except Exception:
                        pass
            pd.progressValue = i + 1
            pd.message = f"t = {f['t']:5.1f} s   {f.get('phase', '')}   target spin {f.get('spin_dps', 0):5.2f} deg/s"
            vp.refresh()
            adsk.doEvents()
            wait = dt - (time.time() - t0)
            if wait > 0:
                time.sleep(wait)
    finally:
        pd.hide()
    ui.messageBox("Replay finished. Run the script again to replay, or right-click a joint > Drive Joints to move it by hand.")


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        joints, signs = existing_rig(app)
        if joints is None:
            joints, signs = build(app, ui)
            if joints is None:
                return
        replay(app, ui, joints, signs)
    except Exception:
        if ui:
            ui.messageBox("Failed:\n{}".format(traceback.format_exc()))
