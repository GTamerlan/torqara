# Arm v2: how the files fit together and how to work with them

Everything in this package is generated from one file, `cad/source/design2.py`. Change a number there and the
CAD, the parts list, the robot software's configs, the loads report and the physics model all follow.

## Folders

| Folder | What is in it |
|---|---|
| `cad/` | `Detumbler_Arm_v2_Assembly.step` (whole rig, every part named), `components/*.step` (13 components), `stl_printed/` (the 12 printed parts), `glb/` (for the web renderer), `renders/`, `source/` (CadQuery scripts) |
| `fusion/DetumblerArmV2/` | Autodesk Fusion script: imports the components, builds the nine working joints (five arm joints, magnet spin, three gimbal axes), replays the physics run. Same steps as the first prototype: Utilities > Add-Ins > Scripts > + > pick the folder > Run |
| `physics/` | MuJoCo model `detumbler_v2.xml` + `meshes/`; `mj_model.py` (builds it from the CAD mass model), `mj_world.py` (the physics world the mission software drives), `mj_run.py`, `mj_baseline.py`, `batch_v2.py`; `results/` with every run |
| `software/` | The robot software (same package as before, updated: `detumbler/gimbal.py`, the drive interpolator in `hardware.py`, gimbal-aware planner, safety and mission logic; configs `config/arm_v2_5dof.toml`, `config/rig_v2.toml`) |
| `bom/` | `Detumbler_Arm_v2_Parts_List.xlsx` / `.csv` |
| `docs/` | this guide, `ARM_V2_REPORT.md`, `loads_report.md` |

## Regenerate everything

```
pip install cadquery==2.8.0 numpy mujoco openpyxl opencv-contrib-python
cd cad/source
python cad2_rig.py            # STEP, STL, GLB, mass model (about 15 s)
python check_all.py           # interference check: must print 0 interferences
python sizing.py              # loads report from the CAD masses
python gen_configs2.py        # software configs from the design (DETUMBLER_SW points at ../../software)
python mj_model.py            # MuJoCo model from the CAD mass model
python make_bom2.py           # parts list
cd ../../software && python tests/run_tests.py --quick
```

## Run the simulations

Kinematic world (fast, no friction, the hull as a free rigid body):
```
cd software
python tools/run_mission.py --sim --arm config/arm_v2_5dof.toml --rig config/rig_v2.toml --spin 40 4 2 --seconds 120
```

Physics world (MuJoCo: CAD masses, servo loops with torque limits, spinning rotor, free gimbal with bearing friction),
the same mission software:
```
cd physics
python mj_run.py --spin 40 4 2 --seconds 120 --out results/my_run.json
python mj_baseline.py         # the hull's free decay on the gimbal, no magnet (bearing friction only)
python batch_v2.py --physics  # the batch in the report
```
`--spin` gives the hull's body rates at t = 0 in deg/s: roll about the gimbal pins, pitch, yaw. The stand is meant
for roll-dominant tumbles (fast about the pins, slow on the other two); see the report, section 6.

For the v2 rig the physics world is the reference. The kinematic world treats the hull as a free rigid body and does
not know that the ring and yoke add inertia to the pitch and yaw motions, so it lets a braked roll turn into a
three-axis tumble that the physics (and the real stand) do not produce; use it for safety checks, not for braking times.

## Hardware notes that came out of the design

- **Balance first.** The braking torque is of order 1 mN m. A 0.2 mm offset of the hull's center of mass from the
  gimbal center gives 3.5 mN m of gravity torque. Balance the hull and the ring with the trim screws (pendulum test)
  to better than 0.02 mm before any braking test, and measure the stand's free decay (bearing friction) first.
- **Bolt patterns.** The actuators' hole patterns in `design2.py` follow the usual harmonic-actuator layout but were
  not read from the vendor drawings. Download the HJ2 2D drawings / STEP from store.leadshine.com and update the
  `HJ2[...]` entries before the hubs are machined. Everything else regenerates.
- **Assembly order.** J4's cradle screws are driven from inside the forearm tube socket before the tube is bonded; the
  head hub's screws are driven from the magnet side before the clamp block goes on; the rear bearing block is a
  spigot held by three radial screws into heat-set inserts.
- **Nothing conductive moves near the magnet except the hull.** Printed PA12-CF boom and bearing blocks, polycarbonate
  guard, titanium shaft, ceramic bearings, G10 ring, printed yoke. Aluminum parts that rotate with the magnet (end
  caps) see no changing field and are fine.
- **Spindle speed.** The braking law sweeps the field at up to 4 m/s at the pole face (about 1500 rpm); the hardware
  can do 3000 rpm. Balance the finished rotor (ISO G2.5).

## Camera software

The vision pipeline from the first prototype is unchanged: ArUco markers on all six hull faces (the +-x faces carry
a smaller marker above the roll hub), a marker block on the boom, camera-to-robot calibration from the arm showing
the block to the camera. `rig_v2.toml` holds camera A's position; camera B is mounted on the mast for the next step
(two-camera fusion and handling of frames where the ring hides a marker).
