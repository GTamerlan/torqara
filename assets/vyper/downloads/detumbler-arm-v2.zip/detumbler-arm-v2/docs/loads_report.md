# Arm v2 loads report

Mass model: CAD mass properties (out/mass_model.json).

Moving mass 13.94 kg, head (everything after J5, with the rotor) 2.456 kg, reach 1127 mm fully stretched.

## Joint torques and actuator margins

| Joint | Actuator | Worst gravity torque | Dynamic (max accel, stretched) | Peak demand | Rated / peak | Margin on rated | Margin on peak | Brake |
|---|---|---|---|---|---|---|---|---|
| J1 | HJ2-90-NK | 0.0 N m | 3.51 N m | 3.51 N m | 50.0 / 102.0 N m | 14.23x | 29.03x | no |
| J2 | HJ2-110-BK | 65.86 N m | 3.41 N m | 69.27 N m | 84.0 / 194.0 N m | 1.21x | 2.8x | yes |
| J3 | HJ2-90-BK | 22.95 N m | 1.65 N m | 24.6 N m | 50.0 / 102.0 N m | 2.03x | 4.15x | yes |
| J4 | HJ2-70-NK | 2.82 N m | 0.02 N m | 2.84 N m | 9.6 / 34.0 N m | 3.38x | 11.98x | no |
| J5 | HJ2-70-BK | 2.85 N m | 0.18 N m | 3.03 N m | 9.6 / 34.0 N m | 3.17x | 11.22x | yes |

Worst gravity pose per joint (J1..J5 deg): J1: None; J2: [0.0, -80.0, -100.0, 0.0, 0.0]; J3: [0.0, -37.89473684210527, 40.0, 90.0, 0.0]; J4: [0.0, -80.0, 80.0, 90.0, 100.0]; J5: [0.0, -21.05263157894737, -60.0, 180.0, 100.0]

Gravity torque in everyday poses [N m]: home: J1 0.0, J2 22.9, J3 22.9, J4 -0.8, J5 2.9; reach_forward_60deg: J1 0.0, J2 60.7, J3 22.9, J4 -0.8, J5 2.9; stretched_horizontal: J1 0.0, J2 43.6, J3 0.0, J4 -0.0, J5 0.0

## Spindle (magnet spinner)

- Rotor 0.734 kg, inertia 2.33e-04 kg m2, 3000 rpm max, rim speed 9.6 m/s.
- Angular momentum 0.0732 N m s. Gyroscopic torque while the arm slews at its fastest: 0.115 N m, i.e. 4.0% of the wrist's gravity load. Negligible.
- Spin-up to full speed in 8 s needs 9.2 mN m; the motor's continuous torque is 84.8 mN m.
- Rotor OD 61.0 mm (block in its carbon tube), guard OD 66.0 mm.
- Unbalance: every g mm of residual unbalance gives 0.099 N of shaking force at full speed. ISO G2.5 on this rotor is about 5 g mm -> 0.49 N.
- Magnet dipole 77.2 A m2. Field at the spindle motor 8.94 mT (pull on its iron < 0.04 N), at the J5 actuator 1.32 mT, at the hull 5 cm away 123.5 mT.

## Stiffness

- Head weight 24.1 N at full stretch: carbon tubes sag 0.43 mm, harmonic-gear wind-up J2 1.22 mm, J3 0.42 mm, J5 0.04 mm; total 2.11 mm.
- Tip stiffness 11.4 N/mm, first bending mode about 8.73 Hz.
- static sag is measured and removed by the camera each frame; what matters is the first mode staying well above the 0.3 Hz content of the commanded motion.

## Power and cost

- All five joints at rated torque and speed together: 549 W; spindle 27 W. PSU: Mean Well RSP-1500-48 (48 V, 1500 W).
- Drive train (5 actuators, spindle motor and driver, magnet): $4574.

## Check before machining

- HJ2 bolt patterns (count, thread, PCD) on the output flange and body: taken from the usual layout, not from the vendor drawing. Download the 2D drawing / STEP for each size from store.leadshine.com and update HJ2[...] before cutting the hubs.
- HJ2 connector position and cable exit (the hubs leave a 30 mm cable window; move it if the connector is elsewhere).
- Magnet block: confirm 50.8 x 50.8 x 25.4 mm nominal, measure the actual block and pot it with 0.3 mm epoxy clearance.
- Carbon tube actual OD/ID: roll-wrapped tubes are +-0.2 mm; ream the hub bores to the delivered tube.
- Rotor balance: balance the finished rotor to ISO 1940 G2.5 at 3000 rpm before fitting the guard.
